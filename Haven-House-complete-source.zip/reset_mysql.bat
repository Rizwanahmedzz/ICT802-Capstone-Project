@echo off
TASKKILL /F /IM mysqld.exe >nul 2>&1
DEL /F /Q "C:\xampp\mysql\data\ibdata1" "C:\xampp\mysql\data\ib_logfile0" "C:\xampp\mysql\data\ib_logfile1" "C:\xampp\mysql\data\ibtmp1" >nul 2>&1
echo MYSQL_STATE_RESET
