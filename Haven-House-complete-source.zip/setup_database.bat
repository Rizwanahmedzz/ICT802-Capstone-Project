@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
    echo Python Launcher was not found. Install Python 3 and ensure the "py" command is available.
    pause
    exit /b 1
)

py -3 backend\setup_database.py
if errorlevel 1 (
    echo.
    echo Setup did not complete. Confirm MySQL is running in the XAMPP Control Panel
    echo and install backend dependencies with: py -3 -m pip install -r backend\requirements.txt
    pause
    exit /b 1
)

echo.
pause
