-- ====================================================================
-- HAVEN HOUSE — SERVICE NAVIGATION ASSISTANT
-- PROTOTYPE / DEMO SEED DATA SCRIPT
-- Populates 7 demo service categories with clearly marked placeholder content.
-- All content is clearly marked as DEMO / placeholder awaiting client approval.
-- ====================================================================

USE haven_house;

-- Clear existing data if resetting in development
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE audit_log;
TRUNCATE TABLE users;
TRUNCATE TABLE otp_challenges;
TRUNCATE TABLE appointments;
TRUNCATE TABLE knowledge_content;
TRUNCATE TABLE faq_feedback;
TRUNCATE TABLE faqs;
TRUNCATE TABLE service_hours;
TRUNCATE TABLE service_eligibility;
TRUNCATE TABLE service_details;
TRUNCATE TABLE services;
TRUNCATE TABLE organization;
SET FOREIGN_KEY_CHECKS = 1;

-- ====================================================================
-- 1. SEED ORGANIZATION
-- ====================================================================
INSERT INTO organization (id, name, tagline, location, established_period, disclaimer)
VALUES (
    1,
    'Haven House',
    'Crisis Support Services',
    'Bondi, Sydney',
    '1980s',
    'The Support Assistant provides service navigation and approved information. It is not a counsellor, therapist, lawyer, doctor, or emergency service.'
);

-- ====================================================================
-- 2. SEED SERVICES (7 Demo Service Categories)
-- ====================================================================
INSERT INTO services (id, service_key, title, card_title, badge, description, icon_name, is_active, display_order)
VALUES
(
    1,
    'accommodation',
    'Emergency & Temporary Accommodation Support',
    'Emergency & Temporary Accommodation Support',
    'Crisis & Temporary Accommodation [DEMO]',
    'DEMO — Example service record showing how accommodation-related support could be presented.',
    'home',
    TRUE,
    1
),
(
    2,
    'child-support',
    'Child & Family Support',
    'Child & Family Support',
    'HH Kids Programs [DEMO]',
    'DEMO — Example service record showing how child and family support could be presented.',
    'child',
    TRUE,
    2
),
(
    3,
    'ndis',
    'NDIS Support Coordination',
    'NDIS Support Coordination',
    'Disability & Support Coordination [DEMO]',
    'DEMO — Example service record showing how NDIS-related support could be presented.',
    'accessibility',
    TRUE,
    3
),
(
    4,
    'psychology',
    'Counselling & Psychological Support',
    'Counselling & Psychological Support',
    'Psychological & Mental Health Services [DEMO]',
    'DEMO — Example service record showing how counselling and psychological support could be presented.',
    'heart-pulse',
    TRUE,
    4
),
(
    5,
    'employment',
    'Employment & Skills Support',
    'Employment & Skills Support',
    'Vocational & Jobs Support [DEMO]',
    'DEMO — Example service record showing how employment support could be presented.',
    'briefcase',
    TRUE,
    5
),
(
    6,
    'chaplaincy',
    'Chaplaincy & Pastoral Support',
    'Chaplaincy & Pastoral Support',
    'Pastoral & Spiritual Support [DEMO]',
    'DEMO — Example service record showing how chaplaincy support could be presented.',
    'hands-helping',
    TRUE,
    6
),
(
    7,
    'general-info',
    'Haven House General Information',
    'Haven House General Information',
    'Organisation Overview [DEMO]',
    'DEMO — Example service record showing how general information could be presented.',
    'info-circle',
    TRUE,
    7
);

-- ====================================================================
-- 3. SEED SERVICE DETAILS (1:1 with services)
-- ====================================================================
INSERT INTO service_details (service_id, detail_title, detail_description, overview, relevance, intake_desk_text, eligibility_note)
VALUES
(
    1,
    'Emergency & Temporary Accommodation Support [DEMO]',
    'DEMO — Short-term emergency beds and transitional accommodation pathways.',
    'DEMO — Haven House coordinates crisis and temporary accommodation assistance for eligible individuals and families in the Bondi and Eastern Suburbs area seeking safe shelter. [DEMO — client confirmation required].',
    'DEMO — When you need safe emergency housing, transitional accommodation, or support navigating community housing pathways.',
    '[DEMO — Intake desk: Contact Haven House coordinator during intake hours or via Bondi safe hub].',
    'DEMO — Initial safety screening and intake assessment apply. [DEMO — client confirmation required].'
),
(
    2,
    'Child & Family Support [DEMO]',
    'DEMO — Community programs and tailored support through HH Kids.',
    'DEMO — Specialized support programs designed to foster safety, emotional well-being, and social development for children and young people. [DEMO — client confirmation required].',
    'DEMO — Families with children requiring developmental, emotional, or community-based support services.',
    '[DEMO — Intake desk: Contact family intake coordinator].',
    'DEMO — Open to children, youth, and families residing in the catchment area. [DEMO — client confirmation required].'
),
(
    3,
    'NDIS Support Coordination [DEMO]',
    'DEMO — Navigating disability plans and connecting with registered providers.',
    'DEMO — Practical assistance for NDIS participants to understand and implement their plans, connecting with trusted community providers. [DEMO — client confirmation required].',
    'DEMO — Individuals with an active or pending NDIS plan seeking local support coordination.',
    '[DEMO — Intake desk: Contact NDIS intake coordinator].',
    'DEMO — Requires an active NDIS plan or eligibility for NDIS access support. [DEMO — client confirmation required].'
),
(
    4,
    'Counselling & Psychological Support [DEMO]',
    'DEMO — Confidential psychological and emotional support pathways.',
    'DEMO — Information and referral coordination for confidential psychology, mental health, and trauma-informed wellbeing services. [DEMO — client confirmation required].',
    'DEMO — Individuals seeking mental health consultations, emotional resilience support, or psychological referrals.',
    '[DEMO — Intake desk: Contact psychological services intake].',
    'DEMO — Confidential intake assessment applies. [DEMO — client confirmation required].'
),
(
    5,
    'Employment & Skills Support [DEMO]',
    'DEMO — Vocational guidance, resume preparation, and job readiness.',
    'DEMO — Supportive guidance for job seekers including resume reviews, interview preparation, and vocational skill-building. [DEMO — client confirmation required].',
    'DEMO — Community members seeking employment pathways, vocational training, or workforce re-entry.',
    '[DEMO — Intake desk: Contact employment support coordinator].',
    'DEMO — Open to all individuals seeking employment navigation assistance. [DEMO — client confirmation required].'
),
(
    6,
    'Chaplaincy & Pastoral Support [DEMO]',
    'DEMO — Pastoral care, spiritual support, and community comfort.',
    'DEMO — Respectful chaplaincy and pastoral care offering listening, spiritual counsel, and comfort during difficult life transitions. [DEMO — client confirmation required].',
    'DEMO — Individuals or families seeking spiritual comfort, pastoral conversations, or community chaplaincy.',
    '[DEMO — Intake desk: Contact chaplaincy desk].',
    'DEMO — Non-judgmental and open to all community members. [DEMO — client confirmation required].'
),
(
    7,
    'Haven House General Information [DEMO]',
    'DEMO — Overview of Haven House mission, location, and community pathways.',
    'DEMO — Established in Bondi, Sydney, Haven House is an independent crisis support organisation dedicated to providing community care, shelter navigation, and family resources. [DEMO — client confirmation required].',
    'DEMO — Visitors, community members, and service partners seeking general organizational information.',
    '[DEMO — General inquiries: Contact Haven House reception].',
    'DEMO — General information is publicly accessible to all. [DEMO — client confirmation required].'
);

-- ====================================================================
-- 4. SEED SERVICE ELIGIBILITY (1:M with services)
-- ====================================================================
INSERT INTO service_eligibility (service_id, criterion, display_order)
VALUES
(1, 'DEMO — Individuals or families requiring urgent safe accommodation [client confirmation required]', 1),
(1, 'DEMO — Assessment of safety and housing readiness [client confirmation required]', 2),
(2, 'DEMO — Children and youth aged 0–18 and their families [client confirmation required]', 1),
(2, 'DEMO — Community or self-referral [client confirmation required]', 2),
(3, 'DEMO — Current NDIS plan with Support Coordination funding or NDIS access inquiry [client confirmation required]', 1),
(4, 'DEMO — Seeking psychological wellbeing or trauma-informed support [client confirmation required]', 1),
(5, 'DEMO — Seeking employment navigation or vocational skill-building [client confirmation required]', 1),
(6, 'DEMO — Community members seeking pastoral or spiritual support [client confirmation required]', 1),
(7, 'DEMO — Open to all community members and service partners [client confirmation required]', 1);

-- ====================================================================
-- 5. SEED SERVICE HOURS (1:M with services)
-- ====================================================================
INSERT INTO service_hours (service_id, day_of_week, opening_time, closing_time, is_closed, notes)
VALUES
(1, 'Monday', '09:00:00', '17:00:00', FALSE, 'DEMO — Standard intake hours [24/7 crisis escalation via 000/approved crisis line]'),
(1, 'Tuesday', '09:00:00', '17:00:00', FALSE, 'DEMO — Standard intake hours'),
(1, 'Wednesday', '09:00:00', '17:00:00', FALSE, 'DEMO — Standard intake hours'),
(1, 'Thursday', '09:00:00', '17:00:00', FALSE, 'DEMO — Standard intake hours'),
(1, 'Friday', '09:00:00', '16:00:00', FALSE, 'DEMO — Standard intake hours'),
(2, 'Monday', '09:00:00', '17:00:00', FALSE, 'DEMO — Family programs by appointment'),
(3, 'Monday', '09:00:00', '17:00:00', FALSE, 'DEMO — Support coordination desk open'),
(4, 'Monday', '09:00:00', '17:00:00', FALSE, 'DEMO — Consultation appointments scheduled'),
(5, 'Monday', '09:00:00', '17:00:00', FALSE, 'DEMO — Jobs consultation desk open'),
(6, 'Monday', '09:00:00', '17:00:00', FALSE, 'DEMO — Chaplaincy visits and pastoral care'),
(7, 'Monday', '09:00:00', '17:00:00', FALSE, 'DEMO — General reception open');

-- ====================================================================
-- 6. SEED FAQS (1-2 per service category)
-- ====================================================================
INSERT INTO faqs (id, question, answer, category, display_order, is_active)
VALUES
(1, 'How can I access emergency accommodation support? [DEMO]', 'DEMO — Haven House coordinates emergency intake for eligible individuals. Contact the intake coordinator during standard hours, or dial emergency services (000) for immediate danger. [DEMO — client confirmation required].', 'Accommodation', 1, TRUE),
(2, 'What types of temporary shelter pathways are offered? [DEMO]', 'DEMO — Pathways range from crisis short-term beds to transitional housing referrals. [DEMO — client confirmation required].', 'Accommodation', 2, TRUE),
(3, 'What programs does HH Kids provide for children? [DEMO]', 'DEMO — HH Kids offers social, recreational, and emotional support programs tailored for children and youth. [DEMO — client confirmation required].', 'HH Kids / Family', 3, TRUE),
(4, 'How does NDIS Support Coordination work? [DEMO]', 'DEMO — Our support coordinators assist participants with navigating plan budgets and connecting with trusted registered providers. [DEMO — client confirmation required].', 'NDIS', 4, TRUE),
(5, 'How do I arrange a psychological support consultation? [DEMO]', 'DEMO — Contact the Haven House team to discuss confidential referral and intake options for psychological services. [DEMO — client confirmation required].', 'Psychology', 5, TRUE),
(6, 'What vocational and employment help is available? [DEMO]', 'DEMO — We provide resume reviews, interview guidance, and job search navigation support. [DEMO — client confirmation required].', 'Employment', 6, TRUE),
(7, 'Is chaplaincy support available to anyone in the community? [DEMO]', 'DEMO — Yes, Haven House chaplaincy offers non-judgmental spiritual comfort and listening for all community members. [DEMO — client confirmation required].', 'Chaplaincy', 7, TRUE),
(8, 'Where is Haven House located and what are the general hours? [DEMO]', 'DEMO — Haven House is based in Bondi, Sydney. General inquiries are managed Monday to Friday, 9:00 AM – 5:00 PM. [DEMO — client confirmation required].', 'General', 8, TRUE);

-- ====================================================================
-- 7. SEED KNOWLEDGE CONTENT
-- Service records below are external referral information, not claims that
-- Haven House itself provides these services. Confirm linked source details.
-- ====================================================================
INSERT INTO knowledge_content (content_type, reference_id, content_text, approval_status, is_active, version)
VALUES
(
    'SERVICE',
    1,
    'EXTERNAL REFERRAL INFORMATION — This is not a claim that Haven House provides accommodation. Ask Izzy is an Australian directory where people can search by location for accommodation, housing, food, financial, health and other community support. Eligibility, availability, hours and costs are determined by each listed provider; contact that provider to confirm. Source: https://askizzy.org.au/',
    'APPROVED',
    TRUE,
    1
),
(
    'SERVICE',
    2,
    'EXTERNAL REFERRAL INFORMATION — This is not a claim that Haven House provides family relationship services. The Australian Government Family Relationship Advice Line offers information, support and referrals for parents, grandparents, children, young people, other family members and friends. Published hours: Monday-Friday 8 am-8 pm local time and Saturday 10 am-4 pm local time; closed Sundays and national public holidays. Contact: 1800 050 321. Confirm current hours and options with the provider. Source: https://www.familyrelationships.gov.au/talk-someone/advice-line',
    'APPROVED',
    TRUE,
    1
),
(
    'SERVICE',
    3,
    'EXTERNAL REFERRAL INFORMATION — This is not a claim that Haven House provides NDIS services or that any person is eligible. NDIS access is subject to official eligibility requirements. For information about access, plans, supports, providers or local offices, contact the NDIS National Contact Centre on 1800 800 110 or visit https://www.ndis.gov.au/. Published contact-centre hours: Monday-Friday 8 am-7 pm local time. Confirm current details with the NDIS. Source: https://www.ndis.gov.au/contact',
    'APPROVED',
    TRUE,
    1
),
(
    'SERVICE',
    4,
    'EXTERNAL REFERRAL INFORMATION — This is not a claim that Haven House provides counselling or psychology. Lifeline Australia offers crisis support for people in Australia by phone, text and online chat, 24 hours a day, 7 days a week. Phone: 13 11 14. Text: 0477 13 11 14. This is not a substitute for emergency services; call 000 for immediate danger. Confirm current options with Lifeline. Source: https://www.lifeline.org.au/131114',
    'APPROVED',
    TRUE,
    1
),
(
    'SERVICE',
    5,
    'EXTERNAL REFERRAL INFORMATION — This is not a claim that Haven House provides employment services or that any person qualifies for assistance. Workforce Australia can provide information about employment services; eligibility and assistance depend on the person and service. Contact its Digital Services Contact Centre on 1800 314 677 or visit https://www.workforceaustralia.gov.au/individuals/contact to confirm current availability and requirements. Source: https://www.workforceaustralia.gov.au/',
    'APPROVED',
    TRUE,
    1
),
(
    'SERVICE',
    6,
    'EXTERNAL REFERRAL INFORMATION — No single national chaplaincy contact has been identified. Availability, eligibility, hours and costs vary. Ask the relevant hospital, educational institution, community organisation or service provider about pastoral, spiritual or chaplaincy support. No Haven House chaplaincy contact details have been verified; do not infer any.',
    'APPROVED',
    TRUE,
    1
),
(
    'SERVICE',
    7,
    'EXTERNAL REFERRAL INFORMATION — This is general Australian service navigation, not a claim about Haven House operations. Ask Izzy lets people search for community services by assistance type, including housing, money help, counselling, family violence support, health, employment and education. Availability, eligibility and costs depend on the listed provider. Ask Izzy: https://askizzy.org.au/. For deaf, hard-of-hearing or speech/communication access, the National Relay Service Helpdesk is 1800 555 660; confirm available relay options at https://www.accesshub.gov.au/about-the-nrs/nrs-helpdesk.',
    'APPROVED',
    TRUE,
    1
);

-- User-supplied general guidance approved for chatbot use.
INSERT INTO knowledge_content (content_type, reference_id, content_text, approval_status, is_active, version)
VALUES
(
    'ORGANIZATION',
    NULL,
    'For each service, users can find approved information about what the service offers, who is eligible, how to access it, hours and costs, and verified contact information. Use only approved and verified sources. Service details, eligibility, hours, costs, and contact information may change, so users should confirm current details with the relevant service provider. No specific service-level details are established by this general guidance.',
    'APPROVED',
    TRUE,
    1
),
(
    'SAFETY_MESSAGE',
    NULL,
    'Privacy: Do not provide personal, confidential, or sensitive information unless it is specifically required by the relevant service provider. Avoid sharing passwords, identification numbers, financial details, medical records, or other private client information.',
    'APPROVED',
    TRUE,
    1
),
(
    'SAFETY_MESSAGE',
    NULL,
    'Emergency information for Australia: If you or someone else is in immediate danger or requires urgent assistance, call 000 for emergency police, fire, or ambulance services. For non-emergency assistance, contact the appropriate service provider using its verified contact information.',
    'APPROVED',
    TRUE,
    1
);

-- Replace legacy demo presentation with external referral information.
UPDATE services SET
    title = CASE id
        WHEN 1 THEN 'Accommodation Support'
        WHEN 2 THEN 'Children, Youth & Family Services'
        WHEN 3 THEN 'NDIS Support'
        WHEN 4 THEN 'Counselling & Psychology'
        WHEN 5 THEN 'Employment & Skills Support'
        WHEN 6 THEN 'Chaplaincy Pastoral Care'
        WHEN 7 THEN 'Information and Referrals'
    END,
    card_title = CASE id
        WHEN 1 THEN 'Accommodation Support'
        WHEN 2 THEN 'Children, Youth & Family Services'
        WHEN 3 THEN 'NDIS Support'
        WHEN 4 THEN 'Counselling & Psychology'
        WHEN 5 THEN 'Employment & Skills Support'
        WHEN 6 THEN 'Chaplaincy Pastoral Care'
        WHEN 7 THEN 'Information and Referrals'
    END,
    badge = 'External referral information',
    description = CASE id
        WHEN 1 THEN 'Search Ask Izzy for accommodation, housing, food, financial and other community support. Availability depends on each provider.'
        WHEN 2 THEN 'The Family Relationship Advice Line provides information, support and referrals for families. Call 1800 050 321.'
        WHEN 3 THEN 'Contact the NDIS for information about access, plans, supports and providers. Call 1800 800 110.'
        WHEN 4 THEN 'Lifeline offers crisis support by phone, text and online chat, 24 hours a day. This is not a Haven House service.'
        WHEN 5 THEN 'Contact Workforce Australia for information about employment services. Eligibility and assistance vary.'
        WHEN 6 THEN 'Ask a relevant hospital, educational institution or community organisation about pastoral support.'
        WHEN 7 THEN 'Search Ask Izzy for Australian community services. Confirm availability and requirements with each provider.'
    END
WHERE id BETWEEN 1 AND 7;

UPDATE service_details SET
    detail_title = CASE service_id
        WHEN 1 THEN 'Accommodation Support'
        WHEN 2 THEN 'Children, Youth & Family Services'
        WHEN 3 THEN 'NDIS Support'
        WHEN 4 THEN 'Counselling & Psychology'
        WHEN 5 THEN 'Employment & Skills Support'
        WHEN 6 THEN 'Chaplaincy Pastoral Care'
        WHEN 7 THEN 'Information and Referrals'
    END,
    detail_description = CASE service_id
        WHEN 1 THEN 'Ask Izzy is an Australian directory for finding local accommodation, housing, food, financial, health and community support.'
        WHEN 2 THEN 'The Family Relationship Advice Line provides information, support and referrals about family relationships, parenting and related matters.'
        WHEN 3 THEN 'The NDIS provides information about access, participant plans, supports, providers and local offices.'
        WHEN 4 THEN 'Lifeline Australia provides crisis support by phone, text and online chat. It is not a substitute for emergency services.'
        WHEN 5 THEN 'Workforce Australia provides information about employment services. Eligibility and assistance depend on the person and service.'
        WHEN 6 THEN 'Pastoral, spiritual and chaplaincy support may be available from relevant hospitals, educational institutions and community organisations.'
        WHEN 7 THEN 'Ask Izzy is an Australian directory for searching community services by the type of assistance needed.'
    END,
    overview = CASE service_id
        WHEN 1 THEN 'EXTERNAL REFERRAL ONLY: Search Ask Izzy by location for accommodation, housing, food, financial, health and other community support. Haven House accommodation services have not been verified.'
        WHEN 2 THEN 'EXTERNAL REFERRAL ONLY: The Australian Government Family Relationship Advice Line provides information, support and referrals for parents, grandparents, children, young people, other family members and friends. This is not a confirmed Haven House service.'
        WHEN 3 THEN 'EXTERNAL REFERRAL ONLY: NDIS access is subject to official eligibility requirements. Contact the NDIS for information; this does not establish that Haven House provides NDIS support.'
        WHEN 4 THEN 'EXTERNAL REFERRAL ONLY: Lifeline Australia offers crisis support for people in Australia by phone, text and online chat, 24 hours a day, 7 days a week. This does not establish that Haven House provides counselling or psychology.'
        WHEN 5 THEN 'EXTERNAL REFERRAL ONLY: Workforce Australia can provide information about employment services. Eligibility and available assistance depend on the person and service; this is not a confirmed Haven House service.'
        WHEN 6 THEN 'EXTERNAL REFERRAL ONLY: No single national chaplaincy contact has been identified. Ask a relevant hospital, educational institution or community organisation about local support. Haven House chaplaincy has not been verified.'
        WHEN 7 THEN 'EXTERNAL REFERRAL ONLY: Ask Izzy allows people to search for Australian community services, including housing, financial assistance, counselling, family violence support, health, employment and education. It is not a Haven House service directory.'
    END,
    relevance = CASE service_id
        WHEN 1 THEN 'For people looking for Australian accommodation, housing, food, financial or other local community services.'
        WHEN 2 THEN 'For parents, grandparents, children, young people, family members and friends seeking family relationship information or referrals.'
        WHEN 3 THEN 'For people seeking official information about NDIS access, plans, supports or providers.'
        WHEN 4 THEN 'For people in Australia seeking emotional crisis support from Lifeline.'
        WHEN 5 THEN 'For people seeking information about employment services in Australia.'
        WHEN 6 THEN 'For people seeking pastoral or chaplaincy support through a local organisation.'
        WHEN 7 THEN 'For people looking for Australian community services by type of assistance.'
    END,
    intake_desk_text = CASE service_id
        WHEN 1 THEN 'Search https://askizzy.org.au/. Contact the listed provider directly to confirm current availability, eligibility, hours and costs.'
        WHEN 2 THEN 'Call the Family Relationship Advice Line on 1800 050 321. Confirm current hours and options at https://www.familyrelationships.gov.au/talk-someone/advice-line.'
        WHEN 3 THEN 'Call the NDIS National Contact Centre on 1800 800 110 or visit https://www.ndis.gov.au/.'
        WHEN 4 THEN 'Call Lifeline on 13 11 14, text 0477 13 11 14, or use online support at https://www.lifeline.org.au/131114. For immediate danger call 000.'
        WHEN 5 THEN 'Call Workforce Australia Digital Services Contact Centre on 1800 314 677 or visit https://www.workforceaustralia.gov.au/individuals/contact.'
        WHEN 6 THEN 'Ask the relevant hospital, educational institution, community organisation or service provider about available pastoral support. No Haven House contact has been verified.'
        WHEN 7 THEN 'Search https://askizzy.org.au/ and confirm current details directly with the provider listed.'
    END,
    eligibility_note = CASE service_id
        WHEN 1 THEN 'Eligibility is set by each provider listed on Ask Izzy.'
        WHEN 2 THEN 'The advice line serves parents, grandparents, children, young people, family members and friends.'
        WHEN 3 THEN 'NDIS access is subject to the NDIS official eligibility requirements.'
        WHEN 4 THEN 'Lifeline crisis support is available to people in Australia; call 000 for immediate danger.'
        WHEN 5 THEN 'Eligibility and assistance depend on the person and employment service.'
        WHEN 6 THEN 'Eligibility depends on the organisation providing pastoral or chaplaincy support.'
        WHEN 7 THEN 'Anyone can search public service directories; each listed provider sets its own eligibility.'
    END;

DELETE FROM service_eligibility WHERE service_id BETWEEN 1 AND 7;
INSERT INTO service_eligibility (service_id, criterion, display_order)
VALUES
(1, 'Ask Izzy lists services; each provider sets its own eligibility requirements.', 1),
(2, 'The Advice Line is available to parents, grandparents, children, young people, other family members and friends.', 1),
(3, 'NDIS access is subject to official NDIS eligibility requirements.', 1),
(4, 'Lifeline crisis support is available to people in Australia.', 1),
(5, 'Eligibility and available employment assistance depend on the person and service.', 1),
(6, 'Eligibility depends on the organisation providing pastoral or chaplaincy support.', 1),
(7, 'Anyone can search public directories; individual providers set their own eligibility.', 1);

DELETE FROM service_hours WHERE service_id BETWEEN 1 AND 7;
INSERT INTO service_hours (service_id, day_of_week, opening_time, closing_time, is_closed, notes)
VALUES
(1, NULL, NULL, NULL, FALSE, 'Hours and availability vary by provider. Confirm directly with the service listed on Ask Izzy.'),
(2, NULL, NULL, NULL, FALSE, 'Family Relationship Advice Line: Monday-Friday 8 am-8 pm local time; Saturday 10 am-4 pm local time; closed Sundays and national public holidays. Confirm current hours with the provider.'),
(3, NULL, NULL, NULL, FALSE, 'NDIS National Contact Centre: Monday-Friday 8 am-7 pm local time. Confirm current hours at ndis.gov.au/contact.'),
(4, NULL, NULL, NULL, FALSE, 'Lifeline phone, text and online crisis support is available 24 hours a day, 7 days a week.'),
(5, NULL, NULL, NULL, FALSE, 'Contact Workforce Australia to confirm current availability and service requirements.'),
(6, NULL, NULL, NULL, FALSE, 'Hours vary by provider. Contact the relevant organisation to confirm availability.'),
(7, NULL, NULL, NULL, FALSE, 'Availability varies by provider. Confirm directly with the service listed on Ask Izzy.');

UPDATE faqs SET
    question = CASE id
        WHEN 1 THEN 'Where can I search for accommodation and housing help?'
        WHEN 2 THEN 'How do I find family relationship support?'
        WHEN 3 THEN 'Who can contact the Family Relationship Advice Line?'
        WHEN 4 THEN 'How can I get official NDIS information?'
        WHEN 5 THEN 'Where can I find crisis support or someone to talk to?'
        WHEN 6 THEN 'How do I find employment services?'
        WHEN 7 THEN 'Where can I ask about pastoral or chaplaincy support?'
        WHEN 8 THEN 'Where can I search for community services in Australia?'
    END,
    answer = CASE id
        WHEN 1 THEN 'Search Ask Izzy at https://askizzy.org.au/ for accommodation, housing and local support. Availability, eligibility, hours and costs vary by provider; confirm directly with the listed service.'
        WHEN 2 THEN 'The Australian Government Family Relationship Advice Line provides information, support and referrals. Call 1800 050 321 or visit https://www.familyrelationships.gov.au/talk-someone/advice-line to confirm current details.'
        WHEN 3 THEN 'The Advice Line is available to parents, grandparents, children, young people, other family members and friends. Call 1800 050 321. Published hours are Monday-Friday 8 am-8 pm local time and Saturday 10 am-4 pm local time; closed Sundays and national public holidays.'
        WHEN 4 THEN 'Contact the NDIS on 1800 800 110 or visit https://www.ndis.gov.au/. Access is subject to official NDIS eligibility requirements.'
        WHEN 5 THEN 'Lifeline Australia provides crisis support by phone on 13 11 14, text on 0477 13 11 14, and online chat, 24 hours a day, 7 days a week. For immediate danger in Australia, call 000.'
        WHEN 6 THEN 'Workforce Australia provides information about employment services. Contact 1800 314 677 or visit https://www.workforceaustralia.gov.au/individuals/contact to confirm current assistance and requirements.'
        WHEN 7 THEN 'Availability varies by provider. Contact the relevant hospital, educational institution or community organisation to ask about pastoral or chaplaincy support. No Haven House contact has been verified.'
        WHEN 8 THEN 'Search Ask Izzy at https://askizzy.org.au/ for Australian community services. Availability and eligibility vary by provider; confirm current details directly.'
    END
WHERE id BETWEEN 1 AND 8;
