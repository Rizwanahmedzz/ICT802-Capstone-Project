-- ====================================================================
-- HAVEN HOUSE — DATABASE VALIDATION & TEST QUERIES
-- Run these queries to verify schema integrity, relationships, and seed data.
-- ====================================================================

USE haven_house;

-- 1. VERIFY ALL 10 TABLES EXIST
SELECT 
    table_name AS 'Table Name',
    table_rows AS 'Estimated Rows',
    create_time AS 'Created At'
FROM information_schema.tables 
WHERE table_schema = 'haven_house'
ORDER BY table_name;

-- 2. VERIFY ORGANIZATION RECORD
SELECT id, name, tagline, location, established_period, disclaimer 
FROM organization;

-- 3. VERIFY ALL 7 SEEDED SERVICES
SELECT id, service_key, title, card_title, badge, icon_name, is_active, display_order 
FROM services 
ORDER BY display_order ASC;

-- 4. JOIN TEST: SERVICES WITH 1:1 SERVICE DETAILS
SELECT 
    s.id AS service_id,
    s.title AS service_title,
    sd.detail_title,
    sd.relevance,
    LEFT(sd.overview, 60) AS overview_snippet,
    sd.eligibility_note
FROM services s
INNER JOIN service_details sd ON s.id = sd.service_id
ORDER BY s.display_order ASC;

-- 5. JOIN TEST: SERVICES WITH 1:M ELIGIBILITY CRITERIA
SELECT 
    s.title AS service_title,
    se.display_order,
    se.criterion
FROM services s
INNER JOIN service_eligibility se ON s.id = se.service_id
ORDER BY s.display_order ASC, se.display_order ASC;

-- 6. JOIN TEST: SERVICES WITH OPERATIONAL HOURS & NOTES
SELECT 
    s.title AS service_title,
    sh.notes AS schedule_notes
FROM services s
LEFT JOIN service_hours sh ON s.id = sh.service_id
ORDER BY s.display_order ASC;

-- 7. VERIFY FAQS
SELECT id, question, category, display_order, is_active 
FROM faqs 
ORDER BY display_order ASC;

-- 8. TEST FAQ FEEDBACK INSERT & JOIN
-- Insert a test feedback response
INSERT INTO faq_feedback (faq_id, response) VALUES (1, 'YES');
INSERT INTO faq_feedback (faq_id, response) VALUES (1, 'NO');

-- Retrieve aggregated FAQ feedback
SELECT 
    f.id AS faq_id,
    f.question,
    SUM(CASE WHEN fb.response = 'YES' THEN 1 ELSE 0 END) AS helpful_yes_count,
    SUM(CASE WHEN fb.response = 'NO' THEN 1 ELSE 0 END) AS helpful_no_count
FROM faqs f
LEFT JOIN faq_feedback fb ON f.id = fb.faq_id
GROUP BY f.id, f.question
ORDER BY f.display_order ASC;

-- Clean up test feedback row if needed
-- DELETE FROM faq_feedback WHERE faq_id = 1;

-- 9. VERIFY KNOWLEDGE CONTENT APPROVAL STATUSES
SELECT 
    id,
    content_type,
    reference_id,
    approval_status,
    version,
    is_active,
    LEFT(content_text, 50) AS content_snippet
FROM knowledge_content
ORDER BY content_type, reference_id;

-- 10. VERIFY USERS & AUDIT LOG SCHEMA INTEGRITY
DESCRIBE users;
DESCRIBE audit_log;

-- Test insert and FK link on audit log
INSERT INTO audit_log (user_id, action, entity_type, entity_id, description)
VALUES (NULL, 'SYSTEM_INIT', 'DATABASE', 1, 'Initial Haven House database seed verified.');

SELECT id, user_id, action, entity_type, entity_id, description, created_at 
FROM audit_log;
