# Haven House — Database Documentation

## 1. Database Overview
- **Database Name:** `haven_house`
- **Target Engine:** MySQL 8.x (InnoDB, utf8mb4)
- **Purpose:** Centralized, normalized relational database foundation supporting Haven House's crisis support service navigation assistant, approved knowledge management, and future Flask/Python API integrations.

---

## 2. Table Structure & Descriptions

The database comprises **11 distinct tables**:

| Table Name | Purpose | Relationships |
| :--- | :--- | :--- |
| `organization` | Central metadata for Haven House (Bondi, Sydney, established 1980s, disclaimer). | Standalone |
| `services` | Core categories (Accommodation, HH Kids, NDIS, Psychology, Employment, Chaplaincy, General Info). | Parent to `service_details`, `service_eligibility`, `service_hours` |
| `service_details` | Detailed 1:1 service descriptions, overview, relevance statement, and intake desk guidance. | `FOREIGN KEY (service_id) REFERENCES services(id)` (1:1) |
| `service_eligibility`| Normalized individual eligibility criteria per service (one-to-many). | `FOREIGN KEY (service_id) REFERENCES services(id)` (1:M) |
| `service_hours` | Structured operating hours and operational notes (e.g. 24/7 intake assessment). | `FOREIGN KEY (service_id) REFERENCES services(id)` (1:M) |
| `faqs` | Frequently asked questions and approved answers with display order. | Parent to `faq_feedback` |
| `faq_feedback` | Aggregates user feedback (`YES` / `NO`) on FAQ usefulness without storing PII. | `FOREIGN KEY (faq_id) REFERENCES faqs(id)` (1:M) |
| `knowledge_content`| Content management tracking approval status (`PENDING`, `APPROVED`, `REJECTED`) for strict client sign-off. | Standalone reference tracking |
| `users` | Secure user authentication foundation (hashes only, prepared for future auth stages). | Parent to `audit_log` |
| `audit_log` | Non-sensitive system and compliance event logs (action, entity type, entity ID). | `FOREIGN KEY (user_id) REFERENCES users(id)` |
| `appointments` | Sign-in-protected prototype reservations using a temporary weekday schedule; not real Haven House bookings. | `FOREIGN KEY (user_id) REFERENCES users(id)` |

---

## 3. Entity Relationships Diagram

```
organization (Haven House metadata & disclaimers)

services
   ├── 1:1 ── service_details
   ├── 1:M ── service_eligibility
   └── 1:M ── service_hours

faqs
   └── 1:M ── faq_feedback

knowledge_content (Tracks PENDING / APPROVED lifecycle)

users
   └── 1:M ── audit_log
   └── 1:M ── appointments
```

---

## 4. Setup & Execution Instructions

### Windows / XAMPP (recommended)
1. Start **MySQL** in the XAMPP Control Panel.
2. From the project folder, run `setup_database.bat`.
3. Confirm the prompt to create the schema and load demo data.

The script reads the SQL files as UTF-8 and connects using the backend's `.env`/default database settings. The seed step truncates and replaces existing Haven House data, including users, feedback, and OTP challenges; do not confirm if you need to preserve existing records.

The appointment feature uses the `appointments` table from `database/schema.sql`. If your database already exists, apply that table definition separately; do not rerun the destructive seed just to add it. Appointment slots currently use a clearly labeled temporary demo schedule and do not contact Haven House staff.

If the Python MySQL connector is missing, install the backend dependencies once:
```bash
py -3 -m pip install -r backend/requirements.txt
```

### A. Create the Database & Tables
Run the schema script using a UTF-8 client so characters like em-dashes are preserved correctly:
```bash
mysql --default-character-set=utf8mb4 -u your_username -p < database/schema.sql
```

### B. Seed Initial Approved Knowledge & Categories
Run the seed script with the same UTF-8 setting:
```bash
mysql --default-character-set=utf8mb4 -u your_username -p haven_house < database/seed.sql
```

Note: On Windows/XAMPP, using the default command-prompt encoding can produce mojibake such as `DEMO ÔÇö Example...`. Keep the MySQL client in UTF-8 mode or insert data through a UTF-8-safe Python/MySQL connection when reloading the demo data.

### C. Run Validation & Test Queries
Verify table counts, foreign keys, and JOIN relationships:
```bash
mysql -u your_username -p haven_house < database/test_queries.sql
```

---

## 5. Development Database Reset

To reset the database cleanly to its initial seed state during development:
```bash
mysql -u your_username -p -e "DROP DATABASE IF EXISTS haven_house;"
mysql -u your_username -p < database/schema.sql
mysql -u your_username -p haven_house < database/seed.sql
```

---

## 6. Privacy, Security & Safety Principles

1. **No Sensitive Crisis Data Stored:** The assistant navigates and does not counsel. Crisis chats and emergency handoffs are not logged into the database.
2. **Strict Client Sign-Off:** Knowledge records are explicitly initialized with `PENDING` approval status until client review is finalized.
3. **No Plaintext Passwords:** The `users` table is provisioned with `password_hash` fields only for future authentication phases.
4. **Placeholder Contact Information:** Contact details use clearly marked placeholders (e.g., `[Haven House approved 24/7 crisis number...]`) to prevent accidental presentation of unapproved numbers as real.
