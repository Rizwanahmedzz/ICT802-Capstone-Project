USE haven_house;

ALTER TABLE appointments
  ADD COLUMN service_title VARCHAR(100) NULL AFTER guest_contact;
