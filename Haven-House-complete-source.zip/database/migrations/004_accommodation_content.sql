USE haven_house;

UPDATE services SET badge = 'Accommodation support',
  description = 'Our accommodation support helps residents understand their housing options and connect with the appropriate Haven team. Support may include information about residences, accommodation pathways and assistance with housing-related enquiries.'
WHERE id = 1;

UPDATE service_details SET
  detail_description = 'Haven provides accommodation-focused support designed to help residents maintain safe, stable and independent housing.',
  overview = 'Our accommodation support helps residents understand their housing options and connect with the appropriate Haven team. Support may include: information about available residences; assistance with understanding accommodation options; support with resident enquiries; guidance on available housing pathways; connection with the appropriate Haven team; and assistance with accommodation-related enquiries.',
  relevance = 'For people who need help understanding their housing options and the next steps.',
  intake_desk_text = 'Need help with accommodation? Contact the Haven team for information about available residences, housing enquiries and the appropriate next steps.',
  eligibility_note = 'Eligibility requirements may vary depending on the residence and type of housing available. If you are interested in accommodation, please contact the Haven team to discuss your circumstances and available options.'
WHERE service_id = 1;

UPDATE service_eligibility SET
  criterion = 'Eligibility depends on the specific accommodation or housing pathway. Please contact the Haven team to discuss your circumstances.'
WHERE service_id = 1;

UPDATE service_hours SET
  notes = 'Our team is available during standard business hours. Contact us and our team will assist with your enquiry.'
WHERE service_id = 1;
