-- ====================================================================
-- Haven House — Database Migration 001
-- Stage 2: Create otp_challenges table for Two-Layer Authentication
-- ====================================================================

CREATE TABLE IF NOT EXISTS otp_challenges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    challenge_id VARCHAR(64) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    purpose VARCHAR(50) NOT NULL DEFAULT 'LOGIN_2FA',
    otp_hash VARCHAR(255) NOT NULL,
    delivery_method ENUM('EMAIL', 'SMS') NOT NULL DEFAULT 'EMAIL',
    destination VARCHAR(255) NOT NULL,
    attempt_count INT NOT NULL DEFAULT 0,
    max_attempts INT NOT NULL DEFAULT 5,
    expires_at DATETIME NOT NULL,
    verified_at DATETIME NULL,
    used_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_otp_user FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_otp_challenge_id (challenge_id),
    INDEX idx_otp_user_purpose (user_id, purpose),
    INDEX idx_otp_expires_at (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
