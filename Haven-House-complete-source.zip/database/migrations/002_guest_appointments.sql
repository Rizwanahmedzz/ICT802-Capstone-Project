USE haven_house;

ALTER TABLE appointments
  MODIFY user_id INT NULL,
  ADD COLUMN guest_name VARCHAR(120) NULL AFTER user_id,
  ADD COLUMN guest_contact VARCHAR(190) NULL AFTER guest_name;
