import os
from dotenv import load_dotenv

# Load this project's environment variables.  Use the project configuration in
# preference to inherited shell variables so a stale system-level API key cannot
# silently override the key configured for this backend.
load_dotenv(override=True)

class Config:
    # Environment Mode
    ENV = os.getenv("FLASK_ENV", "development").lower()
    DEBUG = os.getenv("FLASK_DEBUG", "True").lower() in ("true", "1", "t")

    # Database Configuration
    DB_HOST = os.getenv("DB_HOST", "localhost")
    DB_PORT = int(os.getenv("DB_PORT", 3306))
    DB_NAME = os.getenv("DB_NAME", "haven_house")
    DB_USER = os.getenv("DB_USER", "root")
    DB_PASSWORD = os.getenv("DB_PASSWORD", "")
    
    # Connection Pool Settings
    DB_POOL_NAME = "haven_house_pool"
    DB_POOL_SIZE = int(os.getenv("DB_POOL_SIZE", 5))

    # JWT Authentication Configuration
    DEV_FALLBACK_SECRET = "haven-house-dev-secret-key-change-in-production-min-32-chars"
    JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", DEV_FALLBACK_SECRET)
    JWT_EXPIRATION_HOURS = int(os.getenv("JWT_EXPIRATION_HOURS", 1))

    # Admin sign-in: username + passcode only (no email verification)
    ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
    ADMIN_PASSCODE = os.getenv("ADMIN_PASSCODE", "")

    # Stage 2: Two-Layer Authentication / OTP Configuration
    OTP_EXPIRATION_MINUTES = int(os.getenv("OTP_EXPIRATION_MINUTES", 5))
    OTP_MAX_ATTEMPTS = int(os.getenv("OTP_MAX_ATTEMPTS", 5))
    OTP_RESEND_COOLDOWN_SECONDS = int(os.getenv("OTP_RESEND_COOLDOWN_SECONDS", 60))
    OTP_MAX_REQUESTS = int(os.getenv("OTP_MAX_REQUESTS", 3))
    OTP_DEMO_MODE = os.getenv("OTP_DEMO_MODE", "True").lower() in ("true", "1", "t")
    OTP_DELIVERY_METHOD = os.getenv("OTP_DELIVERY_METHOD", "EMAIL").upper()

    # Email / SMTP Configuration
    SMTP_HOST = os.getenv("SMTP_HOST", "smtp.example.com")
    SMTP_PORT = int(os.getenv("SMTP_PORT", 587))
    SMTP_USERNAME = os.getenv("SMTP_USERNAME", "")
    SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
    OTP_FROM_EMAIL = os.getenv("OTP_FROM_EMAIL", "no-reply@havenhouse.org.au")

    # SMS Provider Configuration
    SMS_PROVIDER = os.getenv("SMS_PROVIDER", "MOCK")
    SMS_ACCOUNT_ID = os.getenv("SMS_ACCOUNT_ID", "")
    SMS_AUTH_TOKEN = os.getenv("SMS_AUTH_TOKEN", "")
    SMS_FROM_NUMBER = os.getenv("SMS_FROM_NUMBER", "")

    # Server Configuration (Port 5001 avoids macOS AirPlay collision on port 5000)
    PORT = int(os.getenv("PORT", 5001))

    # OpenAI Assistant Configuration
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

    # CORS Settings (Explicit allowed origins only, no wildcard)
    CORS_ORIGINS = os.getenv(
        "CORS_ORIGINS", 
        "http://localhost,http://127.0.0.1,http://localhost:3000,http://localhost:8080,http://127.0.0.1:5500,http://localhost:5500,http://127.0.0.1:8080,http://127.0.0.1:3000"
    ).split(",")

    @classmethod
    def validate_production_security(cls):
        """
        Validates critical security configuration before server boot in production.
        Prevents insecure defaults or fallback secrets from running in production.
        """
        is_production = cls.ENV == "production" or not cls.DEBUG
        
        if is_production:
            if not cls.JWT_SECRET_KEY or cls.JWT_SECRET_KEY == cls.DEV_FALLBACK_SECRET:
                raise RuntimeError(
                    "FATAL SECURITY CONFIGURATION ERROR: A strong custom JWT_SECRET_KEY "
                    "is strictly required in production mode. Default development secrets are forbidden."
                )
            if len(cls.JWT_SECRET_KEY) < 32:
                raise RuntimeError(
                    "FATAL SECURITY CONFIGURATION ERROR: JWT_SECRET_KEY must be at least "
                    "32 characters long in production mode."
                )
