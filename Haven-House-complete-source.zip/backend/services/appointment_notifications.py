import logging
import smtplib
from email.mime.text import MIMEText

from backend.config import Config
from backend.services.otp_delivery import mask_destination

logger = logging.getLogger(__name__)


def send_appointment_confirmation(destination: str, starts_at) -> bool:
    if not Config.SMTP_HOST or not Config.SMTP_USERNAME or not Config.SMTP_PASSWORD:
        logger.error("[Appointment Email Error] SMTP is not configured.")
        return False

    appointment_time = (
        starts_at.strftime("%A, %B ")
        + str(starts_at.day)
        + starts_at.strftime(", %Y at %I:%M %p").replace(" at 0", " at ", 1)
    )
    message = MIMEText(
        "Your reservation has been recorded for "
        f"{appointment_time}.\n\n"
        "Please note: This is not an official Haven House appointment. "
        "The schedule is temporary and has not been confirmed by Haven House. "
        "Haven House staff have not been notified.\n\n"
        "Haven House Crisis Support Services\n"
        "Bondi, Sydney",
        "plain"
    )
    message["From"] = Config.OTP_FROM_EMAIL
    message["To"] = destination
    message["Subject"] = "Haven House — Reservation Confirmation"

    try:
        with smtplib.SMTP(Config.SMTP_HOST, Config.SMTP_PORT, timeout=10) as server:
            server.starttls()
            server.login(Config.SMTP_USERNAME, Config.SMTP_PASSWORD)
            server.send_message(message)
        logger.info("[Appointment Email Sent] Confirmation sent to %s", mask_destination(destination))
        return True
    except Exception as error:
        logger.error(
            "[Appointment Email Error] Could not send confirmation to %s: %s",
            mask_destination(destination),
            type(error).__name__
        )
        return False
