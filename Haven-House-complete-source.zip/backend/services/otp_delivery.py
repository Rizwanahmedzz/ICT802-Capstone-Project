import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from backend.config import Config

logger = logging.getLogger(__name__)


def mask_destination(destination: str, method: str = "EMAIL") -> str:
    """
    Safely masks email or phone destination for client privacy.
    Examples:
      - 'jane.doe@example.com' -> 'j***e@example.com'
      - '+61412345678' -> '******5678'
    """
    if not destination:
        return "******"

    dest = destination.strip()
    if method.upper() == "EMAIL" or "@" in dest:
        parts = dest.split("@")
        if len(parts) != 2:
            return "***@***"
        local, domain = parts[0], parts[1]
        if len(local) <= 2:
            masked_local = local[0] + "***"
        else:
            masked_local = local[0] + "***" + local[-1]
        return f"{masked_local}@{domain}"
    else:
        # Phone masking
        if len(dest) > 4:
            return "*" * (len(dest) - 4) + dest[-4:]
        return "****"


def deliver_otp(destination: str, method: str, otp_code: str, purpose: str = "verification") -> bool:
    """
    Delivers OTP code through configured email or SMS provider.
    Supports clean development demo mode when external SMTP/SMS infrastructure is not configured.
    """
    method = (method or "EMAIL").upper()
    masked_dest = mask_destination(destination, method)

    # 1. Safe Demo / Development Mode
    if Config.OTP_DEMO_MODE:
        logger.info(
            f"[OTP Service - DEVELOPMENT ONLY] Verification challenge generated for destination: {masked_dest} (Method: {method})"
        )
        return True

    # 2. Production Email (SMTP) Delivery
    if method == "EMAIL":
        try:
            if not Config.SMTP_HOST or not Config.SMTP_USERNAME:
                logger.error("[OTP Delivery Error] SMTP is not configured in production mode.")
                return False

            msg = MIMEMultipart()
            msg["From"] = Config.OTP_FROM_EMAIL
            msg["To"] = destination
            is_password_reset = purpose == "password reset"
            msg["Subject"] = (
                "Haven House — Password Reset Code"
                if is_password_reset
                else "Haven House — Your Verification Code"
            )

            code_description = "password reset code" if is_password_reset else "verification code"
            body = (
                f"Hello,\n\n"
                f"Your Haven House {code_description} is: {otp_code}\n\n"
                f"This code will expire in {Config.OTP_EXPIRATION_MINUTES} minutes.\n"
                f"If you did not request this code, please disregard this email or contact the Haven House team.\n\n"
                f"Haven House Crisis Support Services\n"
                f"Bondi, Sydney"
            )
            msg.attach(MIMEText(body, "plain"))

            with smtplib.SMTP(Config.SMTP_HOST, Config.SMTP_PORT, timeout=10) as server:
                server.starttls()
                server.login(Config.SMTP_USERNAME, Config.SMTP_PASSWORD)
                server.send_message(msg)

            logger.info(f"[OTP Email Sent] Verification code dispatched to {masked_dest}")
            return True

        except Exception as e:
            logger.error(f"[OTP Delivery Exception] SMTP delivery failed to {masked_dest}: {e}")
            return False

    # 3. Production SMS Delivery
    elif method == "SMS":
        try:
            # Pluggable SMS provider interface (e.g. Twilio, AWS SNS, MessageMedia)
            logger.info(f"[OTP SMS Placeholder] Production SMS provider dispatched to {masked_dest}")
            return True
        except Exception as e:
            logger.error(f"[OTP Delivery Exception] SMS delivery failed to {masked_dest}: {e}")
            return False

    return False
