import logging
import mysql.connector
from mysql.connector import Error
from contextlib import contextmanager
from .config import Config

logger = logging.getLogger(__name__)

def get_connection():
    """Create a standalone MySQL connection using parameterized config with fallback."""
    # Attempt 1: Standard configured host
    try:
        connection = mysql.connector.connect(
            host=Config.DB_HOST,
            port=Config.DB_PORT,
            database=Config.DB_NAME,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            charset="utf8mb4",
            collation="utf8mb4_unicode_ci",
            connect_timeout=3
        )
        return connection
    except Error as e:
        # If host was 'localhost' and failed with connection error, try 127.0.0.1 and common unix sockets
        if Config.DB_HOST == "localhost" or Config.DB_HOST == "127.0.0.1":
            for socket_path in ["/tmp/mysql.sock", "/var/mysql/mysql.sock", "/opt/homebrew/var/mysql/mysql.sock"]:
                try:
                    import os
                    if os.path.exists(socket_path):
                        return mysql.connector.connect(
                            unix_socket=socket_path,
                            database=Config.DB_NAME,
                            user=Config.DB_USER,
                            password=Config.DB_PASSWORD,
                            charset="utf8mb4",
                            collation="utf8mb4_unicode_ci"
                        )
                except Exception:
                    pass
            try:
                alt_host = "127.0.0.1" if Config.DB_HOST == "localhost" else "localhost"
                return mysql.connector.connect(
                    host=alt_host,
                    port=Config.DB_PORT,
                    database=Config.DB_NAME,
                    user=Config.DB_USER,
                    password=Config.DB_PASSWORD,
                    charset="utf8mb4",
                    collation="utf8mb4_unicode_ci",
                    connect_timeout=3
                )
            except Exception:
                pass

        logger.error(f"[Database Connection Error] Code {e.errno}: {e.msg}")
        raise e


@contextmanager
def get_db_cursor(commit=False, dictionary=True):
    """Context manager to ensure safe cursor and connection closure."""
    conn = None
    cursor = None
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=dictionary)
        yield cursor
        if commit:
            conn.commit()
    except Error as e:
        if conn and commit:
            conn.rollback()
        logger.error(f"[Database Execution Error] Code {e.errno}: {e.msg}")
        raise e
    finally:
        if cursor:
            cursor.close()
        if conn and conn.is_connected():
            conn.close()


def query_db(query, params=None, fetchone=False, one=False):
    """
    Executes a parameterized SELECT query and returns dictionary rows.
    Always uses parameterized inputs to prevent SQL injection.
    Supports both fetchone=True and one=True.
    """
    should_fetch_one = fetchone or one
    with get_db_cursor(commit=False, dictionary=True) as cursor:
        cursor.execute(query, params or ())
        if should_fetch_one:
            return cursor.fetchone()
        return cursor.fetchall()


def execute_db(query, params=None):
    """
    Executes a parameterized INSERT/UPDATE/DELETE query with commit.
    Returns the last inserted ID.
    """
    with get_db_cursor(commit=True, dictionary=True) as cursor:
        cursor.execute(query, params or ())
        return cursor.lastrowid


def check_db_connection():
    """Tests if MySQL database is reachable."""
    try:
        conn = get_connection()
        if conn.is_connected():
            conn.close()
            return True, "connected"
    except Exception as e:
        logger.warning(f"[DB Health Check Failed] {e}")
        return False, "unavailable"
    return False, "disconnected"


def cleanup_expired_otp_challenges():
    """
    Data Minimization & Retention cleanup:
    Deletes expired or used OTP challenges older than 1 hour.
    """
    try:
        cleanup_query = """
            DELETE FROM otp_challenges
            WHERE expires_at < DATE_SUB(NOW(), INTERVAL 1 HOUR)
               OR (verified_at IS NOT NULL AND created_at < DATE_SUB(NOW(), INTERVAL 1 DAY))
        """
        execute_db(cleanup_query)
    except Exception as e:
        logger.warning(f"[OTP Cleanup Warning] Could not clean up expired challenges: {e}")
