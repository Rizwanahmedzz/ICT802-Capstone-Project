# Haven House — Service Navigation Assistant Backend API

This backend provides a secure, modular REST API connecting the Haven House Service Navigation Assistant frontend to the `haven_house` MySQL database with Stage 3 Security & Privacy Hardening.

---

## 1. Five Security & Privacy Hardening Features

### FEATURE 1: Centralized Input Validation & Sanitization
- **Utility:** [`backend/utils/validation.py`](file:///Users/neelpatel/Desktop/Haven_House/backend/utils/validation.py)
- **Rules:**
  - Strict type checking and boundary enforcement (Names $\le$ 150 chars, Passwords 8–128 chars, OTPs exactly 6 numeric digits, Challenge IDs 20–80 alphanumeric chars, Feedback `'YES'`/`'NO'`).
  - Assistant user messages capped at 2,000 characters without destructive transformation to preserve emergency safety intent detection.
  - Payload size cap (`MAX_CONTENT_LENGTH = 1 MB`) returning `413 Request Entity Too Large` on oversized requests.
  - Parameterized SQL across all queries to prevent SQL injection.
  - Safe HTML escaping (`sanitize_text()`) to eliminate XSS vectors.

### FEATURE 2: HTTP Security Headers
- **Utility:** [`backend/utils/security_headers.py`](file:///Users/neelpatel/Desktop/Haven_House/backend/utils/security_headers.py)
- **Active Response Headers:**
  - `Content-Security-Policy`: Restricts scripts, styles, fonts, and connects to authorized self/local sources while allowing embeddable widget framing from trusted local hosts.
  - `X-Content-Type-Options: nosniff`: Prevents MIME-type confusion attacks.
  - `X-Frame-Options: SAMEORIGIN`: Protects core application views against clickjacking.
  - `Referrer-Policy: strict-origin-when-cross-origin`: Minimizes referrer leakage.
  - `Permissions-Policy: geolocation=(), microphone=(), camera=(), payment=()`: Disables unused browser hardware capabilities.
  - `Cache-Control: no-store, no-cache, must-revalidate, max-age=0`: Prevents browser/proxy caching of dynamic API and authentication responses.

### FEATURE 3: CSRF / CORS Protection for Bearer JWT Architecture
- **Bearer Token Architecture:** Authentication utilizes `Authorization: Bearer <token>` in `fetch` headers rather than ambient cookies. Since browsers never automatically attach custom authorization headers to cross-origin requests, traditional cross-site request forgery (CSRF) is naturally mitigated.
- **CORS Hardening:** Configured in `backend/app.py` via `CORS_ORIGINS` with explicit allowed origins, methods (`GET, POST, OPTIONS`), and allowed headers (`Content-Type, Authorization`). Wildcard origin `*` with credentials is explicitly forbidden.

### FEATURE 4: Privacy & Data Minimization
- **No Plaintext Passwords or OTPs:** Werkzeug PBKDF2-SHA256 password and OTP hashing.
- **Crisis Data Privacy:** Crisis and emergency conversation text is **strictly non-persistent**. When the server-side safety guardrail is triggered, only a minimal anonymized event (`SAFETY_HANDOFF_TRIGGERED`) is recorded in `audit_log` with `user_id = NULL` and zero crisis text.
- **Data Retention & Stale Challenge Cleanup:** `cleanup_expired_otp_challenges()` automatically purges expired OTP challenges older than 1 hour.
- **Destination Masking:** Email and phone destinations are masked (`j***e@example.com`, `******5678`) in client-facing responses.

### FEATURE 5: Security Audit Logging & Event Monitoring
- **Centralized Audit Log:** Recorded in `audit_log` table:
  - `USER_REGISTERED`
  - `LOGIN_SUCCESS`
  - `LOGIN_FAILED`
  - `OTP_REQUESTED`
  - `OTP_VERIFICATION_SUCCESS`
  - `OTP_VERIFICATION_FAILED`
  - `OTP_EXPIRED`
  - `OTP_LOCKED`
  - `PASSWORD_RESET_REQUESTED`
  - `PASSWORD_RESET_FAILED`
  - `PASSWORD_RESET`
  - `LOGOUT`
  - `SAFETY_HANDOFF_TRIGGERED`
  - `RATE_LIMIT_TRIGGERED`
  - `FAQ_FEEDBACK_SUBMITTED`
- **Abuse Throttling:** Sliding window in-memory rate limiter per IP/identifier, including password-reset requests and confirmations.

---

## 2. API Endpoints Overview

All endpoints start with `/api`:

### Public Endpoints (No Authentication Required)
| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/health` | Health check & MySQL connection verification |
| `POST` | `/api/assistant` | Service Navigation Assistant endpoint (approved DB matching & safety handoff) |
| `GET` | `/api/organization` | Organization info & safe navigation disclaimer |
| `GET` | `/api/services` | Active services sorted by display order |
| `GET` | `/api/services/<id_or_key>` | Composite service info + details + eligibility + hours |
| `GET` | `/api/services/<id_or_key>/eligibility` | Service eligibility criteria list |
| `GET` | `/api/services/<id_or_key>/hours` | Service operating hours & operational notes |
| `GET` | `/api/faqs` | Active FAQs sorted by display order |
| `GET` | `/api/faqs/<id>` | Single FAQ record |
| `POST` | `/api/faqs/<id>/feedback` | Submit usefulness feedback (`YES` or `NO`) |
| `GET` | `/api/knowledge` | Approved & active knowledge base items only |
| `GET` | `/api/knowledge/service/<id>` | Approved knowledge items for a specific service |

### Two-Layer Authentication Endpoints
| Method | Endpoint | Auth Required | Description |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/auth/register` | No | Registers new user with PBKDF2 hashed password |
| `POST` | `/api/auth/login` | No | **Layer 1:** Verifies password and creates temporary OTP challenge. Returns `challenge_id` (Zero JWT). |
| `POST` | `/api/auth/request-otp` | No | Resends/refreshes OTP code with cooldown and rate limit checks. |
| `POST` | `/api/auth/verify-otp` | No | **Layer 2:** Verifies 6-digit OTP code against PBKDF2 hash. **Only now issues final JWT.** |
| `GET` | `/api/auth/me` | Yes (`Bearer <token>`) | Returns profile of currently authenticated user |
| `POST` | `/api/auth/logout` | No / Optional Bearer | Records logout audit event; client clears token |

---

### Prototype Appointment Endpoints (Authentication Required)
| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/appointments/availability?date=YYYY-MM-DD` | Lists unreserved weekday prototype times from 9:00 am to 5:00 pm in 30-minute increments |
| `POST` | `/api/appointments` | Reserves one available prototype time, sends a confirmation email when SMTP is available; duplicate reservations return `409` |
| `GET` | `/api/appointments/mine` | Lists the signed-in user's prototype reservations |

These reservations are not official Haven House bookings and do not notify staff. Confirmation emails state this clearly. The temporary schedule must not be presented as verified service availability.

### Password Recovery Endpoints
| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `POST` | `/api/auth/password-reset/request` | Sends a reset code to the email for an active account; response does not reveal whether the account exists |
| `POST` | `/api/auth/password-reset/confirm` | Verifies the one-time code and replaces the password hash |

Password reset codes expire using the configured OTP lifetime, are single-use, and are protected by attempt limits. The new password is never stored in plaintext.

### Admin Panel
The private `#/admin` panel provides appointment totals, a six-month appointment chart, notification review, appointment management, a monthly calendar with date-filtered time-slot management, service editing, public event and announcement publishing, contact-enquiry management, existing-account role management, reports, public site settings, and an administrator activity log. Appointment records do not currently contain a service-category ID, so service-popularity reporting is intentionally not inferred. Admin endpoints verify the current database role; changing browser storage or a JWT role claim does not grant access. Public visitors only receive published events and announcements and settings explicitly marked public.

Login already requires password plus OTP, login attempts are rate limited, and sensitive admin actions are recorded in the activity log. The browser automatically signs an administrator out after 15 minutes without activity; this client-side idle sign-out does not replace the server's JWT expiration or database-role checks.

Apply the additive CMS migration before using the new admin sections:

```bash
python -m backend.migrate_admin_cms
```

This creates missing CMS tables and adds the service-detail columns without executing `database/seed.sql` or replacing existing account and service data. The contact form stores submitted name, email, subject and message in `contact_enquiries`; only authorized administrators can review them. Avoid collecting sensitive personal details.

Staff permissions can be assigned to existing active accounts in the panel. Public self-registration cannot grant administrator privileges. The system prevents an administrator from removing their own access or demoting the last active administrator.

To grant administrator access to a trusted account, run this in phpMyAdmin's SQL tab after selecting the `haven_house` database, replacing the email with the account that should be an administrator:

```sql
UPDATE users
SET role = 'admin'
WHERE email = 'your-account-email@example.com';
```

The administrator must sign out and sign in again for the updated role to appear in the session. Grant this role only to trusted operators; the panel displays account email addresses.

## 3. Running the Project Locally

1. **Configure Environment:**
   ```bash
   copy .env.example .env
   ```
   Add your OpenAI API key to `OPENAI_API_KEY` in `.env` to enable AI chatbot replies. The key is read only by the backend and must never be placed in frontend code. `OPENAI_MODEL` defaults to `gpt-4o-mini`.
   For Gmail OTP delivery, create a Google App Password with 2-Step Verification enabled, then set `OTP_DEMO_MODE=False`, `SMTP_HOST=smtp.gmail.com`, `SMTP_PORT=587`, and fill in `SMTP_USERNAME`, `SMTP_PASSWORD`, and `OTP_FROM_EMAIL` in `.env`. Use the App Password, not your regular Gmail password. Keep `.env` private; it is excluded by `.gitignore`.
2. **Start Backend API:**
   ```bash
   python3 -m backend.app
   ```
3. **Start Frontend Web Server:**
   ```bash
   python3 -m http.server 8080
   ```
4. **Access the Application:**
   Open `http://localhost:8080/#/home` in any modern web browser. For XAMPP, open the site via `http://localhost/<project-folder>/` and keep the Flask backend running on port `5001`.

Register an account through the app before signing in. Login requires the password and a six-digit code delivered to the registered email address. Restart the backend after changing `.env`.
