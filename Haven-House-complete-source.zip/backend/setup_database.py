import sys
from pathlib import Path

import mysql.connector

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.config import Config


SQL_FILES = (
    ROOT / "database" / "schema.sql",
    ROOT / "database" / "seed.sql",
)


def iter_sql_statements(script):
    """Split SQL on semicolons while preserving quoted values and skipping comments."""
    statement = []
    quote = None
    in_block_comment = False
    index = 0

    while index < len(script):
        char = script[index]
        next_char = script[index + 1] if index + 1 < len(script) else ""

        if in_block_comment:
            if char == "*" and next_char == "/":
                in_block_comment = False
                statement.append(" ")
                index += 2
                continue
        elif quote:
            statement.append(char)
            if char == "\\" and next_char:
                statement.append(next_char)
                index += 2
                continue
            if char == quote:
                if next_char == quote:
                    statement.append(next_char)
                    index += 2
                    continue
                quote = None
        elif char in ("'", '"', "`"):
            quote = char
            statement.append(char)
        elif char == "/" and next_char == "*":
            in_block_comment = True
            statement.append(" ")
            index += 2
            continue
        elif char == "#" or (
            char == "-"
            and next_char == "-"
            and (index + 2 == len(script) or script[index + 2].isspace())
        ):
            newline = script.find("\n", index)
            if newline == -1:
                break
            statement.append(" ")
            index = newline + 1
            continue
        elif char == ";":
            sql = "".join(statement).strip()
            if sql:
                yield sql
            statement.clear()
        else:
            statement.append(char)

        index += 1

    sql = "".join(statement).strip()
    if sql:
        yield sql


def run():
    print(f"Connecting to MySQL at {Config.DB_HOST}:{Config.DB_PORT} as {Config.DB_USER}...")
    connection = mysql.connector.connect(
        host=Config.DB_HOST,
        port=Config.DB_PORT,
        user=Config.DB_USER,
        password=Config.DB_PASSWORD,
        charset="utf8mb4",
        collation="utf8mb4_unicode_ci",
        connect_timeout=5,
    )

    try:
        cursor = connection.cursor()
        for sql_file in SQL_FILES:
            print(f"Running {sql_file.relative_to(ROOT)}...")
            script = sql_file.read_text(encoding="utf-8")
            for statement in iter_sql_statements(script):
                cursor.execute(statement)
        cursor.close()
    finally:
        connection.close()

    print("Database schema and demo data are ready.")


def main():
    print("WARNING: database/seed.sql clears and replaces existing Haven House data,")
    print("including users, FAQs, feedback, and OTP challenges.")
    answer = input("Continue with schema setup and demo-data reset? [y/N] ").strip().lower()
    if answer not in ("y", "yes"):
        print("Cancelled; no database changes were made.")
        return 0

    try:
        run()
    except (mysql.connector.Error, OSError) as error:
        print(f"Database setup failed: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
