# Haven House API Testing & Validation Guide (Stage 3 Hardened)

This document outlines how to test all backend REST API endpoints, security headers, input limits, and 2FA authentication flows.

## Prerequisites
Ensure the Flask backend is running on `http://localhost:5000`:
```bash
python3 -m backend.app
```

---

## 1. Security Headers Verification
```bash
curl -I http://localhost:5000/api/health
```
**Expected Response Headers:**
```http
HTTP/1.1 200 OK
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; ...
X-Content-Type-Options: nosniff
X-Frame-Options: SAMEORIGIN
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: geolocation=(), microphone=(), camera=(), payment=()
Cache-Control: no-store, no-cache, must-revalidate, max-age=0
```

---

## 2. Request Size Limit Test (413 Payload Too Large)
```bash
# Sending a 2MB dummy payload should immediately trigger 413
python3 -c "import urllib.request; req = urllib.request.Request('http://localhost:5000/api/assistant', data=b'x'*(2*1024*1024), headers={'Content-Type': 'application/json'}); print(urllib.request.urlopen(req))"
```

---

## 3. Two-Layer Authentication Flow

### A. Register New User (`POST /api/auth/register`)
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Jane Doe",
    "email": "jane@example.com",
    "password": "StrongPassword123"
  }'
```

### B. Step 1: Password Login (`POST /api/auth/login`)
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "jane@example.com",
    "password": "StrongPassword123"
  }'
```

### C. Step 2: Verify 6-Digit OTP (`POST /api/auth/verify-otp`)
```bash
curl -X POST http://localhost:5000/api/auth/verify-otp \
  -H "Content-Type: application/json" \
  -d '{
    "challenge_id": "<challenge_id_from_step_1>",
    "otp": "483921"
  }'
```

### D. Protected Profile (`GET /api/auth/me`)
```bash
curl -X GET http://localhost:5000/api/auth/me \
  -H "Authorization: Bearer <final_jwt_token>"
```

---

## 4. Public Service Navigation & Safety Guardrail

### Service Navigation
```bash
curl -X POST http://localhost:5000/api/assistant \
  -H "Content-Type: application/json" \
  -d '{"message": "I need help finding crisis accommodation"}'
```

### Emergency Safety Intent (Triggering Human Handoff)
```bash
curl -X POST http://localhost:5000/api/assistant \
  -H "Content-Type: application/json" \
  -d '{"message": "I am in immediate danger"}'
```
