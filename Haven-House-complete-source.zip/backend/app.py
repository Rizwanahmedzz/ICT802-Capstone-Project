import logging
from flask import Flask, jsonify, request
from flask_cors import CORS

from backend.config import Config
from backend.db import check_db_connection
from backend.utils.responses import success_response, error_response
from backend.utils.security_headers import apply_security_headers
from backend.routes import (
    organization_bp,
    services_bp,
    faqs_bp,
    feedback_bp,
    knowledge_bp,
    assistant_bp,
    auth_bp,
    appointments_bp,
    admin_bp,
    site_content_bp
)

# Configure logging with security redaction format
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [%(levelname)s] in %(module)s: %(message)s"
)
logger = logging.getLogger(__name__)


def create_app():
    """Application factory for Haven House REST API with security hardening."""
    # 1. Validate Production Security Configuration (Fail-fast on unsafe secrets)
    Config.validate_production_security()

    app = Flask(__name__)
    app.config.from_object(Config)

    # 2. Feature 1: Request Body Size Limit (1 MB)
    app.config["MAX_CONTENT_LENGTH"] = 1 * 1024 * 1024

    # 3. Feature 3: Cleaned CORS Configuration for Bearer JWT Architecture
    # Note: supports_credentials is omitted because bearer token authentication
    # operates exclusively via 'Authorization: Bearer <token>' headers, not ambient browser cookies.
    CORS(
        app, 
        resources={r"/api/*": {"origins": Config.CORS_ORIGINS}},
        allow_headers=["Content-Type", "Authorization"],
        methods=["GET", "POST", "PATCH", "OPTIONS"]
    )

    # 4. Feature 2: HTTP Security Headers Middleware (after_request)
    @app.after_request
    def security_headers_middleware(response):
        return apply_security_headers(response)

    # 5. Register Route Blueprints with /api prefix
    app.register_blueprint(organization_bp, url_prefix="/api")
    app.register_blueprint(services_bp, url_prefix="/api")
    app.register_blueprint(faqs_bp, url_prefix="/api")
    app.register_blueprint(feedback_bp, url_prefix="/api")
    app.register_blueprint(knowledge_bp, url_prefix="/api")
    app.register_blueprint(assistant_bp, url_prefix="/api")
    app.register_blueprint(auth_bp, url_prefix="/api")
    app.register_blueprint(appointments_bp, url_prefix="/api")
    app.register_blueprint(admin_bp, url_prefix="/api")
    app.register_blueprint(site_content_bp, url_prefix="/api")

    # 6. Public Health Check Endpoint
    @app.route("/api/health", methods=["GET"])
    def health_check():
        db_ok, db_status = check_db_connection()
        return success_response(
            data={
                "api": "running",
                "database": db_status
            },
            message="Haven House API is operational"
        )

    # 7. Global Error Handlers (Safe responses, never exposing stack traces or SQL)
    @app.errorhandler(400)
    def bad_request_handler(e):
        return error_response("Invalid request.", status_code=400)

    @app.errorhandler(404)
    def not_found_handler(e):
        return error_response("Resource not found.", status_code=404)

    @app.errorhandler(405)
    def method_not_allowed_handler(e):
        return error_response("Method not allowed.", status_code=405)

    @app.errorhandler(413)
    def request_entity_too_large_handler(e):
        return error_response("Request payload exceeds maximum allowed size (1 MB).", status_code=413)

    @app.errorhandler(429)
    def ratelimit_handler(e):
        return error_response("Too many requests. Please try again later.", status_code=429)

    @app.errorhandler(500)
    def internal_error_handler(e):
        logger.error(f"[Server Error] Internal error occurred: {e}")
        return error_response("Internal server error.", status_code=500)

    return app


app = create_app()

if __name__ == "__main__":
    logger.info(f"Starting Haven House API on port {Config.PORT} (Debug: {Config.DEBUG}, Env: {Config.ENV})...")
    app.run(host="0.0.0.0", port=Config.PORT, debug=Config.DEBUG)
