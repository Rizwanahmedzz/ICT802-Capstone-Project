import logging
from flask import Response, request

logger = logging.getLogger(__name__)

# Standard Content Security Policy for Haven House
CSP_POLICY = (
    "default-src 'self'; "
    "script-src 'self' 'unsafe-inline'; "
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
    "font-src 'self' https://fonts.gstatic.com; "
    "img-src 'self' data: https:; "
    "connect-src 'self' http://localhost:* http://127.0.0.1:*; "
    "frame-ancestors 'self' http://localhost:* http://127.0.0.1:*; "
    "base-uri 'self'; "
    "object-src 'none';"
)


def apply_security_headers(response: Response) -> Response:
    """
    Applies strict HTTP security and privacy headers to all outgoing Flask responses.
    Prevents MIME sniffing, clickjacking, XSS, and unintended caching of sensitive data.
    """
    response.headers["Content-Security-Policy"] = CSP_POLICY
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=(), payment=()"

    # Apply Cache-Control: no-store on all API endpoints to prevent token/personal data caching
    if request.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"

    return response
