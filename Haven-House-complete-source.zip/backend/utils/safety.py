import re
import logging

logger = logging.getLogger(__name__)

# Comprehensive safety & crisis keyword patterns (word-boundary matched where appropriate)
SAFETY_PATTERNS = [
    # Immediate Danger & Threats
    r"\bin danger\b",
    r"\bimmediate danger\b",
    r"\bthreat\b",
    r"\bthreats\b",
    r"\bthreatening\b",
    r"\bthreatened\b",
    r"\bunsafe\b",
    r"\bnot safe\b",
    r"\bfeel unsafe\b",
    r"\b(don't|do not|doesn't) feel safe\b",
    r"\bemergency\b",
    r"\bsomeone is threatening\b",
    r"\bsomeone wants to kill\b",
    r"\bsomeone wants to hurt\b",
    r"\bheld hostage\b",
    
    # Suicide & Self-Harm
    r"\bhurt myself\b",
    r"\bhurting myself\b",
    r"\bkill myself\b",
    r"\bkilling myself\b",
    r"\bsuicide\b",
    r"\bsuicidal\b",
    r"\bwant to die\b",
    r"\bwishing i was dead\b",
    r"\bending my life\b",
    r"\bend my life\b",
    r"\btake my own life\b",
    r"\bself[- ]?harm\b",
    r"\bcutting myself\b",
    
    # Domestic Violence, Abuse & Assault
    r"\bdomestic violence\b",
    r"\bdv\b",
    r"\bhurting me\b",
    r"\bhurt me\b",
    r"\bhitting me\b",
    r"\bhit me\b",
    r"\bpartner is hitting\b",
    r"\bbeing attacked\b",
    r"\battacked\b",
    r"\battacking\b",
    r"\battack\b",
    r"\bassault\b",
    r"\bassaulted\b",
    r"\babuse\b",
    r"\babused\b",
    r"\babusive\b",
    r"\bviolent\b",
    r"\bviolence\b",
    r"\bstrangled\b",
    r"\bstrangling\b",
    
    # Stalking & Weapons
    r"\bstalking\b",
    r"\bstalker\b",
    r"\bweapon\b",
    r"\bweapons\b",
    r"\bgun\b",
    r"\bknife\b",
    
    # Overdose & Critical Poisoning
    r"\boverdose\b",
    r"\boverdosed\b",
    r"\bpoisoning\b",
    r"\bbleeding out\b"
]

COMPILED_PATTERNS = [re.compile(pattern, re.IGNORECASE) for pattern in SAFETY_PATTERNS]

def is_crisis_intent(text: str) -> bool:
    """
    Evaluates whether text contains crisis, self-harm, domestic violence,
    or immediate safety concerns.
    
    CRITICAL RULE:
    If crisis intent is detected, normal assistant processing is bypassed immediately.
    No crisis advice, instructions, or diagnostics are generated.
    """
    if not text or not isinstance(text, str):
        return False

    normalized = text.strip()
    if not normalized:
        return False

    for pattern in COMPILED_PATTERNS:
        if pattern.search(normalized):
            logger.info("[Safety Guardrail] Server-side crisis intent detected. Halting normal assistant flow.")
            return True

    return False
