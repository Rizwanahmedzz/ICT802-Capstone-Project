from flask import jsonify

def success_response(data=None, message=None, status_code=200):
    """
    Standardized success JSON response structure:
    {
        "success": true,
        "data": ...,
        "message": ... (optional)
    }
    """
    response_body = {"success": True}
    if data is not None:
        response_body["data"] = data
    if message is not None:
        response_body["message"] = message
    return jsonify(response_body), status_code


def error_response(message="An error occurred", status_code=400):
    """
    Standardized error JSON response structure:
    {
        "success": false,
        "message": ...
    }
    """
    return jsonify({
        "success": False,
        "message": message
    }), status_code
