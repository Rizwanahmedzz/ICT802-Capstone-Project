import logging
import datetime
import secrets
from functools import wraps
from flask import request
import jwt
from werkzeug.security import generate_password_hash, check_password_hash

from backend.config import Config
from backend.db import query_db
from backend.utils.responses import error_response

logger = logging.getLogger(__name__)


def hash_password(password: str) -> str:
    """Securely hashes a plaintext password using PBKDF2-SHA256."""
    return generate_password_hash(password, method="pbkdf2:sha256")


def verify_password(password: str, password_hash: str) -> bool:
    """Verifies a plaintext password against its stored PBKDF2 hash."""
    if not password or not password_hash:
        return False
    return check_password_hash(password_hash, password)


def generate_secure_otp(length: int = 6) -> str:
    """Generates a cryptographically secure numeric OTP using secrets module."""
    digits = "0123456789"
    return "".join(secrets.choice(digits) for _ in range(length))


def generate_challenge_id() -> str:
    """Generates a cryptographically secure opaque token for 2FA challenges."""
    return secrets.token_urlsafe(32)


def hash_otp(otp_code: str) -> str:
    """Hashes an OTP code using PBKDF2-SHA256 before database storage."""
    return generate_password_hash(otp_code, method="pbkdf2:sha256")


def verify_otp_hash(otp_code: str, otp_hash: str) -> bool:
    """Verifies a user-entered OTP against the stored PBKDF2 hash."""
    if not otp_code or not otp_hash:
        return False
    return check_password_hash(otp_hash, otp_code)


def create_access_token(user_id: int, role: str = "user", expires_in_hours: int = None) -> str:
    """Creates a signed JWT access token with standard expiration and role claims."""
    hours = expires_in_hours or Config.JWT_EXPIRATION_HOURS
    now = datetime.datetime.now(datetime.timezone.utc)
    expiration = now + datetime.timedelta(hours=hours)

    payload = {
        "sub": str(user_id),
        "role": role,
        "iat": now,
        "exp": expiration
    }

    token = jwt.encode(payload, Config.JWT_SECRET_KEY, algorithm="HS256")
    return token


def decode_access_token(token: str) -> dict | None:
    """
    Safely verifies and decodes a JWT token.
    Returns decoded payload dictionary if valid, or None if invalid/expired.
    """
    try:
        payload = jwt.decode(token, Config.JWT_SECRET_KEY, algorithms=["HS256"])
        return payload
    except jwt.ExpiredSignatureError:
        logger.info("[Auth] JWT expired signature.")
        return None
    except jwt.InvalidTokenError as e:
        logger.info(f"[Auth] Invalid JWT: {e}")
        return None
    except Exception as e:
        logger.error(f"[Auth Error] Unexpected JWT decoding error: {e}")
        return None


def sanitize_user(user: dict) -> dict:
    """Removes password_hash and internal security fields from user object before returning to client."""
    if not user:
        return {}
    return {
        "id": user.get("id"),
        "name": user.get("name"),
        "email": user.get("email"),
        "role": user.get("role", "user")
    }


def require_auth(f):
    """
    Decorator for protecting endpoints with Bearer JWT token verification.
    Validates token signature, expiration, and ensures user account remains active.
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get("Authorization")
        if not auth_header:
            return error_response("Authentication required. Missing Authorization header.", status_code=401)

        parts = auth_header.split()
        if len(parts) != 2 or parts[0].lower() != "bearer":
            return error_response("Invalid Authorization header format. Expected 'Bearer <token>'.", status_code=401)

        token = parts[1]
        payload = decode_access_token(token)
        if not payload or "sub" not in payload:
            return error_response("Invalid or expired authentication token.", status_code=401)

        try:
            user_id = int(payload["sub"])
        except (ValueError, TypeError):
            return error_response("Invalid token subject.", status_code=401)

        # Verify user exists and is active in database
        try:
            query = "SELECT id, name, email, role, is_active FROM users WHERE id = %s LIMIT 1"
            user = query_db(query, (user_id,), one=True)
            if not user:
                return error_response("User account not found.", status_code=401)

            if not user.get("is_active"):
                return error_response("User account is inactive.", status_code=401)

            # Attach authenticated user to request context
            request.current_user = sanitize_user(user)

        except Exception as e:
            logger.error(f"[Auth DB Error] Error verifying user session: {e}")
            return error_response("Authentication verification failed.", status_code=500)

        return f(*args, **kwargs)

    return decorated


def require_admin(f):
    """Reject authenticated users without the current database admin role."""
    @wraps(f)
    def decorated(*args, **kwargs):
        current_user = getattr(request, "current_user", None)
        if not current_user:
            return error_response("Authentication required.", status_code=401)
        if current_user.get("role") != "admin":
            return error_response("Administrator access required.", status_code=403)
        return f(*args, **kwargs)

    return decorated
