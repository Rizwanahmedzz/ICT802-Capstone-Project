import re
import html
import logging
from typing import Any, Tuple, Optional

logger = logging.getLogger(__name__)

EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_REGEX = re.compile(r"^\+?[0-9\s\-\(\)]{8,20}$")
CHALLENGE_ID_REGEX = re.compile(r"^[A-Za-z0-9_\-]{20,80}$")
OTP_REGEX = re.compile(r"^\d{6}$")


def sanitize_text(value: str) -> str:
    """
    Utility to escape raw HTML characters (<, >, &, \", ') for HTML context output.
    Note on Architecture: The Haven House system preserves canonical text in the database
    and non-destructively evaluates assistant messages for crisis safety detection,
    while enforcing context-aware output encoding at the frontend rendering boundary (escapeHtml).
    """
    if not isinstance(value, str):
        return ""
    return html.escape(value.strip())


def validate_email(email: Any) -> Tuple[bool, Optional[str], Optional[str]]:
    """
    Validates and normalizes an email address.
    Returns (is_valid, normalized_email, error_message).
    """
    if not email or not isinstance(email, str):
        return False, None, "Email address is required."

    normalized = email.strip().lower()
    if len(normalized) > 255:
        return False, None, "Email address cannot exceed 255 characters."

    if not EMAIL_REGEX.match(normalized):
        return False, None, "Please enter a valid email address."

    return True, normalized, None


def validate_name(name: Any) -> Tuple[bool, Optional[str], Optional[str]]:
    """
    Validates a user full name.
    Returns (is_valid, trimmed_name, error_message).
    """
    if not name or not isinstance(name, str) or not name.strip():
        return False, None, "Please enter your name."

    trimmed = name.strip()
    if len(trimmed) > 150:
        return False, None, "Name cannot exceed 150 characters."

    return True, trimmed, None


def validate_password(password: Any) -> Tuple[bool, Optional[str]]:
    """
    Validates password length and type.
    Returns (is_valid, error_message).
    """
    if not password or not isinstance(password, str):
        return False, "Please enter a password."

    if len(password) < 8:
        return False, "Password must be at least 8 characters long."

    if len(password) > 128:
        return False, "Password cannot exceed 128 characters."

    return True, None


def validate_otp_code(otp: Any) -> Tuple[bool, Optional[str], Optional[str]]:
    """
    Validates a 6-digit numeric OTP code.
    Returns (is_valid, clean_otp, error_message).
    """
    if not otp or not isinstance(otp, str):
        return False, None, "Please enter a 6-digit verification code."

    clean = otp.strip()
    if not OTP_REGEX.match(clean):
        return False, None, "Verification code must be exactly 6 numeric digits."

    return True, clean, None


def validate_challenge_id(challenge_id: Any) -> Tuple[bool, Optional[str], Optional[str]]:
    """
    Validates a 2FA challenge identifier string.
    Returns (is_valid, clean_id, error_message).
    """
    if not challenge_id or not isinstance(challenge_id, str):
        return False, None, "Missing or invalid challenge identifier."

    clean = challenge_id.strip()
    if not CHALLENGE_ID_REGEX.match(clean):
        return False, None, "Malformed challenge identifier."

    return True, clean, None


def validate_positive_id(value: Any, param_name: str = "ID") -> Tuple[bool, Optional[int], Optional[str]]:
    """
    Validates a numeric integer identifier.
    Returns (is_valid, int_value, error_message).
    """
    try:
        val = int(value)
        if val <= 0:
            return False, None, f"{param_name} must be a positive integer."
        return True, val, None
    except (ValueError, TypeError):
        return False, None, f"Invalid {param_name}. Must be an integer."


def validate_assistant_message(message: Any, max_length: int = 2000) -> Tuple[bool, Optional[str], Optional[str]]:
    """
    Validates an incoming user message for the assistant endpoint.
    Preserves raw content for server-side safety checks without destructive truncation.
    Returns (is_valid, clean_message, error_message).
    """
    if message is None or not isinstance(message, str):
        return False, None, "Message must be a non-empty string."

    trimmed = message.strip()
    if not trimmed:
        return False, None, "Message cannot be empty."

    if len(trimmed) > max_length:
        return False, None, f"Message exceeds maximum allowed length of {max_length} characters."

    return True, trimmed, None


def validate_feedback_response(response: Any) -> Tuple[bool, Optional[str], Optional[str]]:
    """
    Validates FAQ feedback response value ('YES' or 'NO').
    Returns (is_valid, normalized_response, error_message).
    """
    if not response or not isinstance(response, str):
        return False, None, "Feedback response must be 'YES' or 'NO'."

    normalized = response.strip().upper()
    if normalized not in ("YES", "NO"):
        return False, None, "Feedback response must be either 'YES' or 'NO'."

    return True, normalized, None
