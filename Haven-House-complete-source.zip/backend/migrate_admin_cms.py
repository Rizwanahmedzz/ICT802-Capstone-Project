"""Apply additive admin-CMS schema changes without rerunning seed data."""

import sys
from pathlib import Path

import mysql.connector

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.config import Config
from backend.setup_database import iter_sql_statements


def run():
    connection = mysql.connector.connect(
        host=Config.DB_HOST,
        port=Config.DB_PORT,
        user=Config.DB_USER,
        password=Config.DB_PASSWORD,
        charset="utf8mb4",
        collation="utf8mb4_unicode_ci",
        connect_timeout=5,
    )
    try:
        cursor = connection.cursor()
        schema = (ROOT / "database" / "schema.sql").read_text(encoding="utf-8")
        for statement in iter_sql_statements(schema):
            cursor.execute(statement)

        cursor.execute(
            """
            SELECT COLUMN_NAME FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA=%s AND TABLE_NAME='service_details'
            """,
            (Config.DB_NAME,),
        )
        existing_columns = {row[0] for row in cursor.fetchall()}
        additions = {
            "cost_info": "TEXT NULL",
            "contact_info": "TEXT NULL",
            "website_url": "VARCHAR(500) NULL",
        }
        for column, definition in additions.items():
            if column not in existing_columns:
                cursor.execute(f"ALTER TABLE service_details ADD COLUMN {column} {definition}")

        cursor.execute(
            """
            SELECT COLUMN_NAME FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA=%s AND TABLE_NAME='appointments'
            """,
            (Config.DB_NAME,),
        )
        appointment_columns = {row[0] for row in cursor.fetchall()}
        cursor.execute(
            """
            SELECT INDEX_NAME FROM information_schema.STATISTICS
            WHERE TABLE_SCHEMA=%s AND TABLE_NAME='appointments'
            """,
            (Config.DB_NAME,),
        )
        appointment_indexes = {row[0] for row in cursor.fetchall()}
        if "uq_appointments_confirmed_starts_at" not in appointment_indexes:
            if "uq_appointments_starts_at" in appointment_indexes:
                cursor.execute("ALTER TABLE appointments DROP INDEX uq_appointments_starts_at")
            if "confirmed_starts_at" not in appointment_columns:
                cursor.execute(
                    """
                    ALTER TABLE appointments ADD COLUMN confirmed_starts_at DATETIME
                    GENERATED ALWAYS AS (
                        CASE WHEN status = 'CONFIRMED' THEN starts_at ELSE NULL END
                    ) STORED
                    """
                )
            cursor.execute(
                """
                ALTER TABLE appointments
                ADD UNIQUE KEY uq_appointments_confirmed_starts_at (confirmed_starts_at)
                """
            )

        cursor.execute(
            """
            SELECT COLUMN_NAME, IS_NULLABLE FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA=%s AND TABLE_NAME='events'
            """,
            (Config.DB_NAME,),
        )
        event_columns = {row[0]: row[1] for row in cursor.fetchall()}
        if "schedule_label" not in event_columns:
            cursor.execute("ALTER TABLE events ADD COLUMN schedule_label VARCHAR(100) NULL AFTER ends_at")
        if event_columns.get("starts_at") == "NO":
            cursor.execute("ALTER TABLE events MODIFY starts_at DATETIME NULL")
        cursor.close()
    finally:
        connection.close()


if __name__ == "__main__":
    run()
    print("Admin CMS schema migration completed; existing seed data was not modified.")
