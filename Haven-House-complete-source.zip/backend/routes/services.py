import logging
from flask import Blueprint
from backend.db import query_db, execute_db
from backend.utils.responses import success_response, error_response

logger = logging.getLogger(__name__)
services_bp = Blueprint("services", __name__)

def resolve_service_id(service_identifier):
    """Helper to resolve service ID whether passed as integer ID or service_key string."""
    try:
        # If numeric string or int
        if str(service_identifier).isdigit():
            return int(service_identifier)
        
        # If string key
        row = query_db(
            "SELECT id FROM services WHERE service_key = %s AND is_active = TRUE",
            (str(service_identifier),),
            fetchone=True
        )
        return row["id"] if row else None
    except Exception as e:
        logger.error(f"Error resolving service identifier {service_identifier}: {e}")
        return None


@services_bp.route("/services", methods=["GET"])
def get_services():
    """
    GET /api/services
    Returns active services ordered by display_order.
    """
    try:
        query = """
            SELECT id, service_key, title, card_title, badge, description, icon_name
            FROM services
            WHERE is_active = TRUE
            ORDER BY display_order ASC
        """
        services = query_db(query)
        return success_response(data=services)
    except Exception as e:
        logger.error(f"Error fetching services: {e}")
        return error_response("Internal server error", status_code=500)


@services_bp.route("/services/<service_identifier>", methods=["GET"])
def get_single_service(service_identifier):
    """
    GET /api/services/<service_id_or_key>
    Returns composite service record: service info + details + eligibility + hours.
    """
    try:
        service_id = resolve_service_id(service_identifier)
        if not service_id:
            return error_response("Service not found", status_code=404)

        # 1. Fetch Service Info
        service = query_db(
            """
            SELECT id, service_key, title, card_title, badge, description, icon_name
            FROM services
            WHERE id = %s AND is_active = TRUE
            """,
            (service_id,),
            fetchone=True
        )
        if not service:
            return error_response("Service not found", status_code=404)

        # 2. Fetch Service Details (1:1)
        details = query_db(
            """
            SELECT detail_title, detail_description, overview, relevance, intake_desk_text,
                   eligibility_note, cost_info, contact_info, website_url
            FROM service_details
            WHERE service_id = %s
            """,
            (service_id,),
            fetchone=True
        )

        # 3. Fetch Service Eligibility (1:M)
        eligibility = query_db(
            """
            SELECT id, criterion, display_order
            FROM service_eligibility
            WHERE service_id = %s
            ORDER BY display_order ASC
            """,
            (service_id,)
        )

        # 4. Fetch Service Hours (1:M)
        hours = query_db(
            """
            SELECT id, day_of_week, 
                   TIME_FORMAT(opening_time, '%%H:%%i') as opening_time, 
                   TIME_FORMAT(closing_time, '%%H:%%i') as closing_time, 
                   is_closed, notes
            FROM service_hours
            WHERE service_id = %s
            ORDER BY id ASC
            """,
            (service_id,)
        )

        # Non-sensitive audit logging for service view
        try:
            execute_db(
                """
                INSERT INTO audit_log (user_id, action, entity_type, entity_id, description)
                VALUES (NULL, 'SERVICE_VIEWED', 'SERVICE', %s, %s)
                """,
                (service_id, f"Viewed service: {service.get('title')}")
            )
        except Exception as audit_err:
            logger.warning(f"Audit log insertion skipped: {audit_err}")

        return success_response(data={
            "service": service,
            "details": details or {},
            "eligibility": eligibility or [],
            "hours": hours or []
        })
    except Exception as e:
        logger.error(f"Error fetching single service {service_identifier}: {e}")
        return error_response("Internal server error", status_code=500)


@services_bp.route("/services/<service_identifier>/eligibility", methods=["GET"])
def get_service_eligibility(service_identifier):
    """
    GET /api/services/<service_id>/eligibility
    Returns eligibility criteria for a service.
    """
    try:
        service_id = resolve_service_id(service_identifier)
        if not service_id:
            return error_response("Service not found", status_code=404)

        criteria = query_db(
            """
            SELECT id, criterion, display_order
            FROM service_eligibility
            WHERE service_id = %s
            ORDER BY display_order ASC
            """,
            (service_id,)
        )
        return success_response(data=criteria)
    except Exception as e:
        logger.error(f"Error fetching service eligibility: {e}")
        return error_response("Internal server error", status_code=500)


@services_bp.route("/services/<service_identifier>/hours", methods=["GET"])
def get_service_hours(service_identifier):
    """
    GET /api/services/<service_id>/hours
    Returns structured hours and notes for a service.
    """
    try:
        service_id = resolve_service_id(service_identifier)
        if not service_id:
            return error_response("Service not found", status_code=404)

        hours = query_db(
            """
            SELECT id, day_of_week, 
                   TIME_FORMAT(opening_time, '%%H:%%i') as opening_time, 
                   TIME_FORMAT(closing_time, '%%H:%%i') as closing_time, 
                   is_closed, notes
            FROM service_hours
            WHERE service_id = %s
            ORDER BY id ASC
            """,
            (service_id,)
        )
        return success_response(data=hours)
    except Exception as e:
        logger.error(f"Error fetching service hours: {e}")
        return error_response("Internal server error", status_code=500)
