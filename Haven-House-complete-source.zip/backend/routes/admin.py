import datetime
import logging
from contextlib import contextmanager

from flask import Blueprint, request
from mysql.connector import IntegrityError, errorcode

from backend.config import Config
from backend.db import execute_db, query_db
from backend.utils.auth import require_admin, require_auth
from backend.utils.responses import error_response, success_response

logger = logging.getLogger(__name__)
admin_bp = Blueprint("admin", __name__)


@contextmanager
def _admin_transaction():
    from backend.db import get_db_cursor

    with get_db_cursor(commit=True) as cursor:
        try:
            yield cursor
        except Exception:
            cursor.connection.rollback()
            raise


def _json_payload():
    if not request.is_json:
        return None
    payload = request.get_json(silent=True)
    return payload if isinstance(payload, dict) else None


def _audit(action, entity_type, entity_id, description):
    execute_db(
        """
        INSERT INTO audit_log (user_id, action, entity_type, entity_id, description)
        VALUES (%s, %s, %s, %s, %s)
        """,
        (request.current_user["id"], action, entity_type, entity_id, description[:255]),
    )


def _format_datetime_rows(rows, *fields):
    for row in rows:
        for field in fields:
            value = row.get(field)
            if isinstance(value, (datetime.datetime, datetime.date)):
                row[field] = value.isoformat()
    return rows


def _safe_audit(action, entity_type, entity_id, description):
    try:
        _audit(action, entity_type, entity_id, description)
    except Exception as error:
        logger.error("Admin audit failed for %s: %s", action, type(error).__name__)


@admin_bp.route("/admin/appointments", methods=["GET"])
@require_auth
@require_admin
def list_appointments():
    try:
        appointments = query_db(
            """
            SELECT a.id, a.user_id, COALESCE(u.name, a.guest_name) AS name,
                   COALESCE(u.email, a.guest_contact) AS email, a.starts_at, a.status, a.created_at
            FROM appointments a
            LEFT JOIN users u ON u.id = a.user_id
            ORDER BY a.starts_at DESC
            LIMIT 200
            """
        )
    except Exception as error:
        logger.error("Admin appointment lookup failed: %s", type(error).__name__)
        return error_response("Could not load appointment reservations. Please try again.", status_code=500)

    for appointment in appointments:
        starts_at = appointment["starts_at"]
        created_at = appointment["created_at"]
        if isinstance(starts_at, datetime.datetime):
            appointment["starts_at"] = starts_at.strftime("%Y-%m-%dT%H:%M")
        if isinstance(created_at, (datetime.datetime, datetime.date)):
            appointment["created_at"] = created_at.isoformat()

    return success_response(
        data={"appointments": appointments},
        message="Appointment reservations loaded."
    )


@admin_bp.route("/admin/dashboard", methods=["GET"])
@require_auth
@require_admin
def dashboard():
    try:
        metrics = query_db(
            """
            SELECT
                (SELECT COUNT(*) FROM appointments WHERE status = 'CONFIRMED') AS appointments,
                (SELECT COUNT(*) FROM appointments) AS total_appointments,
                (SELECT COUNT(*) FROM appointments WHERE status = 'CANCELLED') AS cancelled_appointments,
                (SELECT COUNT(*) FROM appointments WHERE status = 'CONFIRMED' AND starts_at >= NOW()) AS upcoming_appointments,
                (SELECT COUNT(*) FROM contact_enquiries WHERE status = 'NEW') AS new_enquiries,
                (SELECT COUNT(*) FROM events WHERE status = 'PUBLISHED' AND (starts_at >= NOW() OR starts_at IS NULL)) AS upcoming_events,
                (SELECT COUNT(*) FROM announcements WHERE status = 'PUBLISHED') AS published_announcements,
                (SELECT COUNT(*) FROM admin_notifications WHERE is_read = FALSE) AS unread_notifications,
                (SELECT COUNT(*) FROM services WHERE is_active = TRUE) AS active_services
            """,
            fetchone=True,
        )
        notifications = query_db(
            """
            SELECT id, notification_type, title, message, source_type, source_id,
                   is_read, created_at
            FROM admin_notifications
            ORDER BY created_at DESC
            LIMIT 10
            """
        )
        appointment_months = query_db(
            """
            SELECT DATE_FORMAT(starts_at, '%Y-%m') AS report_month, status, COUNT(*) AS total
            FROM appointments
            WHERE starts_at >= DATE_SUB(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL 5 MONTH)
              AND starts_at < DATE_ADD(LAST_DAY(CURDATE()), INTERVAL 1 DAY)
            GROUP BY report_month, status
            ORDER BY report_month ASC, status ASC
            """
        )
        _format_datetime_rows(notifications, "created_at")
        return success_response(data={
            "metrics": metrics,
            "notifications": notifications,
            "appointment_months": appointment_months,
        })
    except Exception as error:
        logger.error("Admin dashboard lookup failed: %s", type(error).__name__)
        return error_response("Could not load the admin dashboard. Please try again.", status_code=500)


@admin_bp.route("/admin/appointments/<int:appointment_id>", methods=["PATCH"])
@require_auth
@require_admin
def update_appointment(appointment_id):
    payload = _json_payload()
    if payload is None:
        return error_response("Invalid request. JSON payload required.", status_code=400)
    action = payload.get("action")
    if action == "status":
        status = str(payload.get("status", "")).upper()
        if status not in ("CONFIRMED", "CANCELLED"):
            return error_response("Choose CONFIRMED or CANCELLED.", status_code=400)
        query = "UPDATE appointments SET status = %s WHERE id = %s"
        params = (status, appointment_id)
        description = f"Set appointment {appointment_id} to {status}"
    elif action == "reschedule":
        try:
            starts_at = datetime.datetime.strptime(payload.get("starts_at", ""), "%Y-%m-%dT%H:%M")
        except (TypeError, ValueError):
            return error_response("Choose a valid appointment date and time.", status_code=400)
        if (
            starts_at <= datetime.datetime.now()
            or starts_at.weekday() >= 5
            or starts_at.hour < 9
            or starts_at.hour >= 17
            or starts_at.minute not in (0, 30)
        ):
            return error_response("Choose a future weekday time between 9:00 am and 4:30 pm.", status_code=400)
        query = "UPDATE appointments SET starts_at = %s WHERE id = %s"
        params = (starts_at, appointment_id)
        description = f"Rescheduled appointment {appointment_id}"
    else:
        return error_response("Choose a valid appointment action.", status_code=400)

    try:
        with _admin_transaction() as cursor:
            cursor.execute("SELECT starts_at, status FROM appointments WHERE id=%s FOR UPDATE", (appointment_id,))
            original = cursor.fetchone()
            if not original:
                return error_response("Appointment not found.", status_code=404)
            destination = starts_at if action == "reschedule" else original["starts_at"]
            if action == "reschedule" and destination != original["starts_at"]:
                destination_date_start = datetime.datetime.combine(destination.date(), datetime.time.min)
                destination_date_end = destination_date_start + datetime.timedelta(days=1)
                cursor.execute(
                    "SELECT id FROM appointment_slots WHERE starts_at >= %s AND starts_at < %s LIMIT 1",
                    (destination_date_start, destination_date_end),
                )
                configured_day = cursor.fetchone()
                if configured_day:
                    cursor.execute("SELECT id, is_active FROM appointment_slots WHERE starts_at=%s FOR UPDATE", (destination,))
                    available = cursor.fetchone()
                    if not available or (not available["is_active"] and destination != original["starts_at"]):
                        raise ValueError("destination slot unavailable")
            cursor.execute(query, params)
            if action == "reschedule" and destination != original["starts_at"]:
                cursor.execute("UPDATE appointment_slots SET is_active=FALSE WHERE starts_at=%s", (destination,))
                cursor.execute(
                    """
                    UPDATE appointment_slots SET is_active=TRUE
                    WHERE starts_at=%s AND NOT EXISTS
                        (SELECT 1 FROM appointments a WHERE a.starts_at=%s AND a.status='CONFIRMED' AND a.id<>%s)
                    """,
                    (original["starts_at"], original["starts_at"], appointment_id),
                )
            if action == "status" and status == "CANCELLED":
                cursor.execute("UPDATE appointment_slots SET is_active=TRUE WHERE starts_at=%s", (original["starts_at"],))
            if action == "status" and status == "CONFIRMED":
                cursor.execute("UPDATE appointment_slots SET is_active=FALSE WHERE starts_at=%s", (original["starts_at"],))
            if action == "status" and status == "CANCELLED":
                cursor.execute(
                    """
                    INSERT INTO admin_notifications
                        (notification_type, title, message, source_type, source_id)
                    VALUES ('APPOINTMENT_CANCELLED', 'Appointment cancelled', %s, 'APPOINTMENT', %s)
                    """,
                    (f"Appointment {appointment_id} was cancelled.", appointment_id),
                )
        _safe_audit("APPOINTMENT_UPDATED", "APPOINTMENT", appointment_id, description)
        return success_response(message="Appointment updated.")
    except ValueError:
        return error_response("Choose an open administrator-created slot.", status_code=409)
    except IntegrityError as error:
        if error.errno != errorcode.ER_DUP_ENTRY:
            logger.error("Admin appointment update integrity failure: %s", error.errno)
            return error_response("Could not update the appointment. Please try again.", status_code=500)
        return error_response("That appointment time is already reserved.", status_code=409)
    except Exception as error:
        logger.error("Admin appointment update failed: %s", type(error).__name__)
        return error_response("Could not update the appointment. Please try again.", status_code=500)


@admin_bp.route("/admin/slots", methods=["GET", "POST", "PATCH"])
@require_auth
@require_admin
def manage_slots():
    if request.method == "GET":
        month = request.args.get("month")
        query = """
            SELECT s.id, s.starts_at, s.is_active, s.notes,
                   a.id AS appointment_id
            FROM appointment_slots s
            LEFT JOIN appointments a
              ON a.starts_at = s.starts_at AND a.status = 'CONFIRMED'
        """
        params = ()
        bookings = []
        if month:
            try:
                month_start = datetime.datetime.strptime(month, "%Y-%m")
                if month_start.strftime("%Y-%m") != month:
                    raise ValueError
                if month_start.month == 12:
                    month_end = month_start.replace(year=month_start.year + 1, month=1)
                else:
                    month_end = month_start.replace(month=month_start.month + 1)
            except ValueError:
                return error_response("Choose a valid calendar month.", status_code=400)
            query += " WHERE s.starts_at >= %s AND s.starts_at < %s"
            params = (month_start, month_end)
            booking_query = """
                SELECT id, starts_at
                FROM appointments
                WHERE status = 'CONFIRMED' AND starts_at >= %s AND starts_at < %s
                ORDER BY starts_at ASC
                LIMIT 500
            """
        query += " ORDER BY s.starts_at ASC LIMIT 500"
        try:
            slots = query_db(query, params)
            _format_datetime_rows(slots, "starts_at")
            if month:
                bookings = query_db(booking_query, params)
                _format_datetime_rows(bookings, "starts_at")
            return success_response(data={"slots": slots, "appointments": bookings})
        except Exception as error:
            logger.error("Admin slot lookup failed: %s", type(error).__name__)
            return error_response("Could not load appointment slots.", status_code=500)

    payload = _json_payload()
    if payload is None:
        return error_response("Invalid request. JSON payload required.", status_code=400)
    action = payload.get("action", "create")
    if action == "toggle" and request.method == "PATCH":
        try:
            slot_id = int(payload.get("id"))
            is_active = bool(payload.get("is_active"))
        except (TypeError, ValueError):
            return error_response("Choose a valid appointment slot.", status_code=400)
        try:
            changed = execute_db(
                "UPDATE appointment_slots SET is_active = %s WHERE id = %s",
                (is_active, slot_id),
            )
            if not changed:
                return error_response("Appointment slot not found.", status_code=404)
            _safe_audit("APPOINTMENT_SLOT_UPDATED", "APPOINTMENT_SLOT", slot_id, "Updated slot availability")
            return success_response(message="Appointment slot updated.")
        except Exception as error:
            logger.error("Admin slot update failed: %s", type(error).__name__)
            return error_response("Could not update the appointment slot.", status_code=500)

    if request.method != "POST":
        return error_response("Choose a valid appointment slot action.", status_code=400)
    try:
        starts_at = datetime.datetime.strptime(payload.get("starts_at", ""), "%Y-%m-%dT%H:%M")
    except (TypeError, ValueError):
        return error_response("Choose a valid appointment date and time.", status_code=400)
    if starts_at <= datetime.datetime.now() or starts_at.weekday() >= 5:
        return error_response("Slots must be set for a future weekday.", status_code=400)
    if starts_at.hour < 9 or starts_at.hour >= 17 or starts_at.minute not in (0, 30):
        return error_response("Slots must be set on a half-hour between 9:00 am and 4:30 pm.", status_code=400)
    try:
        slot_id = execute_db(
            """
            INSERT INTO appointment_slots (starts_at, is_active, notes, created_by)
            VALUES (%s, TRUE, %s, %s)
            """,
            (starts_at, str(payload.get("notes", "")).strip()[:255] or None, request.current_user["id"]),
        )
        _safe_audit("APPOINTMENT_SLOT_CREATED", "APPOINTMENT_SLOT", slot_id, "Created appointment slot")
        return success_response(data={"id": slot_id}, message="Appointment slot added.", status_code=201)
    except IntegrityError as error:
        if error.errno == errorcode.ER_NO_REFERENCED_ROW_2:
            logger.error("Admin slot owner reference invalid: %s", error.errno)
            return error_response("Could not verify the administrator account.", status_code=500)
        if error.errno == errorcode.ER_DUP_ENTRY:
            return error_response("A slot already exists at that time.", status_code=409)
        logger.error("Admin slot integrity failure: %s", error.errno)
        return error_response("Could not add the appointment slot.", status_code=500)
    except ValueError:
        return error_response("Slot notes must be valid text.", status_code=400)
    except Exception as error:
        logger.error("Admin slot creation failed: %s", type(error).__name__)
        return error_response("Could not add the appointment slot.", status_code=500)


@admin_bp.route("/admin/events", methods=["GET", "POST", "PATCH"])
@require_auth
@require_admin
def manage_events():
    if request.method == "GET":
        try:
            events = query_db("SELECT * FROM events ORDER BY starts_at IS NULL, starts_at DESC LIMIT 500")
            _format_datetime_rows(events, "starts_at", "ends_at", "created_at", "updated_at")
            return success_response(data={"events": events})
        except Exception as error:
            logger.error("Admin event lookup failed: %s", type(error).__name__)
            return error_response("Could not load events.", status_code=500)
    payload = _json_payload()
    if payload is None:
        return error_response("Invalid request. JSON payload required.", status_code=400)
    try:
        title = str(payload.get("title", "")).strip()
        description = str(payload.get("description", "")).strip()
        starts_value = str(payload.get("starts_at", "")).strip()
        starts_at = datetime.datetime.strptime(starts_value, "%Y-%m-%dT%H:%M") if starts_value else None
        ends_value = payload.get("ends_at")
        ends_at = datetime.datetime.strptime(ends_value, "%Y-%m-%dT%H:%M") if ends_value else None
        schedule_label = str(payload.get("schedule_label", "")).strip()
        status = str(payload.get("status", "DRAFT")).upper()
        event_id = int(payload["id"]) if payload.get("id") else None
    except (TypeError, ValueError, KeyError):
        return error_response("Enter a valid event title, description and date or date label.", status_code=400)
    if not title or not description or not (starts_at or schedule_label) or status not in ("DRAFT", "PUBLISHED", "CANCELLED"):
        return error_response("Enter a title, description and either a start time or date label.", status_code=400)
    try:
        values = (title[:180], description, starts_at, ends_at, schedule_label[:100] or None,
                  str(payload.get("location", "")).strip()[:255] or None, status)
        if ends_at and not starts_at:
            return error_response("An event end time requires a start time.", status_code=400)
        if ends_at and ends_at < starts_at:
            return error_response("Event end time must be after its start time.", status_code=400)
        if event_id:
            changed = execute_db(
                """
                UPDATE events SET title=%s, description=%s, starts_at=%s, ends_at=%s,
                    schedule_label=%s, location=%s, status=%s WHERE id=%s
                """,
                values + (event_id,),
            )
            if not changed and not query_db("SELECT id FROM events WHERE id=%s", (event_id,), fetchone=True):
                return error_response("Event not found.", status_code=404)
        else:
            event_id = execute_db(
                """
                INSERT INTO events (title, description, starts_at, ends_at, schedule_label, location, status, created_by)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """,
                values + (request.current_user["id"],),
            )
        _safe_audit("EVENT_SAVED", "EVENT", event_id, f"Saved event: {title}")
        return success_response(data={"id": event_id}, message="Event saved.")
    except Exception as error:
        logger.error("Admin event save failed: %s", type(error).__name__)
        return error_response("Could not save the event.", status_code=500)


@admin_bp.route("/admin/announcements", methods=["GET", "POST", "PATCH"])
@require_auth
@require_admin
def manage_announcements():
    if request.method == "GET":
        try:
            announcements = query_db("SELECT * FROM announcements ORDER BY created_at DESC LIMIT 500")
            _format_datetime_rows(announcements, "published_at", "created_at", "updated_at")
            return success_response(data={"announcements": announcements})
        except Exception as error:
            logger.error("Admin announcement lookup failed: %s", type(error).__name__)
            return error_response("Could not load announcements.", status_code=500)
    payload = _json_payload()
    if payload is None:
        return error_response("Invalid request. JSON payload required.", status_code=400)
    title = str(payload.get("title", "")).strip()
    body = str(payload.get("body", "")).strip()
    status = str(payload.get("status", "DRAFT")).upper()
    try:
        announcement_id = int(payload["id"]) if payload.get("id") else None
    except (TypeError, ValueError):
        return error_response("Choose a valid announcement.", status_code=400)
    if not title or not body or status not in ("DRAFT", "PUBLISHED", "ARCHIVED"):
        return error_response("Enter a title and body and choose a valid status.", status_code=400)
    try:
        published_at = datetime.datetime.now() if status == "PUBLISHED" else None
        if announcement_id:
            changed = execute_db(
                """
                UPDATE announcements SET title=%s, body=%s, status=%s, published_at=%s
                WHERE id=%s
                """,
                (title[:180], body, status, published_at, announcement_id),
            )
            if not changed and not query_db(
                "SELECT id FROM announcements WHERE id=%s", (announcement_id,), fetchone=True
            ):
                return error_response("Announcement not found.", status_code=404)
        else:
            announcement_id = execute_db(
                """
                INSERT INTO announcements (title, body, status, published_at, created_by)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (title[:180], body, status, published_at, request.current_user["id"]),
            )
        _safe_audit("ANNOUNCEMENT_SAVED", "ANNOUNCEMENT", announcement_id, f"Saved announcement: {title}")
        return success_response(data={"id": announcement_id}, message="Announcement saved.")
    except Exception as error:
        logger.error("Admin announcement save failed: %s", type(error).__name__)
        return error_response("Could not save the announcement.", status_code=500)


@admin_bp.route("/admin/enquiries", methods=["GET", "PATCH"])
@require_auth
@require_admin
def manage_enquiries():
    if request.method == "GET":
        try:
            enquiries = query_db(
                """
                SELECT id, name, email, subject, message, status, created_at, updated_at
                FROM contact_enquiries ORDER BY created_at DESC LIMIT 500
                """
            )
            _format_datetime_rows(enquiries, "created_at", "updated_at")
            return success_response(data={"enquiries": enquiries})
        except Exception as error:
            logger.error("Admin enquiry lookup failed: %s", type(error).__name__)
            return error_response("Could not load contact enquiries.", status_code=500)
    payload = _json_payload()
    if payload is None:
        return error_response("Invalid request. JSON payload required.", status_code=400)
    try:
        enquiry_id = int(payload.get("id"))
    except (TypeError, ValueError):
        return error_response("Choose a valid enquiry.", status_code=400)
    status = str(payload.get("status", "")).upper()
    if status not in ("NEW", "IN_PROGRESS", "RESOLVED"):
        return error_response("Choose a valid enquiry status.", status_code=400)
    try:
        changed = execute_db(
            "UPDATE contact_enquiries SET status=%s WHERE id=%s",
            (status, enquiry_id),
        )
        if not changed:
            return error_response("Contact enquiry not found.", status_code=404)
        _safe_audit("ENQUIRY_STATUS_UPDATED", "CONTACT_ENQUIRY", enquiry_id, f"Changed enquiry status to {status}")
        return success_response(message="Enquiry status updated.")
    except Exception as error:
        logger.error("Admin enquiry update failed: %s", type(error).__name__)
        return error_response("Could not update the enquiry.", status_code=500)


@admin_bp.route("/admin/services", methods=["GET"])
@require_auth
@require_admin
def admin_services():
    try:
        services = query_db(
            """
            SELECT s.id, s.service_key, s.title, s.card_title, s.badge, s.description,
                   s.icon_name, s.display_order, s.is_active,
                   d.detail_title, d.detail_description, d.overview, d.relevance,
                   d.intake_desk_text, d.eligibility_note, d.cost_info,
                   d.contact_info, d.website_url
            FROM services s
            LEFT JOIN service_details d ON d.service_id = s.id
            ORDER BY s.display_order, s.id
            """
        )
        for service in services:
            service["hours"] = query_db(
                """
                SELECT day_of_week,
                       TIME_FORMAT(opening_time, '%%H:%%i') AS opening_time,
                       TIME_FORMAT(closing_time, '%%H:%%i') AS closing_time,
                       is_closed, notes
                FROM service_hours WHERE service_id=%s ORDER BY id
                """,
                (service["id"],),
            )
        return success_response(data={"services": services})
    except Exception as error:
        logger.error("Admin service lookup failed: %s", type(error).__name__)
        return error_response("Could not load services.", status_code=500)


@admin_bp.route("/admin/services/<int:service_id>", methods=["PATCH"])
@require_auth
@require_admin
def update_service(service_id):
    payload = _json_payload()
    if payload is None:
        return error_response("Invalid request. JSON payload required.", status_code=400)
    required = ("title", "card_title", "description")
    if any(not str(payload.get(field, "")).strip() for field in required):
        return error_response("Service title, card title and description are required.", status_code=400)
    eligibility = payload.get("eligibility", [])
    if not isinstance(eligibility, list) or any(not isinstance(item, str) for item in eligibility):
        return error_response("Eligibility must be a list of text items.", status_code=400)
    hours = payload.get("hours", [])
    allowed_days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"}
    if not isinstance(hours, list):
        return error_response("Operating hours must be a list.", status_code=400)
    for row in hours:
        if (
            not isinstance(row, dict)
            or row.get("day_of_week") not in allowed_days
            or not isinstance(row.get("is_closed"), bool)
            or (not row["is_closed"] and (
                not isinstance(row.get("opening_time"), str)
                or not isinstance(row.get("closing_time"), str)
                or len(row["opening_time"]) != 5
                or len(row["closing_time"]) != 5
            ))
        ):
            return error_response("Check each operating-hours day, time and closed status.", status_code=400)
        if not row["is_closed"]:
            try:
                datetime.datetime.strptime(row["opening_time"], "%H:%M")
                datetime.datetime.strptime(row["closing_time"], "%H:%M")
            except ValueError:
                return error_response("Operating times must use 24-hour HH:MM format.", status_code=400)
    try:
        service = query_db("SELECT id FROM services WHERE id=%s", (service_id,), fetchone=True)
        if not service:
            return error_response("Service not found.", status_code=404)
        service_fields = {
            "title": str(payload["title"]).strip()[:180],
            "card_title": str(payload["card_title"]).strip()[:180],
            "badge": str(payload.get("badge", "")).strip()[:80] or None,
            "description": str(payload["description"]).strip(),
            "icon_name": str(payload.get("icon_name", "")).strip()[:80] or None,
            "is_active": bool(payload.get("is_active", True)),
        }
        detail_fields = {
            "detail_title": str(payload.get("detail_title", "")).strip()[:150],
            "detail_description": str(payload.get("detail_description", "")).strip(),
            "overview": str(payload.get("overview", "")).strip(),
            "relevance": str(payload.get("relevance", "")).strip()[:255],
            "intake_desk_text": str(payload.get("intake_desk_text", "")).strip(),
            "eligibility_note": str(payload.get("eligibility_note", "")).strip()[:255] or None,
            "cost_info": str(payload.get("cost_info", "")).strip(),
            "contact_info": str(payload.get("contact_info", "")).strip(),
            "website_url": str(payload.get("website_url", "")).strip()[:500],
        }
        if any(len(row.get("notes", "")) > 1000 for row in hours if isinstance(row.get("notes", ""), str)):
            return error_response("Operating-hours notes must be 1000 characters or fewer.", status_code=400)
        with _admin_transaction() as cursor:
            cursor.execute(
            """
            UPDATE services SET title=%s, card_title=%s, badge=%s, description=%s,
                icon_name=%s, is_active=%s WHERE id=%s
            """,
            (
                service_fields["title"],
                service_fields["card_title"],
                service_fields["badge"],
                service_fields["description"],
                service_fields["icon_name"],
                service_fields["is_active"],
                service_id,
            ),
            )
            cursor.execute(
            """
            INSERT INTO service_details
                (service_id, detail_title, detail_description, overview, relevance,
                 intake_desk_text, eligibility_note, cost_info, contact_info, website_url)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                detail_title=VALUES(detail_title),
                detail_description=VALUES(detail_description),
                overview=VALUES(overview), relevance=VALUES(relevance),
                intake_desk_text=VALUES(intake_desk_text),
                eligibility_note=VALUES(eligibility_note), cost_info=VALUES(cost_info),
                contact_info=VALUES(contact_info), website_url=VALUES(website_url)
            """,
            (
                service_id,
                detail_fields["detail_title"],
                detail_fields["detail_description"],
                detail_fields["overview"],
                detail_fields["relevance"],
                detail_fields["intake_desk_text"],
                detail_fields["eligibility_note"],
                detail_fields["cost_info"],
                detail_fields["contact_info"],
                detail_fields["website_url"],
            ),
            )
            cursor.execute("DELETE FROM service_eligibility WHERE service_id=%s", (service_id,))
            for order, criterion in enumerate(eligibility):
                criterion = criterion.strip()
                if criterion:
                    cursor.execute(
                    "INSERT INTO service_eligibility (service_id, criterion, display_order) VALUES (%s, %s, %s)",
                    (service_id, criterion, order),
                    )
            cursor.execute("DELETE FROM service_hours WHERE service_id=%s", (service_id,))
            for row in hours:
                cursor.execute(
                """
                INSERT INTO service_hours
                    (service_id, day_of_week, opening_time, closing_time, is_closed, notes)
                VALUES (%s, %s, %s, %s, %s, %s)
                """,
                (
                    service_id,
                    row["day_of_week"],
                    None if row["is_closed"] else row["opening_time"],
                    None if row["is_closed"] else row["closing_time"],
                    row["is_closed"],
                    str(row.get("notes", "")).strip() or None,
                ),
                )
        _safe_audit("SERVICE_UPDATED", "SERVICE", service_id, f"Updated service {service_id}")
        return success_response(message="Service information updated.")
    except Exception as error:
        logger.error("Admin service update failed: %s", type(error).__name__)
        return error_response("Could not update the service.", status_code=500)


@admin_bp.route("/admin/settings", methods=["GET", "PATCH"])
@require_auth
@require_admin
def manage_settings():
    if request.method == "GET":
        try:
            settings = query_db(
                "SELECT setting_key, setting_value, is_public, updated_at FROM site_settings ORDER BY setting_key"
            )
            _format_datetime_rows(settings, "updated_at")
            return success_response(data={"settings": settings})
        except Exception as error:
            logger.error("Admin settings lookup failed: %s", type(error).__name__)
            return error_response("Could not load website settings.", status_code=500)
    payload = _json_payload()
    if payload is None or not isinstance(payload.get("settings"), dict):
        return error_response("Provide a settings object.", status_code=400)
    public_keys = {"site_name", "contact_phone", "contact_email", "address", "opening_hours"}
    allowed_keys = public_keys
    for key, value in payload["settings"].items():
        if key not in allowed_keys or not isinstance(value, str):
            return error_response(f"Invalid website setting: {key}.", status_code=400)
        if len(value) > 2000:
            return error_response(f"Website setting {key} must be 2000 characters or fewer.", status_code=400)
        if key == "contact_email" and value and ("@" not in value or len(value.split("@", 1)[-1]) < 3):
            return error_response("Enter a valid contact email address.", status_code=400)
        if key == "site_name" and len(value.strip()) > 100:
            return error_response("Site name must be 100 characters or fewer.", status_code=400)
    try:
        with _admin_transaction() as cursor:
            for key, value in payload["settings"].items():
                cursor.execute(
                """
                INSERT INTO site_settings (setting_key, setting_value, is_public, updated_by)
                VALUES (%s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),
                    is_public=VALUES(is_public), updated_by=VALUES(updated_by)
                """,
                (key, value.strip()[:2000], key in public_keys, request.current_user["id"]),
                )
        _safe_audit("SITE_SETTINGS_UPDATED", "SITE_SETTINGS", None, "Updated public website settings")
        return success_response(message="Website settings saved.")
    except Exception as error:
        logger.error("Admin settings update failed: %s", type(error).__name__)
        return error_response("Could not save website settings.", status_code=500)


@admin_bp.route("/admin/users", methods=["GET", "PATCH"])
@require_auth
@require_admin
def manage_staff_roles():
    if request.method == "GET":
        try:
            users = query_db(
                "SELECT id, name, email, role, is_active, created_at FROM users ORDER BY name LIMIT 500"
            )
            _format_datetime_rows(users, "created_at")
            return success_response(data={"users": users})
        except Exception as error:
            logger.error("Admin user lookup failed: %s", type(error).__name__)
            return error_response("Could not load staff accounts.", status_code=500)
    payload = _json_payload()
    if payload is None:
        return error_response("Invalid request. JSON payload required.", status_code=400)
    try:
        user_id = int(payload.get("user_id"))
    except (TypeError, ValueError):
        return error_response("Choose a valid account.", status_code=400)
    role = str(payload.get("role", "")).lower()
    if role not in ("user", "admin"):
        return error_response("Role must be user or admin.", status_code=400)
    if user_id == request.current_user["id"] and role != "admin":
        return error_response("You cannot remove your own administrator access.", status_code=400)
    try:
        target = query_db("SELECT id, role FROM users WHERE id=%s AND is_active=TRUE", (user_id,), fetchone=True)
        if not target:
            return error_response("Active account not found.", status_code=404)
        if role == "admin" and target["role"] != "admin":
            users = query_db("SELECT COUNT(*) AS total FROM users WHERE role='admin' AND is_active=TRUE", fetchone=True)
            if users["total"] >= 20:
                return error_response("The administrator limit has been reached.", status_code=409)
        if target["role"] == "admin" and role == "user":
            admins = query_db("SELECT COUNT(*) AS total FROM users WHERE role='admin' AND is_active=TRUE", fetchone=True)
            if admins["total"] <= 1:
                return error_response("The last active administrator cannot be removed.", status_code=409)
        execute_db("UPDATE users SET role=%s WHERE id=%s", (role, user_id))
        _safe_audit("USER_ROLE_UPDATED", "USER", user_id, f"Changed user role to {role}")
        return success_response(message="Account permissions updated.")
    except Exception as error:
        logger.error("Admin user role update failed: %s", type(error).__name__)
        return error_response("Could not update account permissions.", status_code=500)


@admin_bp.route("/admin/reports", methods=["GET"])
@require_auth
@require_admin
def admin_reports():
    try:
        bookings = query_db(
            """
            SELECT DATE(starts_at) AS report_date, status, COUNT(*) AS total
            FROM appointments
            WHERE starts_at >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
            GROUP BY DATE(starts_at), status ORDER BY report_date DESC
            """
        )
        enquiries = query_db(
            """
            SELECT status, COUNT(*) AS total
            FROM contact_enquiries GROUP BY status ORDER BY status
            """
        )
        monthly_bookings = query_db(
            """
            SELECT DATE_FORMAT(starts_at, '%Y-%m') AS report_month, status, COUNT(*) AS total
            FROM appointments
            WHERE starts_at >= DATE_SUB(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL 5 MONTH)
              AND starts_at < DATE_ADD(LAST_DAY(CURDATE()), INTERVAL 1 DAY)
            GROUP BY report_month, status
            ORDER BY report_month ASC, status ASC
            """
        )
        _format_datetime_rows(bookings, "report_date")
        return success_response(data={
            "appointments": bookings,
            "monthly_appointments": monthly_bookings,
            "enquiries": enquiries,
        })
    except Exception as error:
        logger.error("Admin report lookup failed: %s", type(error).__name__)
        return error_response("Could not load reports.", status_code=500)


@admin_bp.route("/admin/notifications", methods=["PATCH"])
@require_auth
@require_admin
def mark_notification_read():
    payload = _json_payload()
    try:
        notification_id = int(payload.get("id")) if payload else None
    except (TypeError, ValueError):
        notification_id = None
    if not notification_id:
        return error_response("Choose a valid notification.", status_code=400)
    try:
        notification = query_db("SELECT id FROM admin_notifications WHERE id=%s", (notification_id,), fetchone=True)
        if not notification:
            return error_response("Notification not found.", status_code=404)
        changed = execute_db(
            "UPDATE admin_notifications SET is_read=TRUE WHERE id=%s",
            (notification_id,),
        )
        _safe_audit("NOTIFICATION_READ", "ADMIN_NOTIFICATION", notification_id, "Marked admin notification as read")
        return success_response(message="Notification marked as read.")
    except Exception as error:
        logger.error("Admin notification update failed: %s", type(error).__name__)
        return error_response("Could not update the notification.", status_code=500)


@admin_bp.route("/admin/activity", methods=["GET"])
@require_auth
@require_admin
def admin_activity():
    try:
        entries = query_db(
            """
            SELECT l.id, l.action, l.entity_type, l.entity_id, l.description,
                   l.created_at, u.name AS actor
            FROM audit_log l
            LEFT JOIN users u ON u.id = l.user_id
            WHERE l.user_id IS NOT NULL
            ORDER BY l.created_at DESC
            LIMIT 300
            """
        )
        _format_datetime_rows(entries, "created_at")
        return success_response(data={"entries": entries})
    except Exception as error:
        logger.error("Admin activity lookup failed: %s", type(error).__name__)
        return error_response("Could not load the activity log.", status_code=500)
