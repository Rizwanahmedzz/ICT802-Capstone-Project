import datetime
import logging
import re
from contextlib import contextmanager

from flask import Blueprint, request
from mysql.connector import IntegrityError, errorcode, Error
from backend.db import execute_db, query_db
from backend.services.appointment_notifications import send_appointment_confirmation
from backend.utils.auth import require_auth
from backend.utils.responses import error_response, success_response

logger = logging.getLogger(__name__)
appointments_bp = Blueprint("appointments", __name__)

DEMO_START_HOUR = 9
DEMO_END_HOUR = 17
DEMO_SLOT_MINUTES = 30


@contextmanager
def _booking_transaction():
    from backend.db import get_db_cursor

    with get_db_cursor(commit=True) as cursor:
        try:
            yield cursor
        except Exception:
            cursor.connection.rollback()
            raise


def format_slot_datetime(value):
    if isinstance(value, str):
        value = datetime.datetime.fromisoformat(value)
    if not isinstance(value, datetime.datetime):
        raise TypeError("Appointment timestamp must be a datetime.")
    return value.strftime("%Y-%m-%dT%H:%M")


def parse_booking_date(value):
    if not isinstance(value, str):
        return None
    try:
        return datetime.datetime.strptime(value, "%Y-%m-%dT%H:%M")
    except ValueError:
        return None


def valid_demo_slot(starts_at):
    now = datetime.datetime.now()
    return (
        starts_at > now
        and starts_at.weekday() < 5
        and DEMO_START_HOUR <= starts_at.hour < DEMO_END_HOUR
        and starts_at.minute in (0, 30)
        and starts_at.second == 0
        and starts_at.microsecond == 0
    )


@appointments_bp.route("/appointments/availability", methods=["GET"])
def get_availability():
    date_value = request.args.get("date", "")
    try:
        selected_date = datetime.datetime.strptime(date_value, "%Y-%m-%d").date()
    except ValueError:
        return error_response("Choose a valid appointment date.", status_code=400)

    if selected_date < datetime.date.today():
        return error_response("Choose today or a future date.", status_code=400)

    if selected_date.weekday() >= 5:
        return success_response(data={"date": date_value, "slots": []})

    day_start = datetime.datetime.combine(selected_date, datetime.time(DEMO_START_HOUR))
    day_end = datetime.datetime.combine(selected_date, datetime.time(DEMO_END_HOUR))
    try:
        configured_slots = query_db(
            """
            SELECT starts_at, is_active
            FROM appointment_slots
            WHERE starts_at >= %s AND starts_at < %s
            ORDER BY starts_at
            """,
            (datetime.datetime.combine(selected_date, datetime.time.min),
             datetime.datetime.combine(selected_date + datetime.timedelta(days=1), datetime.time.min)),
        )
        booked = query_db(
            """
            SELECT starts_at
            FROM appointments
            WHERE status = 'CONFIRMED' AND starts_at >= %s AND starts_at < %s
            """,
            (day_start, day_end),
        )
    except Exception as error:
        logger.error("Appointment availability lookup failed: %s", type(error).__name__)
        return error_response("Could not load appointment availability. Please try again.", status_code=500)

    booked_times = {format_slot_datetime(row["starts_at"]) for row in booked}
    now = datetime.datetime.now()
    if configured_slots:
        return success_response(
            data={
                "date": date_value,
                "slots": [
                    format_slot_datetime(row["starts_at"])
                    for row in configured_slots
                    if row["is_active"]
                    and row["starts_at"] > now
                    and format_slot_datetime(row["starts_at"]) not in booked_times
                ],
            }
        )

    slots = []
    slot_time = day_start
    while slot_time < day_end:
        slot_value = slot_time.strftime("%Y-%m-%dT%H:%M")
        if slot_time > now and slot_value not in booked_times:
            slots.append(slot_value)
        slot_time += datetime.timedelta(minutes=DEMO_SLOT_MINUTES)

    return success_response(data={"date": date_value, "slots": slots})


@appointments_bp.route("/appointments", methods=["POST"])
@require_auth
def book_appointment():
    return _create_booking(request.current_user["id"], None, None, request.current_user["email"])


@appointments_bp.route("/appointments/guest", methods=["POST"])
def book_guest_appointment():
    payload = request.get_json(silent=True) if request.is_json else None
    if not isinstance(payload, dict):
        return error_response("Request payload is invalid.", status_code=400)
    name = str(payload.get("name") or "").strip()
    contact = str(payload.get("contact") or "").strip()
    if not 2 <= len(name) <= 120:
        return error_response("Please enter your name.", status_code=400)
    is_email = bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", contact))
    is_phone = bool(re.fullmatch(r"\+?[0-9 ()\-]{8,20}", contact))
    if not (is_email or is_phone) or len(contact) > 190:
        return error_response("Please enter a valid email address or phone number.", status_code=400)
    return _create_booking(None, name, contact, contact if is_email else None)


def _create_booking(user_id, guest_name, guest_contact, email):
    if not request.is_json:
        return error_response("Invalid request. JSON payload required.", status_code=400)

    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return error_response("Request payload is invalid.", status_code=400)

    starts_at = parse_booking_date(payload.get("starts_at"))
    if starts_at is None:
        return error_response("Choose a valid appointment date and time.", status_code=400)

    service_title = str(payload.get("service") or "").strip()[:100] or None
    if service_title:
        try:
            known = query_db(
                "SELECT title FROM services WHERE is_active=TRUE AND title=%s",
                (service_title,), fetchone=True,
            )
        except Exception:
            known = None
        if not known:
            return error_response("Please choose a valid service.", status_code=400)

    try:
        configured_for_day = query_db(
            """
            SELECT id, is_active FROM appointment_slots
            WHERE starts_at = %s
            """,
            (starts_at,),
            fetchone=True,
        )
        any_configured_for_day = query_db(
            """
            SELECT id FROM appointment_slots
            WHERE starts_at >= %s AND starts_at < %s
            LIMIT 1
            """,
            (
                datetime.datetime.combine(starts_at.date(), datetime.time.min),
                datetime.datetime.combine(starts_at.date() + datetime.timedelta(days=1), datetime.time.min),
            ),
            fetchone=True,
        )
    except Exception as error:
        logger.error("Appointment slot validation failed: %s", type(error).__name__)
        return error_response("Could not verify appointment availability. Please try again.", status_code=500)
    if not valid_demo_slot(starts_at):
        return error_response(
            "Choose an available weekday time between 9:00 am and 4:30 pm.",
            status_code=400,
        )
    if any_configured_for_day and (
        not configured_for_day
        or not configured_for_day["is_active"]
        or starts_at <= datetime.datetime.now()
    ):
        return error_response("Choose an available appointment time.", status_code=400)
    try:
        with _booking_transaction() as cursor:
            if any_configured_for_day:
                cursor.execute(
                    "SELECT is_active FROM appointment_slots WHERE id=%s FOR UPDATE",
                    (configured_for_day["id"],),
                )
                current_slot = cursor.fetchone()
                if not current_slot or not current_slot["is_active"]:
                    raise _UnavailableSlotError()
            cursor.execute(
                """
                INSERT INTO appointments (user_id, guest_name, guest_contact, service_title, starts_at, status)
                VALUES (%s, %s, %s, %s, %s, 'CONFIRMED')
                """,
                (user_id, guest_name, guest_contact, service_title, starts_at),
            )
            appointment_id = cursor.lastrowid
            if any_configured_for_day:
                cursor.execute(
                    "UPDATE appointment_slots SET is_active=FALSE WHERE id=%s",
                    (configured_for_day["id"],),
                )
            cursor.execute(
                """
                INSERT INTO admin_notifications
                    (notification_type, title, message, source_type, source_id)
                VALUES ('APPOINTMENT', 'New appointment reservation', %s, 'APPOINTMENT', %s)
                """,
                (f"New appointment reservation for {starts_at:%Y-%m-%d %H:%M}", appointment_id),
            )
    except _UnavailableSlotError:
        return error_response("That time was just reserved. Please choose another slot.", status_code=409)
    except IntegrityError as error:
        if error.errno == errorcode.ER_DUP_ENTRY:
            return error_response("That time was just booked. Please choose another slot.", status_code=409)
        logger.error("Appointment booking integrity failure: %s", error.errno)
        return error_response("Could not book that appointment. Please try again.", status_code=500)
    except Error as error:
        logger.error("Appointment write failed: %s", type(error).__name__)
        return error_response("Could not book that appointment. Please try again.", status_code=500)
    except Exception as error:
        logger.error("Appointment booking failed: %s", type(error).__name__)
        return error_response("Could not book that appointment. Please try again.", status_code=500)

    email_sent = send_appointment_confirmation(email, starts_at) if email else False
    return success_response(
        data={
            "id": appointment_id,
            "starts_at": starts_at.strftime("%Y-%m-%dT%H:%M"),
            "status": "CONFIRMED",
            "email_sent": email_sent,
        },
        message=(
            "Your reservation has been recorded and a confirmation email was sent."
            if email_sent
            else "Your reservation has been recorded."
        ),
        status_code=201,
    )


@appointments_bp.route("/appointments/mine", methods=["GET"])
@require_auth
def get_my_appointments():
    try:
        appointments = query_db(
            """
            SELECT id, starts_at, status, service_title
            FROM appointments
            WHERE user_id = %s
            ORDER BY starts_at ASC
            """,
            (request.current_user["id"],),
        )
    except Exception as error:
        logger.error("User appointment lookup failed: %s", type(error).__name__)
        return error_response("Could not load your appointments. Please try again.", status_code=500)

    for appointment in appointments:
        appointment["starts_at"] = format_slot_datetime(appointment["starts_at"])

    return success_response(data=appointments)


class _UnavailableSlotError(Exception):
    pass
