from .organization import organization_bp
from .services import services_bp
from .faqs import faqs_bp
from .feedback import feedback_bp
from .knowledge import knowledge_bp
from .assistant import assistant_bp
from .auth import auth_bp
from .appointments import appointments_bp
from .admin import admin_bp
from .site_content import site_content_bp

__all__ = [
    "organization_bp",
    "services_bp",
    "faqs_bp",
    "feedback_bp",
    "knowledge_bp",
    "assistant_bp",
    "auth_bp",
    "appointments_bp",
    "admin_bp",
    "site_content_bp"
]
