import logging
from flask import Blueprint
from backend.db import query_db
from backend.utils.responses import success_response, error_response

logger = logging.getLogger(__name__)
faqs_bp = Blueprint("faqs", __name__)

@faqs_bp.route("/faqs", methods=["GET"])
def get_faqs():
    """
    GET /api/faqs
    Returns active FAQs ordered by display_order.
    """
    try:
        query = """
            SELECT id, question, answer, category, display_order
            FROM faqs
            WHERE is_active = TRUE
            ORDER BY display_order ASC
        """
        faqs = query_db(query)
        return success_response(data=faqs)
    except Exception as e:
        logger.error(f"Error fetching FAQs: {e}")
        return error_response("Internal server error", status_code=500)


@faqs_bp.route("/faqs/<int:faq_id>", methods=["GET"])
def get_single_faq(faq_id):
    """
    GET /api/faqs/<faq_id>
    Returns single FAQ.
    """
    try:
        query = """
            SELECT id, question, answer, category, display_order
            FROM faqs
            WHERE id = %s AND is_active = TRUE
        """
        faq = query_db(query, (faq_id,), fetchone=True)
        if not faq:
            return error_response("FAQ not found", status_code=404)
        
        return success_response(data=faq)
    except Exception as e:
        logger.error(f"Error fetching FAQ {faq_id}: {e}")
        return error_response("Internal server error", status_code=500)
