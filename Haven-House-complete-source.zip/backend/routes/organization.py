import logging
from flask import Blueprint
from backend.db import query_db
from backend.utils.responses import success_response, error_response

logger = logging.getLogger(__name__)
organization_bp = Blueprint("organization", __name__)

@organization_bp.route("/organization", methods=["GET"])
def get_organization():
    """
    GET /api/organization
    Returns Haven House organization info and navigation disclaimer.
    """
    try:
        query = """
            SELECT id, name, tagline, location, established_period, disclaimer
            FROM organization
            ORDER BY id ASC
            LIMIT 1
        """
        org = query_db(query, fetchone=True)
        if not org:
            return error_response("Organization information not found", status_code=404)
        
        return success_response(data=org)
    except Exception as e:
        logger.error(f"Error fetching organization data: {e}")
        return error_response("Internal server error", status_code=500)
