import logging
import hmac
import secrets
import time
import datetime
from collections import defaultdict
from flask import Blueprint, request
from werkzeug.exceptions import HTTPException
from backend.config import Config
from backend.db import query_db, execute_db, cleanup_expired_otp_challenges, get_db_cursor
from backend.services.otp_delivery import deliver_otp, mask_destination
from backend.utils.responses import success_response, error_response
from backend.utils.validation import (
    validate_email,
    validate_name,
    validate_password,
    validate_otp_code,
    validate_challenge_id
)
from backend.utils.auth import (
    hash_password,
    verify_password,
    generate_secure_otp,
    generate_challenge_id,
    hash_otp,
    verify_otp_hash,
    create_access_token,
    require_auth,
    sanitize_user
)

logger = logging.getLogger(__name__)
auth_bp = Blueprint("auth", __name__)

# Feature 5: In-memory sliding window rate limiter per IP / identifier
RATE_LIMIT_STORE = defaultdict(list)
MAX_ATTEMPTS_PER_WINDOW = 5
WINDOW_SECONDS = 60


def check_rate_limit(key_identifier: str, action: str, max_attempts: int = MAX_ATTEMPTS_PER_WINDOW, window_secs: int = WINDOW_SECONDS) -> bool:
    """
    Generic rate limit checker with sliding timestamp window.
    Returns True if within limit, False if rate limited.
    """
    key = f"{action}:{key_identifier}"
    now = time.time()
    RATE_LIMIT_STORE[key] = [t for t in RATE_LIMIT_STORE[key] if now - t < window_secs]

    if len(RATE_LIMIT_STORE[key]) >= max_attempts:
        try:
            execute_db(
                "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (NULL, 'RATE_LIMIT_TRIGGERED', 'security', %s)",
                (f"Rate limit exceeded for action: {action}",)
            )
        except Exception:
            pass
        return False

    RATE_LIMIT_STORE[key].append(now)
    return True


@auth_bp.route("/auth/register", methods=["POST"])
def register():
    """
    POST /api/auth/register
    Registers a new standard user with securely hashed password.
    Enforces centralized input validation, email normalization, and duplicate checks.
    """
    client_ip = request.remote_addr or "127.0.0.1"
    if not check_rate_limit(client_ip, "register"):
        return error_response("Too many registration attempts. Please try again in a minute.", status_code=429)

    try:
        if not request.is_json:
            return error_response("Invalid request. JSON payload required.", status_code=400)

        payload = request.get_json()
        if not payload:
            return error_response("Request payload is empty.", status_code=400)

        # 1. Feature 1: Centralized Input Validation
        name_ok, name, name_err = validate_name(payload.get("name"))
        if not name_ok:
            return error_response(name_err, status_code=400)

        email_ok, normalized_email, email_err = validate_email(payload.get("email"))
        if not email_ok:
            return error_response(email_err, status_code=400)

        pwd_ok, pwd_err = validate_password(payload.get("password"))
        if not pwd_ok:
            return error_response(pwd_err, status_code=400)

        # 2. Duplicate Email Check
        existing_user = query_db(
            "SELECT id FROM users WHERE email = %s LIMIT 1",
            (normalized_email,),
            one=True
        )
        if existing_user:
            return error_response("An account with this email already exists.", status_code=409)

        # 3. Secure Password Hashing (PBKDF2-SHA256)
        password_hash = hash_password(payload["password"])

        # 4. Insert New User (Enforcing role='user' and is_active=TRUE)
        insert_query = """
            INSERT INTO users (name, email, password_hash, role, is_active)
            VALUES (%s, %s, %s, 'user', TRUE)
        """
        user_id = execute_db(insert_query, (name, normalized_email, password_hash))

        # 5. Feature 5: Privacy-Preserving Audit Logging
        try:
            audit_query = """
                INSERT INTO audit_log (user_id, action, entity_type, entity_id, description)
                VALUES (%s, 'USER_REGISTERED', 'user', %s, 'New client registration completed')
            """
            execute_db(audit_query, (user_id, user_id))
        except Exception as audit_err:
            logger.warning(f"[Audit Log Warning] Could not log registration event: {audit_err}")

        # 6. Safe Success Response (No password or hash returned)
        return success_response(
            data={
                "user": {
                    "id": user_id,
                    "name": name,
                    "email": normalized_email
                }
            },
            message="Registration successful. Please log in.",
            status_code=201
        )

    except Exception as e:
        logger.error(f"[Registration Error] {e}")
        return error_response("Registration failed due to a server error. Please try again.", status_code=500)


@auth_bp.route("/auth/login", methods=["POST"])
def login():
    """
    POST /api/auth/login
    Step 1 of Two-Layer Authentication (Password Verification).
    Verifies credentials and issues a secure OTP challenge.
    CRITICAL: Does NOT issue the final JWT before Layer 2 OTP verification.
    """
    client_ip = request.remote_addr or "127.0.0.1"
    if not check_rate_limit(client_ip, "login"):
        return error_response("Too many login attempts. Please wait a minute before trying again.", status_code=429)

    try:
        # Feature 4: Periodically clean up expired OTP challenges
        cleanup_expired_otp_challenges()

        if not request.is_json:
            return error_response("Invalid request. JSON payload required.", status_code=400)

        payload = request.get_json()
        if not payload:
            return error_response("Request payload is empty.", status_code=400)

        email_ok, normalized_email, email_err = validate_email(payload.get("email"))
        if not email_ok:
            return error_response(email_err, status_code=400)

        password = payload.get("password")
        if not password or not isinstance(password, str):
            return error_response("Please enter your password.", status_code=400)

        # 1. Lookup user in database
        user = query_db(
            "SELECT id, name, email, phone, password_hash, role, is_active FROM users WHERE email = %s LIMIT 1",
            (normalized_email,),
            one=True
        )

        # 2. Generic authentication failure check (prevents user enumeration)
        if not user or not verify_password(password, user.get("password_hash")) or not user.get("is_active"):
            try:
                execute_db(
                    "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (NULL, 'LOGIN_FAILED', 'security', 'Failed login attempt: invalid credentials or inactive account')"
                )
            except Exception:
                pass
            return error_response("Invalid email or password.", status_code=401)

        # 3. Generate Cryptographically Secure 6-Digit OTP
        otp_code = generate_secure_otp(length=6)
        hashed_otp = hash_otp(otp_code)
        challenge_id = generate_challenge_id()

        delivery_method = Config.OTP_DELIVERY_METHOD
        destination = user.get("email") if delivery_method == "EMAIL" else (user.get("phone") or user.get("email"))

        # 4. Insert OTP Challenge Record
        insert_challenge_query = """
            INSERT INTO otp_challenges (
                challenge_id, user_id, purpose, otp_hash, delivery_method, 
                destination, attempt_count, max_attempts, expires_at
            )
            VALUES (%s, %s, 'LOGIN_2FA', %s, %s, %s, 0, %s, DATE_ADD(NOW(), INTERVAL %s MINUTE))
        """
        execute_db(
            insert_challenge_query,
            (
                challenge_id,
                user["id"],
                hashed_otp,
                delivery_method,
                destination,
                Config.OTP_MAX_ATTEMPTS,
                Config.OTP_EXPIRATION_MINUTES
            )
        )

        # 5. Dispatch OTP via Delivery Service
        if not deliver_otp(destination, delivery_method, otp_code):
            logger.error("[OTP Delivery Error] Could not deliver login verification code.")
            return error_response(
                "We could not send your verification code. Check the email settings or try again later.",
                status_code=503
            )

        # 6. Feature 5: Privacy-Preserving Audit Logging
        try:
            execute_db(
                "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (%s, 'OTP_REQUESTED', 'auth', %s)",
                (user["id"], f"OTP challenge issued via {delivery_method}")
            )
        except Exception:
            pass

        # 7. Return OTP Challenge Response (Zero Plaintext OTP / Zero final JWT)
        return success_response(
            data={
                "status": "otp_required",
                "challenge_id": challenge_id,
                "destination": mask_destination(destination, delivery_method),
                "method": delivery_method.lower(),
                "expires_in_seconds": Config.OTP_EXPIRATION_MINUTES * 60
            },
            message=f"Verification code sent to your {delivery_method.lower()}."
        )

    except Exception as e:
        logger.error(f"[Login Error] {e}")
        return error_response("Login failed due to a server error. Please try again.", status_code=500)


@auth_bp.route("/auth/request-otp", methods=["POST"])
def request_otp():
    """
    POST /api/auth/request-otp
    Resends/refreshes an active OTP challenge for the current user session.
    Enforces validation, cooldown, and request count limits.
    """
    client_ip = request.remote_addr or "127.0.0.1"
    if not check_rate_limit(client_ip, "request_otp", max_attempts=Config.OTP_MAX_REQUESTS, window_secs=600):
        return error_response("Too many verification requests. Please wait a few minutes before trying again.", status_code=429)

    try:
        if not request.is_json:
            return error_response("Invalid request. JSON payload required.", status_code=400)

        payload = request.get_json()
        cid_ok, challenge_id, cid_err = validate_challenge_id(payload.get("challenge_id"))
        if not cid_ok:
            return error_response(cid_err, status_code=400)

        # 1. Fetch existing challenge
        challenge = query_db(
            """
            SELECT id, user_id, destination, delivery_method, verified_at, used_at, created_at 
            FROM otp_challenges 
            WHERE challenge_id = %s AND purpose = 'LOGIN_2FA'
            LIMIT 1
            """,
            (challenge_id,),
            one=True
        )

        if not challenge or challenge.get("verified_at") or challenge.get("used_at"):
            return error_response("Invalid or expired verification challenge. Please log in again.", status_code=401)

        # 2. Cooldown check per challenge
        if not check_rate_limit(challenge_id, "otp_resend_cooldown", max_attempts=1, window_secs=Config.OTP_RESEND_COOLDOWN_SECONDS):
            return error_response(f"Please wait {Config.OTP_RESEND_COOLDOWN_SECONDS} seconds before requesting a new code.", status_code=429)

        # 3. Generate new OTP and update challenge record
        otp_code = generate_secure_otp(length=6)
        hashed_otp = hash_otp(otp_code)

        update_query = """
            UPDATE otp_challenges 
            SET otp_hash = %s, attempt_count = 0, expires_at = DATE_ADD(NOW(), INTERVAL %s MINUTE)
            WHERE id = %s
        """
        execute_db(update_query, (hashed_otp, Config.OTP_EXPIRATION_MINUTES, challenge["id"]))

        # 4. Dispatch new OTP
        destination = challenge["destination"]
        method = challenge["delivery_method"]
        if not deliver_otp(destination, method, otp_code):
            logger.error("[OTP Delivery Error] Could not deliver resent verification code.")
            return error_response(
                "We could not send your verification code. Check the email settings or try again later.",
                status_code=503
            )

        # 5. Feature 5: Privacy-Preserving Audit log
        try:
            execute_db(
                "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (%s, 'OTP_REQUESTED', 'auth', 'New OTP code resent')",
                (challenge["user_id"],)
            )
        except Exception:
            pass

        return success_response(
            data={
                "challenge_id": challenge_id,
                "destination": mask_destination(destination, method),
                "method": method.lower(),
                "expires_in_seconds": Config.OTP_EXPIRATION_MINUTES * 60
            },
            message=f"A new verification code has been sent to your {method.lower()}."
        )

    except Exception as e:
        logger.error(f"[Resend OTP Error] {e}")
        return error_response("Unable to resend verification code. Please try again.", status_code=500)


@auth_bp.route("/auth/password-reset/request", methods=["POST"])
def request_password_reset():
    """Start a password reset without revealing whether an email has an account."""
    generic_message = "If an active account uses that email, a password reset code will be sent."
    client_ip = request.remote_addr or "127.0.0.1"
    if not check_rate_limit(client_ip, "password_reset_request", max_attempts=5, window_secs=600):
        return error_response("Too many reset requests. Please wait a few minutes and try again.", status_code=429)

    if not request.is_json:
        return error_response("Invalid request. JSON payload required.", status_code=400)

    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return error_response("Request payload is invalid.", status_code=400)

    email_ok, normalized_email, email_err = validate_email(payload.get("email"))
    if not email_ok:
        return error_response(email_err, status_code=400)

    try:
        cleanup_expired_otp_challenges()
        challenge_id = generate_challenge_id()
        user = query_db(
            "SELECT id, email FROM users WHERE email = %s AND is_active = TRUE LIMIT 1",
            (normalized_email,),
            one=True
        )
        if user:
            otp_code = generate_secure_otp(length=6)
            destination = user["email"]
            method = "EMAIL"
            execute_db(
                """
                UPDATE otp_challenges
                SET used_at = NOW()
                WHERE user_id = %s AND purpose = 'PASSWORD_RESET' AND used_at IS NULL
                """,
                (user["id"],)
            )
            execute_db(
                """
                INSERT INTO otp_challenges (
                    challenge_id, user_id, purpose, otp_hash, delivery_method,
                    destination, attempt_count, max_attempts, expires_at
                )
                VALUES (%s, %s, 'PASSWORD_RESET', %s, %s, %s, 0, %s,
                        DATE_ADD(NOW(), INTERVAL %s MINUTE))
                """,
                (
                    challenge_id,
                    user["id"],
                    hash_otp(otp_code),
                    method,
                    destination,
                    Config.OTP_MAX_ATTEMPTS,
                    Config.OTP_EXPIRATION_MINUTES
                )
            )
            if not deliver_otp(destination, method, otp_code, purpose="password reset"):
                logger.error("[Password Reset Delivery Error] Could not deliver reset code.")
            else:
                try:
                    execute_db(
                        "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (%s, 'PASSWORD_RESET_REQUESTED', 'auth', 'Password reset code requested')",
                        (user["id"],)
                    )
                except Exception as audit_error:
                    logger.warning("[Password Reset Audit Warning] Could not log request: %s", type(audit_error).__name__)

        return success_response(
            data={
                "challenge_id": challenge_id,
                "expires_in_seconds": Config.OTP_EXPIRATION_MINUTES * 60
            },
            message=generic_message
        )
    except Exception as error:
        logger.error("[Password Reset Request Error] %s", type(error).__name__)
        return error_response("Could not process the password reset request. Please try again.", status_code=500)


@auth_bp.route("/auth/password-reset/confirm", methods=["POST"])
def confirm_password_reset():
    """Verify a reset code and atomically consume it while changing the password."""
    client_ip = request.remote_addr or "127.0.0.1"
    if not check_rate_limit(client_ip, "password_reset_confirm", max_attempts=10, window_secs=600):
        return error_response("Too many reset attempts. Please wait a few minutes and try again.", status_code=429)

    if not request.is_json:
        return error_response("Invalid request. JSON payload required.", status_code=400)

    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return error_response("Request payload is invalid.", status_code=400)

    cid_ok, challenge_id, cid_err = validate_challenge_id(payload.get("challenge_id"))
    if not cid_ok:
        return error_response(cid_err, status_code=400)
    otp_ok, user_otp, otp_err = validate_otp_code(payload.get("otp"))
    if not otp_ok:
        return error_response(otp_err, status_code=400)
    password_ok, password_err = validate_password(payload.get("password"))
    if not password_ok:
        return error_response(password_err, status_code=400)

    try:
        with get_db_cursor(commit=True) as cursor:
            cursor.execute(
                """
                SELECT c.id, c.user_id, c.otp_hash, c.attempt_count, c.max_attempts,
                       c.expires_at, c.verified_at, c.used_at
                FROM otp_challenges c
                JOIN users u ON u.id = c.user_id
                WHERE c.challenge_id = %s
                  AND c.purpose = 'PASSWORD_RESET'
                  AND u.is_active = TRUE
                FOR UPDATE
                """,
                (challenge_id,)
            )
            challenge = cursor.fetchone()
            if not challenge or challenge.get("verified_at") or challenge.get("used_at"):
                return error_response("Invalid or expired reset code. Request a new one.", status_code=401)

            expires_at = challenge["expires_at"]
            if isinstance(expires_at, str):
                expires_at = datetime.datetime.fromisoformat(expires_at.replace("Z", ""))
            if expires_at <= datetime.datetime.now():
                return error_response("Your reset code has expired. Request a new one.", status_code=401)

            if challenge["attempt_count"] >= challenge["max_attempts"]:
                return error_response("Too many incorrect codes. Request a new reset code.", status_code=401)

            if not verify_otp_hash(user_otp, challenge["otp_hash"]):
                cursor.execute(
                    "UPDATE otp_challenges SET attempt_count = attempt_count + 1 WHERE id = %s",
                    (challenge["id"],)
                )
                cursor.execute(
                    "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (%s, 'PASSWORD_RESET_FAILED', 'auth', 'Incorrect password reset code')",
                    (challenge["user_id"],)
                )
                return error_response("Invalid reset code. Please try again.", status_code=401)

            cursor.execute(
                "UPDATE users SET password_hash = %s WHERE id = %s",
                (hash_password(payload["password"]), challenge["user_id"])
            )
            cursor.execute(
                "UPDATE otp_challenges SET verified_at = NOW(), used_at = NOW() WHERE id = %s",
                (challenge["id"],)
            )
            cursor.execute(
                "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (%s, 'PASSWORD_RESET', 'auth', 'Account password reset successfully')",
                (challenge["user_id"],)
            )

        return success_response(message="Your password has been reset. You can now sign in.")
    except Exception as error:
        logger.error("[Password Reset Confirmation Error] %s", type(error).__name__)
        return error_response("Could not reset your password. Please request a new code and try again.", status_code=500)


@auth_bp.route("/auth/verify-otp", methods=["POST"])
def verify_otp():
    """
    POST /api/auth/verify-otp
    Step 2 of Two-Layer Authentication.
    Validates 6-digit OTP code against secure hash and issues final authenticated JWT.
    """
    client_ip = request.remote_addr or "127.0.0.1"
    if not check_rate_limit(client_ip, "verify_otp", max_attempts=15, window_secs=60):
        return error_response("Too many verification attempts. Please wait a minute.", status_code=429)

    try:
        if not request.is_json:
            return error_response("Invalid request. JSON payload required.", status_code=400)

        payload = request.get_json()
        if not payload:
            return error_response("Request payload is empty.", status_code=400)

        cid_ok, challenge_id, cid_err = validate_challenge_id(payload.get("challenge_id"))
        if not cid_ok:
            return error_response(cid_err, status_code=400)

        otp_ok, user_otp, otp_err = validate_otp_code(payload.get("otp"))
        if not otp_ok:
            return error_response(otp_err, status_code=400)

        # 1. Fetch Challenge and User Record
        challenge = query_db(
            """
            SELECT c.id, c.challenge_id, c.user_id, c.purpose, c.otp_hash, 
                   c.attempt_count, c.max_attempts, c.expires_at, c.verified_at, c.used_at,
                   u.name, u.email, u.role, u.is_active
            FROM otp_challenges c
            JOIN users u ON c.user_id = u.id
            WHERE c.challenge_id = %s
            LIMIT 1
            """,
            (challenge_id,),
            one=True
        )

        if not challenge or challenge.get("purpose") != "LOGIN_2FA":
            return error_response("Invalid verification challenge. Please log in again.", status_code=401)

        if challenge.get("verified_at") or challenge.get("used_at"):
            return error_response("This verification code has already been used. Please log in again.", status_code=401)

        # 2. Check Expiration
        expires_at = challenge.get("expires_at")
        is_expired = False
        if expires_at:
            import datetime
            now_dt = datetime.datetime.now()
            if isinstance(expires_at, str):
                try:
                    exp_dt = datetime.datetime.fromisoformat(expires_at.replace("Z", ""))
                    is_expired = now_dt > exp_dt
                except Exception:
                    pass
            elif isinstance(expires_at, datetime.datetime):
                is_expired = now_dt > expires_at

        if is_expired:
            try:
                execute_db(
                    "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (%s, 'OTP_EXPIRED', 'auth', 'OTP verification attempted on expired challenge')",
                    (challenge["user_id"],)
                )
            except Exception:
                pass
            return error_response("Your verification code has expired. Please request a new code.", status_code=401)

        # 3. Check Attempt Limit
        if challenge.get("attempt_count", 0) >= challenge.get("max_attempts", Config.OTP_MAX_ATTEMPTS):
            try:
                execute_db(
                    "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (%s, 'OTP_LOCKED', 'security', 'Challenge locked due to maximum failed attempts')",
                    (challenge["user_id"],)
                )
            except Exception:
                pass
            return error_response("Too many verification attempts. Please request a new code.", status_code=401)

        # 4. Verify OTP Hash (PBKDF2-SHA256)
        is_valid = verify_otp_hash(user_otp, challenge.get("otp_hash"))

        if not is_valid:
            execute_db("UPDATE otp_challenges SET attempt_count = attempt_count + 1 WHERE id = %s", (challenge["id"],))
            try:
                execute_db(
                    "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (%s, 'OTP_VERIFICATION_FAILED', 'security', 'Incorrect OTP entered')",
                    (challenge["user_id"],)
                )
            except Exception:
                pass
            return error_response("Invalid verification code. Please try again.", status_code=401)

        # 5. Successful OTP Verification -> Mark Challenge Used & Update User
        execute_db(
            "UPDATE otp_challenges SET verified_at = NOW(), used_at = NOW() WHERE id = %s",
            (challenge["id"],)
        )
        try:
            execute_db("UPDATE users SET last_login_at = NOW() WHERE id = %s", (challenge["user_id"],))
        except Exception:
            pass

        # 6. Feature 5: Privacy-Preserving Audit Logging Success
        try:
            execute_db(
                "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (%s, 'OTP_VERIFICATION_SUCCESS', 'auth', 'Two-layer authentication completed successfully')",
                (challenge["user_id"],)
            )
            execute_db(
                "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (%s, 'LOGIN_SUCCESS', 'auth', 'Full session established')",
                (challenge["user_id"],)
            )
        except Exception:
            pass

        # 7. Issue Final Authenticated JWT Token
        user_role = challenge.get("role", "user")
        final_token = create_access_token(challenge["user_id"], role=user_role)

        # 8. Return Final Authenticated Session
        return success_response(
            data={
                "token": final_token,
                "user": sanitize_user(challenge)
            },
            message="Two-factor authentication successful."
        )

    except Exception as e:
        logger.error(f"[Verify OTP Error] {e}")
        return error_response("Verification failed due to a server error. Please try again.", status_code=500)


@auth_bp.route("/auth/admin-login", methods=["POST"])
def admin_login():
    """
    POST /api/auth/admin-login
    Admin sign-in with a username and passcode defined in the backend .env.
    No email or OTP delivery is involved.
    """
    client_ip = request.remote_addr or "127.0.0.1"
    if not check_rate_limit(client_ip, "admin_login", max_attempts=5, window_secs=60):
        return error_response("Too many attempts. Please wait a minute and try again.", status_code=429)

    if not Config.ADMIN_PASSCODE:
        return error_response("Admin sign-in is not configured. Set ADMIN_PASSCODE in the backend .env file.", status_code=503)

    payload = request.get_json(silent=True) if request.is_json else None
    if not isinstance(payload, dict):
        return error_response("Invalid request. JSON payload required.", status_code=400)

    username = str(payload.get("username") or "").strip()
    passcode = str(payload.get("passcode") or "")
    username_ok = hmac.compare_digest(username.lower().encode(), Config.ADMIN_USERNAME.lower().encode())
    passcode_ok = hmac.compare_digest(passcode.encode(), Config.ADMIN_PASSCODE.encode())
    if not (username_ok and passcode_ok):
        try:
            execute_db(
                "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (NULL, 'ADMIN_LOGIN_FAILED', 'security', 'Incorrect admin username or passcode')"
            )
        except Exception:
            pass
        return error_response("Invalid username or passcode.", status_code=401)

    try:
        admin_email = "admin@havenhouse.local"
        admin = query_db("SELECT id, name, email, role FROM users WHERE email = %s", (admin_email,), one=True)
        if not admin:
            execute_db(
                "INSERT INTO users (name, email, password_hash, role, is_email_verified, is_active) VALUES (%s, %s, %s, 'admin', 1, 1)",
                (Config.ADMIN_USERNAME, admin_email, hash_password(secrets.token_urlsafe(32))),
            )
        else:
            execute_db("UPDATE users SET role = 'admin', is_active = 1, last_login_at = NOW() WHERE id = %s", (admin["id"],))
        admin = query_db("SELECT id, name, email, role FROM users WHERE email = %s", (admin_email,), one=True)
        try:
            execute_db(
                "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (%s, 'ADMIN_LOGIN_SUCCESS', 'auth', 'Admin signed in with username and passcode')",
                (admin["id"],),
            )
        except Exception:
            pass
        token = create_access_token(admin["id"], role="admin")
        return success_response(
            data={"token": token, "user": sanitize_user(admin)},
            message="Admin sign-in successful.",
        )
    except Exception as e:
        logger.error(f"[Admin Login Error] {type(e).__name__}")
        return error_response("Sign-in failed due to a server error. Please try again.", status_code=500)


@auth_bp.route("/auth/me", methods=["GET"])
@require_auth
def get_current_user():
    """
    GET /api/auth/me
    Protected endpoint returning currently authenticated user profile.
    Requires valid final JWT token issued after successful OTP verification.
    """
    return success_response(
        data={"user": request.current_user},
        message="Authenticated user profile retrieved."
    )


@auth_bp.route("/auth/logout", methods=["POST"])
def logout():
    """
    POST /api/auth/logout
    Stateless JWT logout endpoint.
    Client removes stored token. Backend logs logout event if authorization token is provided.
    """
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        token = auth_header.split()[1]
        from backend.utils.auth import decode_access_token
        payload = decode_access_token(token)
        if payload and "sub" in payload:
            try:
                execute_db(
                    "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (%s, 'LOGOUT', 'auth', 'User logged out')",
                    (payload["sub"],)
                )
            except Exception:
                pass

    return success_response(
        data={"logged_out": True},
        message="Logout successful. Client token removed."
    )
