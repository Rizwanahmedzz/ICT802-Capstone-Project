import logging
import re

from flask import Blueprint, request

from backend.db import execute_db, query_db
from backend.utils.responses import error_response, success_response

logger = logging.getLogger(__name__)
site_content_bp = Blueprint("site_content", __name__)
EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@site_content_bp.route("/events", methods=["GET"])
def public_events():
    try:
        events = query_db(
            """
            SELECT id, title, description, starts_at, ends_at, schedule_label, location
            FROM events
            WHERE status = 'PUBLISHED' AND (starts_at >= NOW() OR starts_at IS NULL)
            ORDER BY starts_at IS NULL, starts_at
            LIMIT 100
            """
        )
        for event in events:
            for field in ("starts_at", "ends_at"):
                if event[field] is not None:
                    event[field] = event[field].isoformat()
        return success_response(data={"events": events})
    except Exception as error:
        logger.error("Public event lookup failed: %s", type(error).__name__)
        return error_response("Could not load events.", status_code=500)


@site_content_bp.route("/announcements", methods=["GET"])
def public_announcements():
    try:
        announcements = query_db(
            """
            SELECT id, title, body, published_at
            FROM announcements
            WHERE status = 'PUBLISHED'
            ORDER BY published_at DESC
            LIMIT 100
            """
        )
        for announcement in announcements:
            if announcement["published_at"] is not None:
                announcement["published_at"] = announcement["published_at"].isoformat()
        return success_response(data={"announcements": announcements})
    except Exception as error:
        logger.error("Public announcement lookup failed: %s", type(error).__name__)
        return error_response("Could not load announcements.", status_code=500)


@site_content_bp.route("/site-settings", methods=["GET"])
def public_settings():
    try:
        settings = query_db(
            "SELECT setting_key, setting_value FROM site_settings WHERE is_public=TRUE"
        )
        return success_response(data={item["setting_key"]: item["setting_value"] for item in settings})
    except Exception as error:
        logger.error("Public site settings lookup failed: %s", type(error).__name__)
        return error_response("Could not load website information.", status_code=500)


@site_content_bp.route("/contact-enquiries", methods=["POST"])
def submit_contact_enquiry():
    if not request.is_json:
        return error_response("Invalid request. JSON payload required.", status_code=400)
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return error_response("Request payload is invalid.", status_code=400)

    name = str(payload.get("name", "")).strip()
    email = str(payload.get("email", "")).strip()
    subject = str(payload.get("subject", "")).strip()
    message = str(payload.get("message", "")).strip()
    if (
        not name or len(name) > 150
        or not EMAIL_PATTERN.fullmatch(email) or len(email) > 255
        or not subject or len(subject) > 180
        or not message or len(message) > 5000
    ):
        return error_response("Enter a name, valid email, subject and message within the allowed lengths.", status_code=400)
    try:
        enquiry_id = execute_db(
            """
            INSERT INTO contact_enquiries (name, email, subject, message)
            VALUES (%s, %s, %s, %s)
            """,
            (name, email, subject, message),
        )
        try:
            execute_db(
                """
                INSERT INTO admin_notifications
                    (notification_type, title, message, source_type, source_id)
                VALUES ('CONTACT_ENQUIRY', 'New contact enquiry', %s, 'CONTACT_ENQUIRY', %s)
                """,
                (f"New enquiry: {subject[:100]}", enquiry_id),
            )
        except Exception as notification_error:
            logger.error("New contact enquiry notification creation failed: %s", type(notification_error).__name__)
            return error_response("Your message was saved but staff notification failed. Please try contacting the organisation directly.", status_code=500)
        return success_response(
            data={"id": enquiry_id},
            message="Your message has been received.",
            status_code=201,
        )
    except Exception as error:
        logger.error("Contact enquiry submission failed: %s", type(error).__name__)
        return error_response("Could not send your message. Please try again.", status_code=500)
