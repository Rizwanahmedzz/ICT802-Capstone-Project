import logging
from flask import Blueprint
from backend.db import query_db
from backend.routes.services import resolve_service_id
from backend.utils.responses import success_response, error_response

logger = logging.getLogger(__name__)
knowledge_bp = Blueprint("knowledge", __name__)

@knowledge_bp.route("/knowledge", methods=["GET"])
def get_approved_knowledge():
    """
    GET /api/knowledge
    CRITICAL RULE: Returns ONLY APPROVED and ACTIVE knowledge content.
    Pending or rejected content is strictly excluded from client consumption.
    """
    try:
        query = """
            SELECT id, content_type, reference_id, content_text, version, approved_at
            FROM knowledge_content
            WHERE approval_status = 'APPROVED' AND is_active = TRUE
            ORDER BY id ASC
        """
        records = query_db(query)
        return success_response(data=records)
    except Exception as e:
        logger.error(f"Error fetching approved knowledge: {e}")
        return error_response("Internal server error", status_code=500)


@knowledge_bp.route("/knowledge/service/<service_identifier>", methods=["GET"])
def get_service_knowledge(service_identifier):
    """
    GET /api/knowledge/service/<service_id_or_key>
    Returns ONLY APPROVED and ACTIVE knowledge for the specific service.
    Prepared for future client-signed knowledge assistant integration.
    """
    try:
        service_id = resolve_service_id(service_identifier)
        if not service_id:
            return error_response("Service not found", status_code=404)

        query = """
            SELECT id, content_type, reference_id, content_text, version, approved_at
            FROM knowledge_content
            WHERE reference_id = %s 
              AND content_type IN ('SERVICE', 'SERVICE_DETAIL')
              AND approval_status = 'APPROVED' 
              AND is_active = TRUE
            ORDER BY id ASC
        """
        records = query_db(query, (service_id,))
        return success_response(data=records)
    except Exception as e:
        logger.error(f"Error fetching service knowledge: {e}")
        return error_response("Internal server error", status_code=500)
