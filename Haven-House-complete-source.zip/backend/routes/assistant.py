import logging
import re
from flask import Blueprint, request
from werkzeug.exceptions import HTTPException
from backend.db import query_db, execute_db
from backend.utils.safety import is_crisis_intent
from backend.utils.responses import success_response, error_response
from backend.services.assistant_ai import (
    AssistantAIConfigurationError,
    AssistantAIError,
    generate_assistant_reply,
)

logger = logging.getLogger(__name__)
assistant_bp = Blueprint("assistant", __name__)

# Service category keyword mappings for deterministic service navigation
SERVICE_KEYWORD_MAP = {
    "accommodation": [
        r"\baccommodat",
        r"\bsomewhere to stay\b",
        r"\bhousing\b",
        r"\bshelter\b",
        r"\bsleep\b",
        r"\bhomeless\b",
        r"\bhomelessness\b",
        r"\bplace to live\b",
        r"\bbed\b",
        r"\bstaying\b",
        r"\brooms\b",
        r"\bcrisis accommodation\b",
        r"\btemporary accommodation\b",
        r"\btemporary housing\b"
    ],
    "child-support": [
        r"\bchild\b",
        r"\bchildren\b",
        r"\bkid\b",
        r"\bkids\b",
        r"\bhh kids\b",
        r"\bfamily\b",
        r"\byouth\b",
        r"\bparent\b",
        r"\bparenting\b",
        r"\bteen\b",
        r"\bteenager\b"
    ],
    "ndis": [
        r"\bndis\b",
        r"\bdisabilit",
        r"\bsupport coordination\b",
        r"\bndis plan\b",
        r"\bndis services\b",
        r"\bndis access\b"
    ],
    "psychology": [
        r"\bpsycholog",
        r"\bmental health\b",
        r"\bcounsel",
        r"\btherapy\b",
        r"\btherapist\b",
        r"\bemotional\b",
        r"\btrauma\b",
        r"\bcoping\b",
        r"\btalk to someone\b",
        r"\bwellbeing\b"
    ],
    "employment": [
        r"\bemploy",
        r"\bjob\b",
        r"\bjobs\b",
        r"\bwork\b",
        r"\bcareer\b",
        r"\bresume\b",
        r"\bcv\b",
        r"\binterview\b",
        r"\bfinding a job\b",
        r"\bvocational\b",
        r"\bhiring\b"
    ],
    "chaplaincy": [
        r"\bchaplain",
        r"\bpastoral\b",
        r"\bspiritual\b",
        r"\bfaith\b",
        r"\bbereavement\b",
        r"\bgrief\b",
        r"\bcomfort\b",
        r"\brabbi\b",
        r"\bprayer\b",
        r"\bjewish community\b"
    ],
    "general-info": [
        r"\bgeneral info\b",
        r"\bgeneral information\b",
        r"\babout haven house\b",
        r"\bbondi\b",
        r"\blocation\b",
        r"\bcontact\b",
        r"\bwho can i contact\b",
        r"\bphone\b",
        r"\bemail\b",
        r"\bhours\b",
        r"\bopening hours\b",
        r"\btimes\b",
        r"\bhistory\b"
    ]
}

# Patterns for general service catalog inquiries or broad assistance requests
GENERAL_INQUIRY_PATTERNS = [
    r"\bwhat services\b",
    r"\bwhat do you provide\b",
    r"\bwhat do you offer\b",
    r"\bwhat services are available\b",
    r"\bwhich service\b",
    r"\bwhich service is right\b",
    r"\bwhich service should i choose\b",
    r"\blist of services\b",
    r"\bexplore services\b",
    r"\ball services\b",
    r"^(i need )?help[\.!?]?$",
    r"^help me[\.!?]?$",
    r"^(i need )?support[\.!?]?$",
    r"^(i need )?assistance[\.!?]?$",
    r"\bi don't know (which|what) service\b"
]


def fetch_all_active_services():
    """Fetches all active services from MySQL database using parameterized query."""
    try:
        query = """
            SELECT id, service_key, title, card_title, badge, description, icon_name
            FROM services
            WHERE is_active = TRUE
            ORDER BY display_order ASC
        """
        return query_db(query) or []
    except Exception as e:
        logger.error(f"Error querying active services from database: {e}")
        return []


def search_approved_knowledge(message: str):
    """
    Searches approved and active knowledge content from database.
    CRITICAL RULE: Only records with approval_status = 'APPROVED' and is_active = TRUE are retrieved.
    """
    try:
        query = """
            SELECT id, content_type, reference_id, content_text
            FROM knowledge_content
            WHERE approval_status = 'APPROVED' AND is_active = TRUE
        """
        records = query_db(query) or []
        matched = []
        words = [w for w in re.findall(r"\w+", message.lower()) if len(w) > 3]
        for record in records:
            text = record.get("content_text", "").lower()
            if any(w in text for w in words):
                matched.append(record)
        return matched
    except Exception as e:
        logger.error(f"Error querying approved knowledge content: {e}")
        return []


def find_relevant_services(message: str, all_services: list):
    """
    Identifies matching service categories based on message contents.
    """
    normalized = message.lower()
    matched_keys = set()

    for service_key, patterns in SERVICE_KEYWORD_MAP.items():
        for pattern in patterns:
            if re.search(pattern, normalized):
                matched_keys.add(service_key)
                break

    matched_services = [s for s in all_services if s.get("service_key") in matched_keys]
    return matched_services


def is_general_inquiry(message: str) -> bool:
    """Checks if message is asking broadly about all Haven House services or general assistance."""
    normalized = message.lower().strip()
    return any(re.search(p, normalized) for p in GENERAL_INQUIRY_PATTERNS)


BOOKING_PATTERNS = [
    r"\bbook(ing|ed)?\b",
    r"\bappointments?\b",
    r"\bschedul(e|ing)\b",
    r"\bmake a (time|booking)\b",
    r"\bsee (a|someone|somebody)\b",
]


def is_booking_intent(message: str) -> bool:
    normalized = message.lower()
    return any(re.search(p, normalized) for p in BOOKING_PATTERNS)


@assistant_bp.route("/assistant", methods=["POST"])
def assistant_chat():
    """
    POST /api/assistant
    Service Navigation Assistant endpoint.
    Processes user inquiries against approved database records.
    Immediately hands off crisis/safety requests to human care without advice.
    """
    try:
        # 1. Validate JSON Payload
        if not request.is_json:
            return error_response("Invalid request. JSON payload required.", status_code=400)

        payload = request.get_json()
        # 1. Feature 1: Centralized Input Validation (Max 2000 chars, non-destructive to crisis safety)
        from backend.utils.validation import validate_assistant_message
        is_valid, user_message, val_error = validate_assistant_message(payload.get("message"), max_length=2000)
        if not is_valid:
            return error_response(val_error, status_code=400)

        # 2. CRITICAL SERVER-SIDE SAFETY GUARDRAIL
        # If crisis or safety concern is detected -> Immediate handoff with NO normal service search
        if is_crisis_intent(user_message):
            # Feature 4 & 5: Record minimal safety event metadata WITHOUT logging or storing crisis text
            try:
                from backend.db import execute_db
                execute_db(
                    "INSERT INTO audit_log (user_id, action, entity_type, description) VALUES (NULL, 'SAFETY_HANDOFF_TRIGGERED', 'safety', %s)",
                    ("Crisis intent detected; redirected to human crisis handoff pathway",)
                )
            except Exception:
                pass

            return success_response(
                data={
                    "message": "I'm sorry you're dealing with this. I'm not able to provide crisis advice. This needs to be handled by an approved human support pathway.",
                    "services": [],
                    "handoff": True
                }
            )

        # 4. Fetch Active Services from Database
        all_services = fetch_all_active_services()
        approved_knowledge = search_approved_knowledge(user_message)

        # 5. Service Category Matching
        matched_services = find_relevant_services(user_message, all_services)
        try:
            reply = generate_assistant_reply(
                user_message,
                all_services,
                approved_knowledge,
            )
        except AssistantAIConfigurationError as e:
            return error_response(str(e), status_code=503)
        except AssistantAIError as e:
            if e.status_code in (401, 403):
                message = "The OpenAI API key was rejected. Check OPENAI_API_KEY in the backend .env file."
            elif e.status_code == 429:
                message = "The AI chatbot has reached its provider quota. Check your OpenAI account and try again."
            else:
                message = "The AI service is temporarily unavailable. Please try again shortly."
            return error_response(message, status_code=502)

        # 6. Handle unmatched questions with the grounded AI response.
        if not matched_services:
            return success_response(
                data={
                    "message": reply,
                    "services": all_services if is_general_inquiry(user_message) else [],
                    "handoff": False,
                    "action": "book_appointment" if is_booking_intent(user_message) else None
                }
            )

        # 7. Generate Response Based on Matched Services
        if len(matched_services) == 1:
            service = matched_services[0]
            return success_response(
                data={
                    "message": reply,
                    "services": [service],
                    "handoff": False,
                    "action": "book_appointment" if is_booking_intent(user_message) else None
                }
            )

        elif len(matched_services) > 1:
            return success_response(
                data={
                    "message": reply,
                    "services": matched_services,
                    "handoff": False,
                    "action": "book_appointment" if is_booking_intent(user_message) else None
                }
            )

        # 8. No Match / Unknown Topic Fallback (Strict compliance with Approved Content rule)
        return success_response(
            data={
                "message": "I don't have approved information for that yet. I can help you explore the available Haven House services or connect you with the team.",
                "services": all_services,
                "handoff": False,
                    "action": "book_appointment" if is_booking_intent(user_message) else None
            }
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in assistant chat endpoint: {e}")
        return error_response("Internal server error", status_code=500)
