import logging
from flask import Blueprint, request
from backend.db import query_db, execute_db
from backend.utils.responses import success_response, error_response

logger = logging.getLogger(__name__)
feedback_bp = Blueprint("feedback", __name__)

@feedback_bp.route("/faqs/<int:faq_id>/feedback", methods=["POST"])
def submit_faq_feedback(faq_id):
    """
    POST /api/faqs/<faq_id>/feedback
    Records usefulness response ('YES' or 'NO') without collecting personal information.
    """
    try:
        # 1. Validate Content-Type & JSON Payload
        if not request.is_json:
            return error_response("Invalid request. JSON payload required.", status_code=400)
        
        payload = request.get_json()
        if not payload or "response" not in payload:
            return error_response("Missing 'response' field in request body.", status_code=400)
        
        response_val = str(payload.get("response", "")).strip().upper()
        if response_val not in ("YES", "NO"):
            return error_response("Response must be either 'YES' or 'NO'.", status_code=400)

        # 2. Verify FAQ Exists
        faq = query_db(
            "SELECT id FROM faqs WHERE id = %s AND is_active = TRUE",
            (faq_id,),
            fetchone=True
        )
        if not faq:
            return error_response("FAQ not found", status_code=404)

        # 3. Insert Feedback
        execute_db(
            """
            INSERT INTO faq_feedback (faq_id, response)
            VALUES (%s, %s)
            """,
            (faq_id, response_val)
        )

        # 4. Non-sensitive Audit Log
        try:
            execute_db(
                """
                INSERT INTO audit_log (user_id, action, entity_type, entity_id, description)
                VALUES (NULL, 'FAQ_FEEDBACK_SUBMITTED', 'FAQ', %s, %s)
                """,
                (faq_id, f"Feedback submitted: {response_val}")
            )
        except Exception as audit_err:
            logger.warning(f"Audit logging skipped for feedback: {audit_err}")

        return success_response(message="Feedback recorded", status_code=201)

    except Exception as e:
        logger.error(f"Error submitting FAQ feedback: {e}")
        return error_response("Internal server error", status_code=500)
