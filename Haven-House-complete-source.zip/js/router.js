/**
 * Haven House Client Router & Dynamic API View Coordinator
 * Manages 8 core prototype screens with clean URL hashing and backend API integration.
 */

const Router = {
  currentRoute: "home",
  previousRouteHash: null,
  lastRouteHash: null,
  backNavigationPending: false,
  selectedServiceId: "accommodation",
  cachedServices: [],
  currentServiceData: null,
  externalProviderUrls: {
    accommodation: "https://askizzy.org.au/",
    "child-support": "https://www.familyrelationships.gov.au/talk-someone/advice-line",
    ndis: "https://www.ndis.gov.au/contact",
    psychology: "https://www.lifeline.org.au/131114",
    employment: "https://www.workforceaustralia.gov.au/individuals/contact",
    "general-info": "https://askizzy.org.au/"
  },

  routes: [
    "home",
    "services-step-1",
    "services-step-2",
    "service-detail",
    "appointments",
    "appointment-confirmation",
    "admin",
    "assistant",
    "crisis-handoff",
    "about",
    "contact",
    "events",
    "login",
    "admin-login",
    "password-reset",
    "reset-password",
    "register",
    "otp-verification"
  ],

  init() {
    window.addEventListener("hashchange", () => this.handleHashChange());
    this.handleHashChange();
  },

  openProviderContact() {
    const serviceKey = this.currentServiceData && this.currentServiceData.service
      ? this.currentServiceData.service.service_key
      : null;
    const providerUrl = serviceKey ? this.externalProviderUrls[serviceKey] : null;
    if (providerUrl) {
      window.open(providerUrl, "_blank", "noopener,noreferrer");
    }
  },

  handleHashChange() {
    const currentHash = window.location.hash || "#/home";
    if (this.backNavigationPending) {
      this.backNavigationPending = false;
      this.previousRouteHash = null;
    } else if (this.lastRouteHash && this.lastRouteHash !== currentHash) {
      this.previousRouteHash = this.lastRouteHash;
    }
    this.lastRouteHash = currentHash;

    let hash = window.location.hash.replace(/^#\/?/, "");
    if (!hash) hash = "home";

    const parts = hash.split("/");
    const route = parts[0];
    const param = parts[1];

    if (param && (route === "service-detail" || route === "services-step-2")) {
      this.selectedServiceId = param;
    }

    if (this.routes.includes(route)) {
      this.showScreen(route, param);
    } else {
      this.showScreen("home");
    }
  },

  navigate(route, param = null) {
    if (param) {
      window.location.hash = `#/${route}/${param}`;
    } else {
      window.location.hash = `#/${route}`;
    }
  },

  // Replaces the current history entry so Back never returns to a page that just redirected.
  redirect(route) {
    window.location.replace(`${window.location.pathname}${window.location.search}#/${route}`);
  },

  goBack() {
    if (this.previousRouteHash) {
      this.backNavigationPending = true;
      window.history.back();
      return;
    }
    this.navigate("home");
  },

  openAdminLogin() {
    sessionStorage.setItem("haven_house_after_login_route", "admin");
  },

  async showScreen(route, param = null) {
    if (
      (route === "appointments" || route === "appointment-confirmation")
      && (!window.AuthManager || !AuthManager.isAuthenticated())
    ) {
      sessionStorage.setItem("haven_house_after_login_route", "appointments");
      this.redirect("login");
      return;
    }
    if (route === "appointment-confirmation" && !sessionStorage.getItem("haven_house_appointment_confirmation")) {
      this.redirect("appointments");
      return;
    }
    if (route === "reset-password" && (!window.AuthManager || !AuthManager.pendingPasswordReset)) {
      this.redirect("password-reset");
      return;
    }
    if (route === "admin" && (!window.AuthManager || !AuthManager.isAuthenticated())) {
      this.redirect("admin-login");
      return;
    }
    if (route === "admin" && AuthManager.currentUser?.role !== "admin") {
      this.redirect("admin-login");
      return;
    }

    this.currentRoute = route;
    document.body.classList.toggle("inner-page", route !== "home");
    if (window.AdminSessionGuard) {
      if (route === "admin") AdminSessionGuard.start();
      else AdminSessionGuard.stop();
    }
    document.body.classList.toggle("admin-page", route === "admin" || route === "admin-login");
    document.body.classList.toggle("home-page", route === "home");
    document.body.classList.toggle(
      "service-page",
      ["services-step-1", "services-step-2", "service-detail"].includes(route)
    );

    // Update screen visibility
    document.querySelectorAll(".screen-view").forEach(screen => {
      screen.style.display = "none";
    });

    const targetScreen = document.getElementById(`screen-${route}`);
    if (targetScreen) {
      targetScreen.style.display = "block";
    }
    if (route === "login") {
      const adminNotice = document.getElementById("adminAccessNotice");
      const noticeText = sessionStorage.getItem("haven_house_admin_access_notice");
      if (adminNotice) {
        adminNotice.hidden = !noticeText;
        adminNotice.textContent = noticeText || "";
      }
      if (noticeText) sessionStorage.removeItem("haven_house_admin_access_notice");
    }

    // Update Desktop Sidebar active states
    document.querySelectorAll(".nav-link").forEach(link => {
      link.classList.remove("active");
      const navTarget = link.getAttribute("data-nav");
      
      if (
        (route === "home" && navTarget === "home") ||
        ((route === "services-step-1" || route === "services-step-2" || route === "service-detail") && navTarget === "services") ||
        ((route === "appointments" || route === "appointment-confirmation") && navTarget === "appointments") ||
        (route === "admin" && navTarget === "admin") ||
        (route === "about" && navTarget === "about") ||
        (route === "contact" && navTarget === "contact") ||
        (route === "events" && navTarget === "events")
      ) {
        link.classList.add("active");
      }
    });

    // Close mobile drawer if open
    const drawer = document.getElementById("mobileNavDrawer");
    if (drawer) drawer.classList.remove("open");

    // Dynamic screen render hooks
    if (route === "services-step-2") {
      await this.renderServicesStep2();
    } else if (route === "service-detail") {
      const serviceId = param || this.selectedServiceId || "accommodation";
      await this.renderServiceDetail(serviceId);
    } else if (route === "appointments" && window.AppointmentManager) {
      await AppointmentManager.load();
    } else if (route === "appointment-confirmation" && window.AppointmentManager) {
      AppointmentManager.loadConfirmation();
    } else if (route === "admin" && window.AdminManager) {
      await AdminManager.load();
    }

    // Scroll to top
    window.scrollTo({ top: 0, behavior: "smooth" });
  },

  setSelectedService(serviceId) {
    this.selectedServiceId = serviceId;
    this.navigate("services-step-2", serviceId);
  },

  async fetchServiceComposite(serviceIdentifier) {
    try {
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/services/${serviceIdentifier}`);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const json = await response.json();
      if (json.success && json.data) {
        this.currentServiceData = json.data;
        return json.data;
      }
    } catch (err) {
      console.warn(`[API] Could not fetch service from backend: ${err.message}. Using local referral fallback.`);
      const fallback = (HAVEN_HOUSE_CONFIG.fallbackServices || []).find(
        s => String(s.id) === String(serviceIdentifier) || s.service_key === serviceIdentifier
      );
      if (fallback) {
        return {
          service: fallback,
          details: {
            detail_title: fallback.title,
            detail_description: fallback.description,
            overview: fallback.description,
            relevance: "Eligibility and availability are set by the external provider; confirm details directly with them.",
            intake_desk_text: "This is external referral information, not a confirmed Haven House service. Use the linked provider contact details to enquire."
          },
          eligibility: [
            { criterion: "Eligibility depends on the external provider. Confirm requirements directly with them." }
          ],
          hours: [
            { day_of_week: null, opening_time: null, closing_time: null, is_closed: 0, notes: "Hours vary by provider; confirm directly with the service." }
          ]
        };
      }
    }
    return null;
  },

  async renderServicesStep2() {
    const data = await this.fetchServiceComposite(this.selectedServiceId);
    const service = data ? data.service : null;
    const title = service ? service.title : "Selected Service";
    const cardTitle = service ? service.card_title : title;
    const desc = service ? service.description : "Service information and intake details.";
    const iconKey = service ? service.icon_name : "default";
    const iconSvg = HAVEN_HOUSE_CONFIG.ICONS[iconKey] || HAVEN_HOUSE_CONFIG.ICONS["default"];

    const titleEl = document.getElementById("step2SelectedTitle");
    if (titleEl) {
      titleEl.textContent = `You selected ${title}. What would you like to know?`;
    }

    const heroEl = document.getElementById("serviceThemeHero");
    if (heroEl && window.ServiceThemes) {
      heroEl.innerHTML = ServiceThemes.render(service ? service.service_key : "");
    }
  },

  async renderServiceDetail(serviceId) {
    this.selectedServiceId = serviceId;
    const data = await this.fetchServiceComposite(serviceId);

    const badgeEl = document.getElementById("detailServiceBadge");
    const titleEl = document.getElementById("detailServiceTitle");
    const descEl = document.getElementById("detailServiceDesc");
    const overviewEl = document.getElementById("detailOverviewText");
    const relevanceEl = document.getElementById("detailRelevanceText");
    const eligibilityListEl = document.getElementById("detailEligibilityList");
    const intakeTextEl = document.getElementById("detailIntakeText");
    const imageEl = document.getElementById("detailServiceImage");

    if (badgeEl) badgeEl.textContent = "External referral information — confirm details with the provider";

    if (data && data.service) {
      const service = data.service;
      const details = data.details || {};
      const eligibility = data.eligibility || [];
      const serviceImages = {
        accommodation: {
          src: "assets/accommodation-support.jpg",
          alt: "A support worker helping someone view an accommodation option."
        },
        ndis: {
          src: "assets/ndis-support.jpg",
          alt: "A disability support worker helping a wheelchair user prepare food."
        },
        "child-support": {
          src: "assets/children-family-support.jpg",
          alt: "A family support worker speaking with a parent and young child."
        },
        chaplaincy: {
          src: "assets/chaplaincy-pastoral-care.jpg",
          alt: "A chaplain talking with a person in a private, supportive setting."
        },
        psychology: {
          src: "assets/counselling-support.jpg",
          alt: "A counsellor speaking with a client during a private session."
        },
        employment: {
          src: "assets/employment-skills-support.jpg",
          alt: "A group taking part in a job skills and resume workshop."
        },
        "general-info": {
          src: "assets/information-referrals.jpg",
          alt: "A community member speaking with staff at an information and referral desk."
        }
      };
      const serviceImage = serviceImages[service.service_key];
      if (imageEl) {
        imageEl.hidden = !serviceImage;
        if (serviceImage) {
          imageEl.src = serviceImage.src;
          imageEl.alt = serviceImage.alt;
        } else {
          imageEl.removeAttribute("src");
          imageEl.alt = "";
        }
      }
      const providerUrl = this.externalProviderUrls[service.service_key];
      document.querySelectorAll("#detailProviderBtn").forEach(button => {
        button.disabled = !providerUrl;
        button.textContent = providerUrl ? "Open provider website" : "No national provider contact listed";
      });
      const costEl = document.getElementById("detailCostInfo");
      const contactEl = document.getElementById("detailContactInfo");
      const websiteEl = document.getElementById("detailWebsiteUrl");
      if (costEl) costEl.textContent = details.cost_info || "Confirm costs with the provider.";
      if (contactEl) contactEl.textContent = details.contact_info || "Contact details have not been provided.";
      if (websiteEl) {
        let approvedUrl = "";
        try {
          const parsedUrl = new URL(details.website_url || "");
          if (["http:", "https:"].includes(parsedUrl.protocol)) approvedUrl = parsedUrl.href;
        } catch {
          approvedUrl = "";
        }
        websiteEl.href = approvedUrl;
        websiteEl.textContent = approvedUrl ? "Visit approved provider website" : "No approved website provided";
        websiteEl.hidden = !approvedUrl;
      }

      if (titleEl) titleEl.textContent = details.detail_title || `${service.title} Support`;
      if (descEl) descEl.textContent = details.detail_description || service.description;
      if (overviewEl) overviewEl.textContent = details.overview || "Service details currently being updated from approved sources.";
      if (relevanceEl) relevanceEl.textContent = details.relevance || "Relevant for community crisis support needs.";
      if (intakeTextEl) intakeTextEl.textContent = details.intake_desk_text || "Our intake coordination team can help connect you with appropriate services.";

      if (eligibilityListEl) {
        if (eligibility.length > 0) {
          eligibilityListEl.replaceChildren(...eligibility.map(item => {
            const row = document.createElement("div");
            row.className = "eligibility-item";
            const check = document.createElement("div");
            check.className = "eligibility-check";
            check.textContent = "✓";
            const text = document.createElement("div");
            text.className = "eligibility-text";
            text.textContent = item.criterion;
            row.append(check, text);
            return row;
          }));
        } else {
          eligibilityListEl.innerHTML = `
            <div class="eligibility-item">
              <div class="eligibility-text">Eligibility information is not available. Confirm requirements with the provider.</div>
            </div>
          `;
        }
      }
    } else {
      // Graceful fallback if backend is unavailable
      if (imageEl) imageEl.hidden = true;
      if (titleEl) titleEl.textContent = "Service Support Details";
      if (descEl) descEl.textContent = "Service information is temporarily unavailable from the database. Please try again.";
      if (overviewEl) overviewEl.textContent = "External referral information is temporarily unavailable. Please try again.";
      if (relevanceEl) relevanceEl.textContent = "Confirm service details directly with the relevant provider.";
      if (eligibilityListEl) {
        eligibilityListEl.innerHTML = `
          <div class="eligibility-item">
            <div class="eligibility-text">Eligibility information is unavailable. Confirm requirements with the provider.</div>
          </div>
        `;
      }
    }
  }
};

window.Router = Router;
