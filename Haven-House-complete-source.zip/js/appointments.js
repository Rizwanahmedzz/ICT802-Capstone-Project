const AppointmentManager = {
  selectedSlot: null,

  async load() {
    const dateInput = document.getElementById("appointmentDate");
    const bookButton = document.getElementById("appointmentBookBtn");
    if (!dateInput || !bookButton) return;

    const today = this.localDateString(new Date());
    dateInput.min = today;
    const nextAvailable = this.nextAvailableWeekday(new Date());
    if (!dateInput.value || (dateInput.value === today && nextAvailable !== today)) {
      dateInput.value = nextAvailable;
    }
    bookButton.onclick = () => this.bookSelectedSlot();
    dateInput.onchange = () => { this.loadSlots(); this.renderSelection(); };
    const serviceSelect = document.getElementById("appointmentService");
    if (serviceSelect) serviceSelect.onchange = () => this.renderSelection();
    this.loadServices();
    const user = AuthManager.currentUser;
    const who = document.getElementById("appointmentWhoami");
    if (who) {
      const name = user && (user.name || user.full_name || user.username);
      who.hidden = !name;
      who.textContent = name ? `Booking as ${name}` : "";
    }
    this.selectedSlot = null;
    bookButton.disabled = true;
    this.renderSelection();

    await Promise.all([this.loadSlots(), this.loadMyAppointments()]);
  },

  localDateString(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  },

  nextAvailableWeekday(now) {
    const date = new Date(now);
    const weekday = date.getDay();
    const noSlotsLeftToday = date.getHours() > 16
      || (date.getHours() === 16 && date.getMinutes() >= 30);
    if (weekday === 0 || weekday === 6 || noSlotsLeftToday) {
      date.setDate(date.getDate() + 1);
      while (date.getDay() === 0 || date.getDay() === 6) {
        date.setDate(date.getDate() + 1);
      }
    }
    return this.localDateString(date);
  },

  async loadServices() {
    const select = document.getElementById("appointmentService");
    if (!select || select.options.length > 1) return;
    try {
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/services`);
      const json = await response.json();
      (json.data || []).forEach(service => {
        const option = document.createElement("option");
        option.value = service.title;
        option.textContent = service.title;
        select.appendChild(option);
      });
    } catch (error) {
      console.error("[Appointments] Could not load services.", error);
    }
  },

  renderSelection() {
    const box = document.getElementById("appointmentSelection");
    if (!box) return;
    const user = AuthManager.currentUser;
    const name = user && (user.name || user.full_name || user.username);
    const service = document.getElementById("appointmentService")?.value;
    const date = document.getElementById("appointmentDate")?.value;
    let dateLabel = "";
    if (date) {
      const [y, m, d] = date.split("-").map(Number);
      dateLabel = new Date(y, m - 1, d).toLocaleDateString(undefined, { weekday: "long", year: "numeric", month: "long", day: "numeric" });
    }
    const rows = [
      ["Name", name || "Not signed in"],
      ["Service", service || "Not selected"],
      ["Date", dateLabel || "Not selected"],
      ["Time", this.selectedSlot ? this.formatTime(this.selectedSlot) : "Not selected"]
    ];
    const dl = document.createElement("dl");
    rows.forEach(([label, value]) => {
      const dt = document.createElement("dt");
      dt.textContent = label;
      const dd = document.createElement("dd");
      dd.textContent = value;
      dl.append(dt, dd);
    });
    const heading = document.createElement("h4");
    heading.textContent = "Your selection";
    box.replaceChildren(heading, dl);
  },

  async request(url, options = {}) {
    const response = await AuthManager.authenticatedFetch(url, options);
    const json = await response.json();
    if (response.status === 401) {
      sessionStorage.setItem("haven_house_after_login_route", "appointments");
      Router.navigate("login");
      throw new Error("Your sign-in session has expired. Please sign in again.");
    }
    if (!response.ok || !json.success) {
      throw new Error(json.message || `Request failed (${response.status}).`);
    }
    return json;
  },

  async loadSlots(clearFeedback = true) {
    const dateInput = document.getElementById("appointmentDate");
    const slotsContainer = document.getElementById("appointmentSlots");
    const bookButton = document.getElementById("appointmentBookBtn");
    const feedback = document.getElementById("appointmentFeedback");
    if (!dateInput || !slotsContainer || !bookButton) return;

    this.selectedSlot = null;
    bookButton.disabled = true;
    slotsContainer.replaceChildren();
    if (feedback && clearFeedback) {
      feedback.className = "auth-feedback";
      feedback.textContent = "";
    }

    try {
      const date = encodeURIComponent(dateInput.value);
      const json = await this.request(
        `${HAVEN_HOUSE_CONFIG.API_BASE}/appointments/availability?date=${date}`
      );
      const slots = json.data.slots || [];
      if (slots.length === 0) {
        const [year, month, day] = dateInput.value.split("-").map(Number);
        const weekday = new Date(year, month - 1, day).getDay();
        slotsContainer.textContent = weekday === 0 || weekday === 6
          ? "Appointments are available Monday to Friday only. Please select a weekday."
          : "No times are available on this date. Please choose another weekday.";
        return;
      }

      slots.forEach(slot => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "appointment-slot-btn";
        button.textContent = this.formatTime(slot);
        button.setAttribute("aria-pressed", "false");
        button.addEventListener("click", () => {
          this.selectedSlot = slot;
          slotsContainer.querySelectorAll(".appointment-slot-btn").forEach(item => {
            item.classList.remove("selected");
            item.setAttribute("aria-pressed", "false");
          });
          button.classList.add("selected");
          button.setAttribute("aria-pressed", "true");
          bookButton.disabled = false;
          this.renderSelection();
          if (feedback) {
            feedback.className = "auth-feedback";
            feedback.textContent = "";
          }
        });
        slotsContainer.appendChild(button);
      });
    } catch (error) {
      slotsContainer.textContent = error.message;
    }
  },

  async bookSelectedSlot() {
    const bookButton = document.getElementById("appointmentBookBtn");
    const feedback = document.getElementById("appointmentFeedback");
    if (!this.selectedSlot || !bookButton) return;
    const service = document.getElementById("appointmentService")?.value;
    if (!service) {
      if (feedback) {
        feedback.className = "auth-feedback error";
        feedback.textContent = "Please choose a service first.";
      }
      return;
    }

    bookButton.disabled = true;
    bookButton.textContent = "Reserving...";
    if (feedback) {
      feedback.className = "auth-feedback";
      feedback.textContent = "";
    }

    try {
      const json = await this.request(`${HAVEN_HOUSE_CONFIG.API_BASE}/appointments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ starts_at: this.selectedSlot, service })
      });
      if (!json.data || !json.data.starts_at || typeof json.data.email_sent !== "boolean") {
        throw new Error("The reservation response was incomplete. Please check your reservations before booking again.");
      }
      const user = AuthManager.currentUser;
      sessionStorage.setItem("haven_house_appointment_confirmation", JSON.stringify({
        starts_at: json.data.starts_at,
        email_sent: json.data.email_sent,
        service,
        name: user && (user.name || user.full_name || user.username) || ""
      }));
      this.selectedSlot = null;
      Router.navigate("appointment-confirmation");
    } catch (error) {
      await this.loadSlots(false);
      if (feedback) {
        feedback.className = "auth-feedback error";
        feedback.textContent = error.message;
      }
    } finally {
      bookButton.textContent = "Reserve selected time";
      bookButton.disabled = !this.selectedSlot;
    }
  },

  async loadMyAppointments() {
    const container = document.getElementById("myAppointmentsList");
    if (!container) return;
    container.textContent = "Loading your reservations…";
    try {
      const json = await this.request(`${HAVEN_HOUSE_CONFIG.API_BASE}/appointments/mine`);
      const appointments = json.data || [];
      if (appointments.length === 0) {
        container.textContent = "You have no reservations yet.";
        return;
      }

      const list = document.createElement("ul");
      list.className = "appointment-list";
      appointments.forEach(appointment => {
        const item = document.createElement("li");
        const label = document.createElement("span");
        label.textContent = (appointment.service_title ? `${appointment.service_title} — ` : "") + this.formatDateTime(appointment.starts_at);
        const status = document.createElement("span");
        status.className = "badge badge-neutral";
        status.textContent = appointment.status === "CONFIRMED" ? "Reserved" : "Cancelled";
        item.append(label, status);
        list.appendChild(item);
      });
      container.replaceChildren(list);
    } catch (error) {
      container.textContent = error.message;
    }
  },

  formatTime(value) {
    const [, time] = value.split("T");
    const [hourText, minute] = time.split(":");
    const hour = Number(hourText);
    return `${hour % 12 || 12}:${minute} ${hour < 12 ? "am" : "pm"}`;
  },

  formatDateTime(value) {
    const [date, time] = value.split("T");
    const [year, month, day] = date.split("-").map(Number);
    const dateLabel = new Date(year, month - 1, day).toLocaleDateString(undefined, {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric"
    });
    return `${dateLabel} at ${this.formatTime(value)}`;
  },

  loadConfirmation() {
    const details = sessionStorage.getItem("haven_house_appointment_confirmation");
    const timeElement = document.getElementById("appointmentConfirmationTime");
    const emailElement = document.getElementById("appointmentConfirmationEmail");
    if (!details || !timeElement || !emailElement) {
      Router.navigate("appointments");
      return;
    }

    try {
      const confirmation = JSON.parse(details);
      if (typeof confirmation.starts_at !== "string" || typeof confirmation.email_sent !== "boolean") {
        throw new Error("Invalid reservation confirmation.");
      }
      timeElement.textContent = this.formatDateTime(confirmation.starts_at);
      const detailList = document.getElementById("appointmentConfirmationDetails");
      if (detailList) {
        detailList.replaceChildren();
        if (confirmation.name) {
          const person = document.createElement("div");
          person.className = "appointment-confirmation-person";
          person.textContent = confirmation.name;
          detailList.appendChild(person);
        }
        if (confirmation.service) {
          const chip = document.createElement("div");
          chip.className = "appointment-confirmation-service";
          chip.textContent = confirmation.service;
          detailList.appendChild(chip);
        }
        const colors = ["#fde68a", "#5eead4", "#c4b5fd", "#fda4af", "#ffffff"];
        for (let i = 0; i < 28; i++) {
          const piece = document.createElement("span");
          piece.className = "appt-confetti";
          piece.style.left = `${Math.random() * 100}%`;
          piece.style.background = colors[i % colors.length];
          piece.style.animationDelay = `${0.2 + Math.random() * 0.9}s`;
          detailList.appendChild(piece);
        }
      }
      emailElement.textContent = confirmation.email_sent
        ? "A confirmation email has been sent to your account email address."
        : "Your reservation was saved, but we could not send the confirmation email.";
    } catch (error) {
      sessionStorage.removeItem("haven_house_appointment_confirmation");
      Router.navigate("appointments");
    }
  }
};

window.AppointmentManager = AppointmentManager;
