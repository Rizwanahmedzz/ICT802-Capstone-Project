/**
 * Haven House Safety Intent Detection & Crisis Handoff System
 * CRITICAL PRODUCT PRINCIPLE:
 * The assistant navigates and provides approved information.
 * It NEVER counsels, diagnoses, or provides crisis advice.
 * On detecting crisis/safety intent, it immediately halts AI conversation and displays Crisis Handoff.
 */

const SAFETY_KEYWORDS = [
  "threat",
  "threatening",
  "threatened",
  "in danger",
  "danger",
  "domestic violence",
  "dv",
  "hurting me",
  "hurt me",
  "hitting me",
  "hit me",
  "being attacked",
  "attacked",
  "attack",
  "attacking",
  "unsafe",
  "emergency",
  "hurt myself",
  "hurting myself",
  "kill myself",
  "killing myself",
  "suicide",
  "suicidal",
  "wants to kill me",
  "want to die",
  "abuse",
  "abused",
  "abusive",
  "violent",
  "violence",
  "immediate danger",
  "assault",
  "assaulted",
  "stalking",
  "stalker",
  "weapon",
  "bleeding",
  "overdose"
];

const SafetyController = {
  /**
   * Evaluates text for crisis/safety keywords
   * @param {string} text 
   * @returns {boolean} true if crisis intent detected
   */
  isCrisisIntent(text) {
    if (!text || typeof text !== "string") return false;
    const normalized = text.toLowerCase().trim();
    
    return SAFETY_KEYWORDS.some(keyword => {
      // Use boundary-safe checks or direct phrase inclusion
      const regex = new RegExp(`\\b${keyword}\\b`, "i");
      return regex.test(normalized) || normalized.includes(keyword);
    });
  },

  /**
   * Triggers Crisis Handoff screen immediately
   */
  triggerCrisisHandoff(fromSource = "chat") {
    console.log(`[Safety Guardrail Triggered] Crisis intent detected from ${fromSource}. Halting AI conversation.`);
    
    // Close floating widget if open
    if (window.FloatingWidget) {
      window.FloatingWidget.close();
    }
    
    // Navigate to Crisis Handoff screen
    if (window.Router) {
      window.Router.navigate("crisis-handoff");
    }
  }
};

window.SafetyController = SafetyController;
