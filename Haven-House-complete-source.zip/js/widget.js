/**
 * Floating Embeddable Service Assistant Widget
 * Connected to Flask REST API: POST /api/assistant
 * Accessible across website views with safety guardrail and database service navigation.
 */

const FloatingWidget = {
  container: null,
  panel: null,
  messagesContainer: null,
  inputField: null,
  form: null,
  isOpen: false,
  isProcessing: false,

  init() {
    this.panel = document.getElementById("floatingWidgetPanel");
    this.messagesContainer = document.getElementById("widgetMessages");
    this.inputField = document.getElementById("widgetInputField");
    this.form = document.getElementById("widgetForm");

    if (this.form) {
      this.form.addEventListener("submit", (e) => {
        e.preventDefault();
        this.handleSubmit();
      });
    }

    this.renderInitialState();
  },

  toggle() {
    if (this.isOpen) {
      this.close();
    } else {
      this.open();
    }
  },

  open() {
    if (!this.panel) return;
    this.panel.classList.add("open");
    this.isOpen = true;
    if (this.inputField) {
      setTimeout(() => this.inputField.focus(), 150);
    }
  },

  close() {
    if (!this.panel) return;
    this.panel.classList.remove("open");
    this.isOpen = false;
  },

  renderInitialState() {
    if (!this.messagesContainer) return;
    this.messagesContainer.innerHTML = `
      <div class="safety-notice-box" style="margin: 0 0 8px 0; font-size: 0.75rem; padding: 8px 10px;">
        <span>ℹ️ Messages are sent to OpenAI to generate replies. I provide service navigation, not counselling or emergency support.</span>
      </div>
      <div class="message-row assistant-message">
        <div class="message-avatar-small">HH</div>
        <div class="message-bubble">
          <p>Hi, how can I help you navigate Haven House services today?</p>
          <div class="quick-chips-row" style="margin-top: 8px;">
            <button class="quick-chip" onclick="FloatingWidget.sendTopic('Find a service')">Find a service</button>
            <button class="quick-chip" onclick="FloatingWidget.sendTopic('Accommodation')">Accommodation</button>
            <button class="quick-chip" onclick="FloatingWidget.sendTopic('HH Kids')">HH Kids</button>
            <button class="quick-chip" onclick="FloatingWidget.sendTopic('NDIS services')">NDIS services</button>
          </div>
        </div>
      </div>
    `;
  },

  handleSubmit() {
    if (!this.inputField || this.isProcessing) return;
    const text = this.inputField.value.trim();
    if (!text) return;

    this.inputField.value = "";
    this.processMessage(text);
  },

  sendTopic(topicText) {
    if (this.isProcessing) return;
    this.processMessage(topicText);
  },

  async processMessage(userText) {
    this.appendMessage("user", userText);

    // 1. CLIENT SAFETY GUARDRAIL
    if (SafetyController.isCrisisIntent(userText)) {
      this.close();
      SafetyController.triggerCrisisHandoff("Floating Widget (Client Guard)");
      return;
    }

    // 2. Show Loading Indicator
    this.isProcessing = true;
    const loadingId = this.showLoadingIndicator();

    try {
      // 3. Send to Shared Assistant API
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/assistant`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userText })
      });

      this.removeLoadingIndicator(loadingId);
      this.isProcessing = false;

      const json = await response.json();
      if (!response.ok) throw new Error(json.message || `HTTP error ${response.status}`);

      if (!json.success || !json.data) {
        throw new Error(json.message || "Invalid response");
      }

      const data = json.data;

      // 4. SERVER SAFETY HANDOFF CHECK
      if (data.handoff === true) {
        this.close();
        SafetyController.triggerCrisisHandoff("Floating Widget (Server Guard)");
        return;
      }

      // 5. Render Response
      this.renderWidgetResponse(data);

    } catch (err) {
      console.warn(`[Widget API Error] ${err.message}`);
      this.removeLoadingIndicator(loadingId);
      this.isProcessing = false;

      this.appendMessage("assistant", `
        <p>${this.escapeHtml(err.message)} Make sure the Flask backend is running and OPENAI_API_KEY is configured in its .env file. Open this site through XAMPP at a localhost URL, not directly as a file.</p>
        <div class="btn-group" style="margin-top: 8px;">
          <button class="btn btn-secondary btn-sm" onclick="FloatingWidget.close(); Router.navigate('services-step-1');">Browse Services</button>
        </div>
      `, true);
    }
  },

  renderWidgetResponse(data) {
    const formattedText = this.escapeHtml(data.message).replace(/\n/g, "<br>");
    let actionButtonsHtml = "";

    if (data.services && data.services.length > 0) {
      if (data.services.length === 1) {
        const s = data.services[0];
        const keyOrId = this.escapeJsString(s.service_key || s.id);
        const titleSafe = this.escapeHtml(s.title);
        const titleJsSafe = this.escapeJsString(s.title);
        actionButtonsHtml = `
          <div class="btn-group" style="margin-top: 8px;">
            <button class="btn btn-primary btn-sm" onclick="FloatingWidget.close(); Router.navigate('service-detail', '${keyOrId}');">View ${titleSafe}</button>
            <button class="btn btn-secondary btn-sm" onclick="App.openContactModal('${titleJsSafe}')">Contact Us</button>
          </div>
        `;
      } else {
        const serviceButtons = data.services.slice(0, 3).map(s => {
          const keyOrId = this.escapeJsString(s.service_key || s.id);
          const titleSafe = this.escapeHtml(s.title);
          return `<button class="btn btn-secondary btn-sm" onclick="FloatingWidget.close(); Router.navigate('service-detail', '${keyOrId}');">${titleSafe}</button>`;
        }).join(" ");

        actionButtonsHtml = `
          <div class="btn-group" style="margin-top: 8px;">
            ${serviceButtons}
          </div>
        `;
      }
    } else {
      actionButtonsHtml = `
        <div class="btn-group" style="margin-top: 8px;">
          <button class="btn btn-primary btn-sm" onclick="FloatingWidget.close(); Router.navigate('services-step-1');">Browse Services</button>
        </div>
      `;
    }

    const fullContent = `<p>${formattedText}</p>${data.action === "book_appointment" ? ChatBooking.formHtml() : actionButtonsHtml}`;
    this.appendMessage("assistant", fullContent, true);
  },

  showLoadingIndicator() {
    const id = "widget-loading-" + Date.now();
    const row = document.createElement("div");
    row.id = id;
    row.className = "message-row assistant-message";
    row.innerHTML = `
      <div class="message-avatar-small">HH</div>
      <div class="message-bubble" style="color: var(--color-text-muted); font-style: italic; font-size: 0.8125rem;">
        Searching services...
      </div>
    `;
    this.messagesContainer.appendChild(row);
    this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
    return id;
  },

  removeLoadingIndicator(id) {
    const el = document.getElementById(id);
    if (el) el.remove();
  },

  appendMessage(sender, contentHtml, isHtml = false) {
    if (!this.messagesContainer) return;

    const row = document.createElement("div");
    row.className = `message-row ${sender}-message`;

    if (sender === "assistant") {
      row.innerHTML = `
        <div class="message-avatar-small">HH</div>
        <div class="message-bubble">${isHtml ? contentHtml : `<p>${contentHtml}</p>`}</div>
      `;
    } else {
      row.innerHTML = `
        <div class="message-bubble">
          <p>${this.escapeHtml(contentHtml)}</p>
        </div>
      `;
    }

    this.messagesContainer.appendChild(row);
    this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
  },

  escapeHtml(text) {
    if (!text) return "";
    const div = document.createElement("div");
    div.textContent = String(text);
    return div.innerHTML;
  },

  escapeJsString(str) {
    if (!str) return "";
    return String(str).replace(/\\/g, "\\\\").replace(/'/g, "\\'").replace(/"/g, "&quot;");
  }
};

window.FloatingWidget = FloatingWidget;
