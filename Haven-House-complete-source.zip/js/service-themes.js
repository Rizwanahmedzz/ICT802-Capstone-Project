// Distinct hero layout per service. Wording is generic on purpose: no unconfirmed facts.
const ServiceThemes = {
  btn(label) {
    return `<button type="button" class="svt-button" onclick="App.openContactModal(this.dataset.s)" data-s="${label.context}">${label.text}</button>`;
  },

  templates: {
    accommodation: (b) => `
      <div class="svt svt-accommodation">
        <div class="svt-split">
          <div>
            <span class="svt-eyebrow">ACCOMMODATION SUPPORT</span>
            <h1>Safe homes. Stronger communities.</h1>
            <p>Explore accommodation options and housing pathways available through Haven.</p>
            ${b("Enquire About Housing")}
          </div>
          <div class="svt-minigrid">
            <div class="svt-mini"><h3>🏠 Residences</h3><p>Information about available residences.</p></div>
            <div class="svt-mini"><h3>🧭 Pathways</h3><p>Guidance on housing pathways.</p></div>
            <div class="svt-mini"><h3>📝 Enquiries</h3><p>Help with accommodation enquiries.</p></div>
          </div>
        </div>
      </div>`,

    "child-support": (b) => `
      <div class="svt svt-family">
        <div class="svt-center">
          <span class="svt-eyebrow">CHILDREN, YOUTH &amp; FAMILY</span>
          <h1>Supporting families through every stage.</h1>
          <p>Information, guidance and connections for children, young people and families.</p>
        </div>
        <div class="svt-cards3">
          <div class="svt-card"><h3>Children</h3><p>Support pathways and information for children and their families.</p></div>
          <div class="svt-card"><h3>Youth</h3><p>Connections to appropriate youth services and community resources.</p></div>
          <div class="svt-card"><h3>Families</h3><p>Assistance and information for families seeking support.</p></div>
        </div>
      </div>`,

    ndis: (b) => `
      <div class="svt svt-ndis">
        <div class="svt-split">
          <div>
            <span class="svt-eyebrow">NDIS SUPPORT</span>
            <h1>Understanding your support options.</h1>
            <p>Information and guidance to help people understand available support pathways.</p>
            ${b("Discuss Your Needs")}
          </div>
          <div class="svt-steps">
            <div class="svt-step"><span class="svt-num">1</span><span>Understand your options</span></div>
            <div class="svt-step"><span class="svt-num">2</span><span>Explore available pathways</span></div>
            <div class="svt-step"><span class="svt-num">3</span><span>Connect with appropriate support</span></div>
          </div>
        </div>
      </div>`,

    psychology: (b) => `
      <div class="svt svt-counselling">
        <div class="svt-center">
          <span class="svt-pill">WELLBEING SUPPORT</span>
          <h1>A space to talk, understand and connect.</h1>
          <p>Information about available wellbeing and counselling pathways.</p>
          <div class="svt-options">
            <div class="svt-option">Emotional wellbeing</div>
            <div class="svt-option">Personal support</div>
            <div class="svt-option">Family wellbeing</div>
            <div class="svt-option">Support pathways</div>
          </div>
          ${b("Contact the Team")}
        </div>
      </div>`,

    employment: (b) => `
      <div class="svt svt-employment">
        <div class="svt-split">
          <div class="svt-panel-dark">
            <span class="svt-eyebrow">EMPLOYMENT SUPPORT</span>
            <h1>Building skills. Creating opportunities.</h1>
            <p>Connect with information and pathways that can support employment goals.</p>
            ${b("Get Started")}
          </div>
          <div class="svt-panel-light">
            <h2>How we can help</h2>
            <ul><li>Employment information</li><li>Career pathways</li><li>Skills development</li><li>Community connections</li></ul>
          </div>
        </div>
      </div>`,

    chaplaincy: (b) => `
      <div class="svt svt-chaplaincy">
        <div class="svt-center svt-narrow">
          <span class="svt-eyebrow">CHAPLAINCY</span>
          <h1>Support, connection and a listening ear.</h1>
          <p class="svt-quote">"Everyone deserves a safe space to be heard and supported."</p>
          <p>Learn more about available chaplaincy and community support pathways.</p>
          ${b("Speak With Our Team")}
        </div>
      </div>`,

    "general-info": (b) => `
      <div class="svt svt-referrals">
        <div class="svt-center">
          <span class="svt-eyebrow">INFORMATION &amp; REFERRALS</span>
          <h1>Not sure where to start?</h1>
          <p>We can help you understand available pathways and connect with appropriate services.</p>
        </div>
        <div class="svt-flow">
          <div class="svt-flow-step"><strong>01</strong>Tell us what you need</div>
          <div class="svt-flow-step"><strong>02</strong>Explore your options</div>
          <div class="svt-flow-step"><strong>03</strong>Find the right pathway</div>
          <div class="svt-flow-step"><strong>04</strong>Connect with support</div>
        </div>
      </div>`
  },

  render(serviceKey) {
    const tpl = this.templates[serviceKey];
    if (!tpl) return "";
    const context = (Router.currentServiceData && Router.currentServiceData.service
      ? Router.currentServiceData.service.title : "Service Inquiry").replace(/"/g, "&quot;");
    return tpl((text) => this.btn({ text, context }));
  }
};

window.ServiceThemes = ServiceThemes;
