const AdminManager = {
  module: "dashboard",
  records: {},
  slotMonth: "",
  slotDate: "",

  async load() {
    document.getElementById("adminRefreshBtn").onclick = () => this.openModule(this.module);
    document.getElementById("adminNotifBtn").onclick = async () => {
      if (this.module !== "dashboard") await this.openModule("dashboard");
      document.getElementById("adminNotifList")?.scrollIntoView({ behavior: "smooth", block: "start" });
    };
    document.getElementById("adminModuleTabs").onclick = event => {
      const button = event.target.closest("[data-module]");
      if (button) this.openModule(button.dataset.module);
    };
    const user = AuthManager.currentUser || {};
    const name = user.name || user.full_name || user.username || "Admin";
    const hour = new Date().getHours();
    const part = hour < 12 ? "Morning" : hour < 18 ? "Afternoon" : "Evening";
    document.getElementById("admGreeting").textContent = `Good ${part}, ${name}! 👋`;
    document.getElementById("admDate").textContent = new Date().toLocaleDateString("en-AU", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
    document.getElementById("admUserName").textContent = name;
    document.getElementById("admAvatar").textContent = name.charAt(0).toUpperCase();
    await this.openModule(this.module);
  },

  async api(path, options = {}) {
    try {
      const response = await AuthManager.authenticatedFetch(
        `${HAVEN_HOUSE_CONFIG.API_BASE}${path}`,
        {
          ...options,
          headers: { "Content-Type": "application/json", ...(options.headers || {}) }
        }
      );
      const json = await response.json();
      if (response.status === 401) {
        Router.navigate("admin-login");
        throw new Error("Please sign in again.");
      }
      if (response.status === 403) {
        Router.navigate("home");
        throw new Error("Administrator access is required.");
      }
      if (!response.ok || !json.success) throw new Error(json.message || `Request failed (${response.status}).`);
      return json.data || {};
    } catch (error) {
      const feedback = document.getElementById("adminFeedback");
      if (feedback) {
        feedback.className = "auth-feedback error";
        feedback.textContent = error.message || "The request could not be completed.";
      }
      throw error;
    }
  },

  setNotifBadge(count) {
    const badge = document.getElementById("adminNotifBadge");
    if (!badge) return;
    const n = Number(count) || 0;
    badge.textContent = n > 99 ? "99+" : String(n);
    badge.hidden = n === 0;
  },

  async refreshNotifBadge() {
    try {
      const response = await AuthManager.authenticatedFetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/admin/dashboard`);
      const json = await response.json();
      if (response.ok && json.success) this.setNotifBadge(json.data?.metrics?.unread_notifications);
    } catch (_) { /* badge is non-critical */ }
  },

  async openModule(name) {
    this.module = name;
    this.refreshNotifBadge();
    document.querySelectorAll("#adminModuleTabs [data-module]").forEach(button => {
      button.setAttribute("aria-current", button.dataset.module === name ? "page" : "false");
    });
    const feedback = document.getElementById("adminFeedback");
    const panel = document.getElementById("adminModuleContent");
    feedback.className = "auth-feedback";
    feedback.textContent = "";
    panel.textContent = "Loading…";
    try {
      const render = this[`render_${name}`];
      if (typeof render !== "function") throw new Error("Unknown admin section.");
      await render.call(this, panel);
    } catch (error) {
      panel.textContent = "This section could not be loaded.";
      feedback.className = "auth-feedback error";
      feedback.textContent = error.message || "This section could not be loaded.";
    }
  },

  escape(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[char]));
  },

  table(headers, rows) {
    if (!rows.length) return "<p>No records found.</p>";
    return `<div class="admin-table-scroll"><table class="admin-appointments-table"><thead><tr>${headers.map(h => `<th scope="col">${this.escape(h)}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table></div>`;
  },

  lineChart(records) {
    const totals = new Map();
    for (const row of records) totals.set(row.report_month, (totals.get(row.report_month) || 0) + (Number(row.total) || 0));
    const now = new Date();
    const points = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      points.push({ label: d.toLocaleDateString(undefined, { month: "short" }), value: totals.get(key) || 0 });
    }
    const W = 560, H = 220, L = 34, B = 26, T = 14, R = 14;
    const max = Math.max(4, ...points.map(p => p.value));
    const x = i => L + (i * (W - L - R)) / (points.length - 1);
    const y = v => T + (H - T - B) * (1 - v / max);
    const path = points.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`).join(" ");
    const area = `${path} L${x(points.length - 1)},${H - B} L${x(0)},${H - B} Z`;
    const grid = [0, 1, 2, 3, 4].map(i => {
      const v = Math.round((max * i) / 4);
      return `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="#2a3350" stroke-dasharray="3 3"/><text x="${L - 6}" y="${y(v) + 4}" text-anchor="end" fill="#8a94ad" font-size="10">${v}</text>`;
    }).join("");
    return `<svg class="adm-line-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Appointments over the last six months">
      <defs><linearGradient id="admArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7c6cf0" stop-opacity=".55"/><stop offset="1" stop-color="#7c6cf0" stop-opacity="0"/></linearGradient></defs>
      ${grid}
      <path d="${area}" fill="url(#admArea)"/>
      <path d="${path}" fill="none" stroke="#a99bff" stroke-width="2.5" stroke-linejoin="round"/>
      ${points.map((p, i) => `<circle cx="${x(i)}" cy="${y(p.value)}" r="4" fill="#a99bff"/><text x="${x(i)}" y="${H - 8}" text-anchor="middle" fill="#8a94ad" font-size="10">${p.label}</text>`).join("")}
    </svg>`;
  },

  statusBars(items) {
    const max = Math.max(1, ...items.map(i => Number(i[1]) || 0));
    return `<div class="adm-hbars">${items.map(([label, value, color]) => {
      const n = Number(value) || 0;
      return `<div class="adm-hbar"><span>${this.escape(label)}</span><span class="adm-hbar-track"><span style="width:${Math.round((n / max) * 100)}%;background:${color}"></span></span><strong>${n}</strong></div>`;
    }).join("")}</div>`;
  },

  appointmentChart(records) {
    const months = new Map();
    for (const row of records) {
      if (!months.has(row.report_month)) months.set(row.report_month, { CONFIRMED: 0, CANCELLED: 0, total: 0 });
      const month = months.get(row.report_month);
      const count = Number(row.total) || 0;
      month[row.status] = count;
      month.total += count;
    }
    if (!months.size) return "<p>No appointment records are available for this period.</p>";
    const max = Math.max(1, ...[...months.values()].map(month => month.total));
    return `<div class="admin-chart" role="img" aria-label="Appointment totals by month for the last six months">
      ${[...months.entries()].map(([key, month]) => {
        const label = new Date(`${key}-01T00:00:00`).toLocaleDateString(undefined, { month: "short", year: "numeric" });
        const width = Math.round((month.total / max) * 100);
        return `<div class="admin-chart-row">
          <span class="admin-chart-label">${this.escape(label)}</span>
          <span class="admin-chart-track"><span class="admin-chart-bar" style="width:${width}%"></span></span>
          <strong>${month.total}</strong>
          <small>${month.CONFIRMED} confirmed · ${month.CANCELLED} cancelled</small>
        </div>`;
      }).join("")}
    </div>`;
  },

  async render_dashboard(panel) {
    const data = await this.api("/admin/dashboard");
    const metrics = data.metrics || {};
    panel.innerHTML = `
      <div class="admin-metric-grid">
        ${[
          ["Total appointments", metrics.total_appointments],
          ["Upcoming appointments", metrics.upcoming_appointments],
          ["Confirmed appointments", metrics.appointments],
          ["Cancelled appointments", metrics.cancelled_appointments],
          ["New contact messages", metrics.new_enquiries],
          ["Upcoming published events", metrics.upcoming_events],
          ["Active services", metrics.active_services],
          ["Unread notifications", metrics.unread_notifications]
        ].map(([label, value], i) => `<article class="card adm-stat adm-stat-${i % 4}"><h3>${this.escape(label)}</h3><strong>${this.escape(value || 0)}</strong></article>`).join("")}
      </div>
      <div class="adm-chart-grid">
        <section class="card"><h3>Appointments overview</h3>${this.lineChart(data.appointment_months || [])}</section>
        <section class="card"><h3>Appointments by status</h3>${this.statusBars([
          ["Confirmed", metrics.appointments, "#2563eb"],
          ["Upcoming", metrics.upcoming_appointments, "#7c6cf0"],
          ["Cancelled", metrics.cancelled_appointments, "#f0745a"],
          ["Messages", metrics.new_enquiries, "#34d399"]
        ])}</section>
      </div>
      <section class="card"><h3>Appointments by month</h3>
      ${this.appointmentChart(data.appointment_months || [])}</section>
      <section class="card" id="adminNotifList"><h3>Recent notifications</h3>
      ${this.table(["Notification", "Details", "Date", "Action"], (data.notifications || []).map(item =>
        `<tr><td>${this.escape(item.title)}</td><td>${this.escape(item.message)}</td><td>${this.escape(item.created_at)}</td><td>${item.is_read ? "Read" : `<button class="btn btn-secondary btn-sm" data-read="${item.id}">Mark read</button>`}</td></tr>`
      ))}</section>`;
    panel.querySelectorAll("[data-read]").forEach(button => button.onclick = async () => {
      await this.api("/admin/notifications", { method: "PATCH", body: JSON.stringify({ id: button.dataset.read }) });
      await this.openModule("dashboard");
    });
  },

  async render_appointments(panel) {
    const data = await this.api("/admin/appointments");
    const rows = (data.appointments || []).map(item => `<tr>
      <td>${this.escape(this.formatDateTime(item.starts_at))}</td><td>${this.escape(item.name)}</td>
      <td>${this.escape(item.email)}</td><td>${this.escape(item.status)}</td>
      <td><button class="btn btn-secondary btn-sm" data-cancel="${item.id}" ${item.status === "CANCELLED" ? "disabled" : ""}>Cancel</button>
      <button class="btn btn-secondary btn-sm" data-reschedule="${item.id}">Reschedule</button></td></tr>`);
    panel.innerHTML = `<section class="card"><h3>Appointment reservations</h3>
      ${this.table(["Reserved time", "Account", "Email", "Status", "Actions"], rows)}</section>`;
    panel.querySelectorAll("[data-cancel]").forEach(button => button.onclick = async () => {
      await this.api(`/admin/appointments/${button.dataset.cancel}`, {
        method: "PATCH", body: JSON.stringify({ action: "status", status: "CANCELLED" })
      });
      await this.openModule("appointments");
    });
    panel.querySelectorAll("[data-reschedule]").forEach(button => button.onclick = async () => {
      const value = prompt("Enter a future weekday date and time (YYYY-MM-DDTHH:MM):");
      if (!value) return;
      await this.api(`/admin/appointments/${button.dataset.reschedule}`, {
        method: "PATCH", body: JSON.stringify({ action: "reschedule", starts_at: value })
      });
      await this.openModule("appointments");
    });
  },

  async render_slots(panel) {
    const today = new Date();
    if (!this.slotMonth) this.slotMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}`;
    if (!this.slotDate) this.slotDate = this.slotDateKey(today);
    const data = await this.api(`/admin/slots?month=${encodeURIComponent(this.slotMonth)}`);
    const slots = data.slots || [];
    const appointments = data.appointments || [];
    const [year, month] = this.slotMonth.split("-").map(Number);
    const firstDay = new Date(year, month - 1, 1);
    const daysInMonth = new Date(year, month, 0).getDate();
    const leadingDays = (firstDay.getDay() + 6) % 7;
    const daySlots = slots.filter(slot => slot.starts_at.slice(0, 10) === this.slotDate);
    const slotTimes = new Set(slots.map(slot => slot.starts_at.slice(0, 16)));
    const unslottedAppointments = appointments.filter(appointment => !slotTimes.has(appointment.starts_at.slice(0, 16)));
    const dayAppointments = unslottedAppointments.filter(appointment => appointment.starts_at.slice(0, 10) === this.slotDate);
    const dayEntries = [
      ...daySlots.map(slot => ({ starts_at: slot.starts_at, slot })),
      ...dayAppointments.map(appointment => ({ starts_at: appointment.starts_at, appointment }))
    ].sort((left, right) => left.starts_at.localeCompare(right.starts_at));
    const selectedDate = new Date(`${this.slotDate}T00:00:00`);
    const calendarCells = Array.from({ length: Math.ceil((leadingDays + daysInMonth) / 7) * 7 }, (_, index) => {
      const day = index - leadingDays + 1;
      if (day < 1 || day > daysInMonth) return `<span class="admin-calendar-empty" aria-hidden="true"></span>`;
      const date = `${this.slotMonth}-${String(day).padStart(2, "0")}`;
      const count = slots.filter(slot => slot.starts_at.slice(0, 10) === date).length
        + unslottedAppointments.filter(appointment => appointment.starts_at.slice(0, 10) === date).length;
      const selected = date === this.slotDate;
      return `<button type="button" class="admin-calendar-day${selected ? " is-selected" : ""}${count ? " has-slots" : ""}" data-calendar-date="${date}" aria-label="${this.escape(new Date(year, month - 1, day).toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" }))}${count ? `, ${count} time slots` : ", no time slots"}" aria-pressed="${selected}">
        <span>${day}</span>${count ? `<small>${count}</small>` : ""}
      </button>`;
    }).join("");
    const rows = dayEntries.map(entry => {
      if (entry.appointment) {
        return `<tr><td>${this.escape(this.formatDateTime(entry.starts_at))}</td><td>Booked appointment</td><td>—</td><td>—</td></tr>`;
      }
      const slot = entry.slot;
      return `<tr>
        <td>${this.escape(this.formatDateTime(slot.starts_at))}</td>
        <td>${slot.appointment_id ? "Reserved" : slot.is_active ? "Available" : "Closed"}</td>
        <td>${this.escape(slot.notes || "—")}</td>
        <td><button class="btn btn-secondary btn-sm" data-slot="${slot.id}" data-active="${slot.is_active ? "false" : "true"}">${slot.is_active ? "Close" : "Reopen"}</button></td>
      </tr>`;
    });
    panel.innerHTML = `<div class="admin-calendar-layout">
      <section class="card admin-calendar-card" aria-label="Appointment calendar">
        <header class="admin-calendar-header">
          <button type="button" class="btn btn-secondary btn-sm" data-calendar-shift="-1" aria-label="Previous month">‹</button>
          <h3>${this.escape(firstDay.toLocaleDateString(undefined, { month: "long", year: "numeric" }))}</h3>
          <button type="button" class="btn btn-secondary btn-sm" data-calendar-shift="1" aria-label="Next month">›</button>
        </header>
        <div class="admin-calendar-grid" role="grid" aria-label="${this.escape(firstDay.toLocaleDateString(undefined, { month: "long", year: "numeric" }))}">
          ${["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map(day => `<span class="admin-calendar-weekday" role="columnheader">${day}</span>`).join("")}
          ${calendarCells}
        </div>
        <p class="admin-calendar-legend"><span class="admin-calendar-dot"></span> Has time slots</p>
      </section>
      <section class="card admin-calendar-day-panel">
        <h3>${this.escape(selectedDate.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" }))}</h3>
        <h4>Time slots</h4>
        ${this.table(["Time", "Status", "Note", "Action"], rows)}
        <h4>Add a time slot</h4>
        <form id="slotForm" class="admin-edit-form">
          <label>Date and time<input name="starts_at" type="datetime-local" value="${this.slotDate}T09:00" required></label>
          <label>Note (optional)<input name="notes" maxlength="255"></label>
          <button class="btn btn-primary">Add slot</button>
          <p class="appointment-field-help">Slots are available for future weekdays, between 9:00 am and 4:30 pm.</p>
        </form>
      </section>
    </div>`;
    panel.querySelectorAll("[data-calendar-shift]").forEach(button => button.onclick = async () => {
      const [currentYear, currentMonth] = this.slotMonth.split("-").map(Number);
      const nextMonth = new Date(currentYear, currentMonth - 1 + Number(button.dataset.calendarShift), 1);
      this.slotMonth = `${nextMonth.getFullYear()}-${String(nextMonth.getMonth() + 1).padStart(2, "0")}`;
      this.slotDate = `${this.slotMonth}-01`;
      await this.openModule("slots");
    });
    panel.querySelectorAll("[data-calendar-date]").forEach(button => button.onclick = async () => {
      this.slotDate = button.dataset.calendarDate;
      await this.openModule("slots");
    });
    panel.querySelector("#slotForm").onsubmit = async event => {
      event.preventDefault();
      const form = new FormData(event.currentTarget);
      await this.api("/admin/slots", { method: "POST", body: JSON.stringify(Object.fromEntries(form)) });
      await this.openModule("slots");
    };
    panel.querySelectorAll("[data-slot]").forEach(button => button.onclick = async () => {
      await this.api("/admin/slots", { method: "PATCH", body: JSON.stringify({
        action: "toggle", id: button.dataset.slot, is_active: button.dataset.active === "true"
      }) });
      await this.openModule("slots");
    });
  },

  slotDateKey(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  },

  async render_services(panel) {
    const data = await this.api("/admin/services");
    const services = data.services || [];
    this.records.services = services;
    panel.innerHTML = `<section class="card"><h3>Edit service information</h3>
      <label>Service<select id="serviceSelect">${services.map(item => `<option value="${item.id}">${this.escape(item.title)}</option>`).join("")}</select></label>
      <form id="serviceForm" class="admin-edit-form">
        <label>Title<input name="title" required></label><label>Card title<input name="card_title" required></label>
        <label>Badge<input name="badge"></label><label>Description<textarea name="description" required></textarea></label>
        <label>Detail title<input name="detail_title"></label><label>Detailed information<textarea name="detail_description"></textarea></label>
        <label>Overview<textarea name="overview"></textarea></label><label>Relevance<textarea name="relevance"></textarea></label>
        <label>Eligibility note<input name="eligibility_note"></label><label>Eligibility items (one per line)<textarea name="eligibility"></textarea></label>
        <label>Access information<textarea name="intake_desk_text"></textarea></label>
        <label>Operating hours (one per line: Day | HH:MM | HH:MM | Open/Closed | optional notes)<textarea name="hours_text"></textarea></label>
        <label>Costs<textarea name="cost_info"></textarea></label>
        <label>Contact information<textarea name="contact_info"></textarea></label><label>Website URL<input name="website_url" type="url"></label>
        <label><input name="is_active" type="checkbox"> Published/active</label><button class="btn btn-primary">Save service</button>
      </form></section>`;
    const select = panel.querySelector("#serviceSelect");
    const form = panel.querySelector("#serviceForm");
    const populate = () => {
      const record = services.find(item => String(item.id) === select.value);
      if (!record) return;
      ["title", "card_title", "badge", "description", "detail_title", "detail_description", "overview", "relevance", "eligibility_note", "intake_desk_text", "cost_info", "contact_info", "website_url"].forEach(key => {
        form.elements[key].value = record[key] || "";
      });
      form.elements.eligibility.value = (record.eligibility || []).map(item => item.criterion).join("\n");
      form.elements.hours_text.value = (record.hours || []).map(item =>
        `${item.day_of_week} | ${item.opening_time || ""} | ${item.closing_time || ""} | ${item.is_closed ? "Closed" : "Open"} | ${item.notes || ""}`
      ).join("\n");
      form.elements.is_active.checked = Boolean(record.is_active);
    };
    // Load existing eligibility for the selected service through the public record endpoint.
    const loadEligibility = async () => {
      const record = services.find(item => String(item.id) === select.value);
      if (!record) return;
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/services/${record.id}`);
      if (!response.ok) throw new Error(`Could not load service details (${response.status}).`);
      const detail = await response.json();
      if (!detail.success || !detail.data) throw new Error(detail.message || "Could not load service details.");
      record.eligibility = detail.data.eligibility || [];
      record.hours = detail.data.hours || [];
      populate();
    };
    select.onchange = loadEligibility;
    await loadEligibility();
    form.onsubmit = async event => {
      event.preventDefault();
      const data = Object.fromEntries(new FormData(form));
      data.is_active = form.elements.is_active.checked;
      data.eligibility = String(data.eligibility || "").split("\n").map(value => value.trim()).filter(Boolean);
      data.hours = String(data.hours_text || "").split("\n").map(line => line.trim()).filter(Boolean).map(line => {
        const [day_of_week, opening_time = "", closing_time = "", closedLabel = "Open", ...notes] = line.split("|").map(part => part.trim());
        return {
          day_of_week,
          opening_time,
          closing_time,
          is_closed: closedLabel.toLowerCase() === "closed",
          notes: notes.join(" | ")
        };
      });
      delete data.hours_text;
      await this.api(`/admin/services/${select.value}`, { method: "PATCH", body: JSON.stringify(data) });
      await this.openModule("services");
    };
  },

  async render_events(panel) {
    const [eventsData, newsData] = await Promise.all([
      this.api("/admin/events"), this.api("/admin/announcements")
    ]);
    const events = eventsData.events || [];
    const announcements = newsData.announcements || [];
    this.records.events = events;
    this.records.announcements = announcements;
    panel.innerHTML = `<div class="admin-content-grid">
      <section class="card"><h3>Event editor</h3><form id="eventForm" class="admin-edit-form">
        <input name="id" type="hidden"><label>Title<input name="title" required maxlength="180"></label>
        <label>Description<textarea name="description" required></textarea></label><label>Starts (if confirmed)<input name="starts_at" type="datetime-local"></label>
        <label>Date / time label (for example, To be announced)<input name="schedule_label" maxlength="100"></label>
        <label>Ends (optional)<input name="ends_at" type="datetime-local"></label><label>Location<input name="location"></label>
        <label>Status<select name="status"><option>DRAFT</option><option>PUBLISHED</option><option>CANCELLED</option></select></label>
        <button class="btn btn-primary">Save event</button></form></section>
      <section class="card"><h3>News / announcement editor</h3><form id="newsForm" class="admin-edit-form">
        <input name="id" type="hidden"><label>Title<input name="title" required maxlength="180"></label>
        <label>Content<textarea name="body" required></textarea></label>
        <label>Status<select name="status"><option>DRAFT</option><option>PUBLISHED</option><option>ARCHIVED</option></select></label>
        <button class="btn btn-primary">Save announcement</button></form></section></div>
      <section class="card"><h3>Events</h3>${this.table(["Title", "Starts", "Status", "Edit"], events.map(item =>
        `<tr><td>${this.escape(item.title)}</td><td>${this.escape(item.schedule_label || item.starts_at || "To be announced")}</td><td>${this.escape(item.status)}</td><td><button class="btn btn-secondary btn-sm" data-edit-event="${item.id}">Edit</button></td></tr>`
      ))}</section>
      <section class="card"><h3>Announcements</h3>${this.table(["Title", "Status", "Edit"], announcements.map(item =>
        `<tr><td>${this.escape(item.title)}</td><td>${this.escape(item.status)}</td><td><button class="btn btn-secondary btn-sm" data-edit-news="${item.id}">Edit</button></td></tr>`
      ))}</section>`;
    const eventForm = panel.querySelector("#eventForm");
    eventForm.onsubmit = async event => {
      event.preventDefault();
      const values = Object.fromEntries(new FormData(eventForm));
      await this.api("/admin/events", { method: values.id ? "PATCH" : "POST", body: JSON.stringify(values) });
      await this.openModule("events");
    };
    const newsForm = panel.querySelector("#newsForm");
    newsForm.onsubmit = async event => {
      event.preventDefault();
      const values = Object.fromEntries(new FormData(newsForm));
      await this.api("/admin/announcements", { method: values.id ? "PATCH" : "POST", body: JSON.stringify(values) });
      await this.openModule("events");
    };
    panel.querySelectorAll("[data-edit-event]").forEach(button => button.onclick = () => {
      const item = events.find(record => record.id === Number(button.dataset.editEvent));
      for (const key of ["id", "title", "description", "schedule_label", "location", "status"]) eventForm.elements[key].value = item[key] || "";
      eventForm.elements.starts_at.value = item.starts_at ? item.starts_at.slice(0, 16) : "";
      eventForm.elements.ends_at.value = item.ends_at ? item.ends_at.slice(0, 16) : "";
      eventForm.scrollIntoView({ behavior: "smooth" });
    });
    panel.querySelectorAll("[data-edit-news]").forEach(button => button.onclick = () => {
      const item = announcements.find(record => record.id === Number(button.dataset.editNews));
      for (const key of ["id", "title", "body", "status"]) newsForm.elements[key].value = item[key] || "";
      newsForm.scrollIntoView({ behavior: "smooth" });
    });
  },

  async render_enquiries(panel) {
    const data = await this.api("/admin/enquiries");
    const items = data.enquiries || [];
    panel.innerHTML = `<section class="card"><h3>Contact messages</h3>
      ${this.table(["Received", "Name", "Email", "Subject / message", "Status", "Update"], items.map(item =>
        `<tr><td>${this.escape(item.created_at)}</td><td>${this.escape(item.name)}</td><td>${this.escape(item.email)}</td>
        <td><strong>${this.escape(item.subject)}</strong><br>${this.escape(item.message)}</td><td>${this.escape(item.status)}</td>
        <td><select data-enquiry-status="${item.id}"><option ${item.status === "NEW" ? "selected" : ""}>NEW</option><option ${item.status === "IN_PROGRESS" ? "selected" : ""}>IN_PROGRESS</option><option ${item.status === "RESOLVED" ? "selected" : ""}>RESOLVED</option></select>
        <button class="btn btn-secondary btn-sm" data-save-enquiry="${item.id}">Save</button></td></tr>`
      ))}</section>`;
    panel.querySelectorAll("[data-save-enquiry]").forEach(button => button.onclick = async () => {
      const id = button.dataset.saveEnquiry;
      const status = panel.querySelector(`[data-enquiry-status="${id}"]`).value;
      await this.api("/admin/enquiries", { method: "PATCH", body: JSON.stringify({ id, status }) });
      await this.openModule("enquiries");
    });
  },

  async render_users(panel) {
    const data = await this.api("/admin/users");
    const users = data.users || [];
    panel.innerHTML = `<section class="card"><h3>Existing account permissions</h3>
      <p>Accounts must register and verify before an administrator can grant staff access.</p>
      ${this.table(["Name", "Email", "Current role", "Active", "Change role"], users.map(item =>
        `<tr><td>${this.escape(item.name)}</td><td>${this.escape(item.email)}</td><td>${this.escape(item.role)}</td><td>${item.is_active ? "Yes" : "No"}</td>
        <td><select data-role="${item.id}"><option value="user" ${item.role === "user" ? "selected" : ""}>User</option><option value="admin" ${item.role === "admin" ? "selected" : ""}>Administrator</option></select>
        <button class="btn btn-secondary btn-sm" data-save-role="${item.id}">Save</button></td></tr>`
      ))}</section>`;
    panel.querySelectorAll("[data-save-role]").forEach(button => button.onclick = async () => {
      const id = button.dataset.saveRole;
      const role = panel.querySelector(`[data-role="${id}"]`).value;
      await this.api("/admin/users", { method: "PATCH", body: JSON.stringify({ user_id: id, role }) });
      await this.openModule("users");
    });
  },

  async render_reports(panel) {
    const data = await this.api("/admin/reports");
    panel.innerHTML = `<section class="card"><h3>Appointment trends (last six months)</h3>
      ${this.appointmentChart(data.monthly_appointments || [])}
      <p class="appointment-field-help">Appointments are not currently linked to a service category, so service popularity cannot be reported without changing the booking data model.</p></section>
      <section class="card"><h3>Appointments (last 90 days)</h3>
      ${this.table(["Date", "Status", "Total"], (data.appointments || []).map(item =>
        `<tr><td>${this.escape(item.report_date)}</td><td>${this.escape(item.status)}</td><td>${this.escape(item.total)}</td></tr>`
      ))}</section><section class="card"><h3>Contact messages by status</h3>
      ${this.table(["Status", "Total"], (data.enquiries || []).map(item =>
        `<tr><td>${this.escape(item.status)}</td><td>${this.escape(item.total)}</td></tr>`
      ))}</section>`;
  },

  async render_settings(panel) {
    const data = await this.api("/admin/settings");
    const settings = Object.fromEntries((data.settings || []).map(item => [item.setting_key, item.setting_value]));
    const keys = ["site_name", "contact_phone", "contact_email", "address", "opening_hours"];
    panel.innerHTML = `<section class="card"><h3>Public website details</h3>
      <p>Only approved, verified information should be published here.</p>
      <form id="settingsForm" class="admin-edit-form">${keys.map(key =>
        `<label>${this.escape(key.replaceAll("_", " "))}${key === "opening_hours" || key === "address" ? `<textarea name="${key}">${this.escape(settings[key] || "")}</textarea>` : `<input name="${key}" value="${this.escape(settings[key] || "")}">`}</label>`
      ).join("")}<button class="btn btn-primary">Save settings</button></form></section>`;
    panel.querySelector("#settingsForm").onsubmit = async event => {
      event.preventDefault();
      await this.api("/admin/settings", {
        method: "PATCH",
        body: JSON.stringify({ settings: Object.fromEntries(new FormData(event.currentTarget)) })
      });
      await this.openModule("settings");
    };
  },

  async render_activity(panel) {
    const data = await this.api("/admin/activity");
    panel.innerHTML = `<section class="card"><h3>Administrator activity</h3>
      ${this.table(["Date", "Administrator", "Action", "Record", "Details"], (data.entries || []).map(item =>
        `<tr><td>${this.escape(item.created_at)}</td><td>${this.escape(item.actor)}</td><td>${this.escape(item.action)}</td><td>${this.escape(item.entity_type)} ${this.escape(item.entity_id || "")}</td><td>${this.escape(item.description)}</td></tr>`
      ))}</section>`;
  },

  formatDateTime(value) {
    if (!value) return "";
    const [date, time = "00:00"] = value.replace(" ", "T").split("T");
    const [year, month, day] = date.split("-").map(Number);
    const [hour, minute] = time.split(":").map(Number);
    const dateLabel = new Date(year, month - 1, day).toLocaleDateString(undefined, {
      weekday: "short", year: "numeric", month: "short", day: "numeric"
    });
    return `${dateLabel}, ${hour % 12 || 12}:${String(minute).padStart(2, "0")} ${hour < 12 ? "am" : "pm"}`;
  }
};

window.AdminManager = AdminManager;
