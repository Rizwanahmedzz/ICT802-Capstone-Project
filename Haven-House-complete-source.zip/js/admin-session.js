const AdminSessionGuard = {
  idleTimeoutMs: 15 * 60 * 1000,
  timer: null,
  lastActivityReset: 0,
  activityEvents: ["pointerdown", "keydown", "scroll", "touchstart"],

  start() {
    this.stop();
    this.lastActivityReset = 0;
    this.activityEvents.forEach(eventName => {
      window.addEventListener(eventName, this.handleActivity, { passive: true });
    });
    this.resetTimer();
  },

  stop() {
    if (this.timer) window.clearTimeout(this.timer);
    this.timer = null;
    this.activityEvents.forEach(eventName => {
      window.removeEventListener(eventName, this.handleActivity);
    });
  },

  resetTimer() {
    const now = Date.now();
    if (now - this.lastActivityReset < 1000) return;
    this.lastActivityReset = now;
    if (this.timer) window.clearTimeout(this.timer);
    this.timer = window.setTimeout(() => {
      sessionStorage.setItem("haven_house_admin_access_notice", "Your admin session ended after 15 minutes of inactivity. Please sign in again.");
      AuthManager.logout().then(() => Router.navigate("admin-login")).catch(error => {
        console.error("[Admin session] Could not complete idle sign-out cleanly.", error);
        Router.navigate("admin-login");
      });
    }, this.idleTimeoutMs);
  },

  handleActivity() {
    AdminSessionGuard.resetTimer();
  }
};

window.AdminSessionGuard = AdminSessionGuard;
