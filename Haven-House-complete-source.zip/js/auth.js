/**
 * Centralized Authentication Manager for Haven House Prototype
 * Supports Two-Layer Authentication:
 *   - Layer 1: Password Verification -> Issues Temporary OTP Challenge
 *   - Layer 2: 6-Digit OTP Verification -> Issues Final Authenticated JWT Session
 */

const TOKEN_KEY = "haven_house_auth_token";
const USER_KEY = "haven_house_auth_user";

const AuthManager = {
  currentUser: null,
  token: null,
  pendingChallenge: null, // { challenge_id, destination, method, expires_in_seconds }
  pendingPasswordReset: null,

  init() {
    this.token = localStorage.getItem(TOKEN_KEY) || null;
    const cachedUser = localStorage.getItem(USER_KEY);
    if (cachedUser) {
      try {
        this.currentUser = JSON.parse(cachedUser);
      } catch (e) {
        this.currentUser = null;
      }
    }

    const pendingReset = sessionStorage.getItem("haven_house_password_reset");
    if (pendingReset) {
      try {
        this.pendingPasswordReset = JSON.parse(pendingReset);
      } catch (error) {
        this.pendingPasswordReset = null;
        sessionStorage.removeItem("haven_house_password_reset");
      }
    }

    if (this.token) {
      // Validate session with server in background
      this.checkSession();
    }

    this.updateAuthUI();
  },

  getToken() {
    return this.token || localStorage.getItem(TOKEN_KEY);
  },

  isAuthenticated() {
    return !!this.getToken();
  },

  getCurrentUser() {
    return this.currentUser;
  },

  getPendingChallenge() {
    return this.pendingChallenge;
  },

  async register(name, email, password) {
    try {
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password })
      });

      const json = await response.json();
      if (!response.ok || !json.success) {
        throw new Error(json.message || "Registration failed. Please check your details.");
      }

      return { success: true, data: json.data, message: json.message };
    } catch (err) {
      return { success: false, message: err.message };
    }
  },

  /**
   * Step 1: Password Authentication
   * Validates credentials and receives a 2FA OTP challenge.
   */
  async login(email, password) {
    try {
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });

      const json = await response.json();
      if (!response.ok || !json.success) {
        throw new Error(json.message || "Invalid email or password.");
      }

      const data = json.data && typeof json.data === "object" ? json.data : {};
      const challengeData = data.challenge && typeof data.challenge === "object"
        ? data.challenge
        : data.otp_challenge && typeof data.otp_challenge === "object"
          ? data.otp_challenge
          : data;
      const authenticationStatus = String(
        data.status || data.authentication_status || data.auth_status || ""
      ).trim().toLowerCase();
      const challengeId = challengeData.challenge_id || challengeData.challengeId;

      // Two-Factor Challenge Required (Layer 2)
      if (
        ["otp_required", "verification_required", "mfa_required"].includes(authenticationStatus)
        || (typeof challengeId === "string" && challengeId.length > 0)
      ) {
        if (typeof challengeId !== "string" || challengeId.length === 0) {
          throw new Error("The server requested a verification code but did not return a valid challenge. Please try signing in again.");
        }
        this.pendingChallenge = {
          challenge_id: challengeId,
          destination: challengeData.destination || "",
          method: challengeData.method || "email",
          expires_in_seconds: Number(challengeData.expires_in_seconds) || 300
        };
        return { success: true, otpRequired: true, challenge: this.pendingChallenge };
      }

      // Direct Token Fallback (if 2FA disabled)
      const token = data.token || data.access_token;
      if (token && data.user) {
        this.setAuthenticatedSession(token, data.user);
        return { success: true, otpRequired: false, user: this.currentUser };
      }

      throw new Error("Sign-in was accepted, but the server returned neither a verification challenge nor a complete session. Please try again; if it repeats, restart the API server.");
    } catch (err) {
      return { success: false, message: err.message };
    }
  },

  /**
   * Step 2: OTP Verification
   * Submits 6-digit OTP against active challenge to receive final authenticated JWT.
   */
  async verifyOtp(otpCode) {
    if (!this.pendingChallenge || !this.pendingChallenge.challenge_id) {
      return { success: false, message: "No active verification challenge. Please sign in again." };
    }

    try {
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/auth/verify-otp`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          challenge_id: this.pendingChallenge.challenge_id,
          otp: otpCode
        })
      });

      const json = await response.json();
      if (!response.ok || !json.success) {
        throw new Error(json.message || "Invalid verification code.");
      }

      const data = json.data;
      if (!data.token || !data.user) {
        throw new Error("Invalid session data received from server.");
      }

      // Successful 2FA verification -> Establish Full Session
      this.setAuthenticatedSession(data.token, data.user);
      this.pendingChallenge = null;

      return { success: true, user: this.currentUser };
    } catch (err) {
      return { success: false, message: err.message };
    }
  },

  /**
   * Resend / Refresh OTP Code for active challenge
   */
  async resendOtp() {
    if (!this.pendingChallenge || !this.pendingChallenge.challenge_id) {
      return { success: false, message: "No active challenge found. Please sign in again." };
    }

    try {
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/auth/request-otp`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          challenge_id: this.pendingChallenge.challenge_id,
          method: this.pendingChallenge.method || "email"
        })
      });

      const json = await response.json();
      if (!response.ok || !json.success) {
        throw new Error(json.message || "Could not resend verification code.");
      }

      if (json.data && json.data.expires_in_seconds) {
        this.pendingChallenge.expires_in_seconds = json.data.expires_in_seconds;
      }

      return { success: true, message: json.message || "New verification code sent." };
    } catch (err) {
      return { success: false, message: err.message };
    }
  },

  async requestPasswordReset(email) {
    try {
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/auth/password-reset/request`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email })
      });
      const json = await response.json();
      if (!response.ok || !json.success || !json.data?.challenge_id) {
        throw new Error(json.message || "Could not request a password reset.");
      }

      this.pendingPasswordReset = {
        challenge_id: json.data.challenge_id,
        expires_in_seconds: json.data.expires_in_seconds || 300
      };
      sessionStorage.setItem("haven_house_password_reset", JSON.stringify(this.pendingPasswordReset));
      return { success: true, message: json.message };
    } catch (error) {
      return { success: false, message: error.message };
    }
  },

  async confirmPasswordReset(otp, password) {
    if (!this.pendingPasswordReset?.challenge_id) {
      return { success: false, message: "Request a new password reset code first." };
    }

    try {
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/auth/password-reset/confirm`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          challenge_id: this.pendingPasswordReset.challenge_id,
          otp,
          password
        })
      });
      const json = await response.json();
      if (!response.ok || !json.success) {
        throw new Error(json.message || "Could not reset your password.");
      }

      this.pendingPasswordReset = null;
      sessionStorage.removeItem("haven_house_password_reset");
      return { success: true, message: json.message };
    } catch (error) {
      return { success: false, message: error.message };
    }
  },

  async adminLogin(username, passcode) {
    try {
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/auth/admin-login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, passcode })
      });
      const json = await response.json();
      if (!response.ok || !json.success) {
        return { success: false, message: json.message || "Invalid username or passcode." };
      }
      this.setAuthenticatedSession(json.data.token, json.data.user);
      return { success: true };
    } catch (error) {
      return { success: false, message: "Could not reach the server. Please try again." };
    }
  },

  cancelOtp() {
    this.pendingChallenge = null;
    if (window.Router) {
      window.Router.navigate("login");
    }
  },

  setAuthenticatedSession(token, user) {
    this.token = token;
    this.currentUser = user;
    localStorage.setItem(TOKEN_KEY, this.token);
    localStorage.setItem(USER_KEY, JSON.stringify(this.currentUser));
    this.updateAuthUI();
  },

  async logout() {
    if (this.token) {
      try {
        await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/auth/logout`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${this.token}`
          }
        });
      } catch (e) {
        // Stateless JWT logout continues on client
      }
    }

    this.token = null;
    this.currentUser = null;
    this.pendingChallenge = null;
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);

    this.updateAuthUI();
    if (window.Router) {
      window.Router.navigate("home");
    }
  },

  async checkSession() {
    if (!this.token) return;

    try {
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/auth/me`, {
        headers: {
          "Authorization": `Bearer ${this.token}`
        }
      });

      if (response.status === 401) {
        this.token = null;
        this.currentUser = null;
        localStorage.removeItem(TOKEN_KEY);
        localStorage.removeItem(USER_KEY);
        this.updateAuthUI();
        return;
      }

      const json = await response.json();
      if (json.success && json.data && json.data.user) {
        this.currentUser = json.data.user;
        localStorage.setItem(USER_KEY, JSON.stringify(this.currentUser));
        this.updateAuthUI();
      }
    } catch (err) {
      console.warn("[Auth Session Check Failed]", err.message);
    }
  },

  async authenticatedFetch(url, options = {}) {
    const token = this.getToken();
    const headers = options.headers ? { ...options.headers } : {};

    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }

    const response = await fetch(url, { ...options, headers });

    if (response.status === 401 && token) {
      this.token = null;
      this.currentUser = null;
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
      this.updateAuthUI();
    }

    return response;
  },

  updateAuthUI() {
    const authElements = document.querySelectorAll(".auth-user-display");
    const loginLinks = document.querySelectorAll(".auth-login-link");
    const registerLinks = document.querySelectorAll(".auth-register-link");
    const logoutBtns = document.querySelectorAll(".auth-logout-btn");
    const adminLinks = document.querySelectorAll(".admin-only");

    if (this.isAuthenticated() && this.currentUser) {
      authElements.forEach(el => {
        el.textContent = this.currentUser.name || this.currentUser.email;
        el.style.display = "inline-flex";
      });
      loginLinks.forEach(el => el.style.display = "none");
      registerLinks.forEach(el => el.style.display = "none");
      logoutBtns.forEach(el => el.style.display = "inline-flex");
      adminLinks.forEach(el => {
        el.style.display = this.currentUser.role === "admin" ? "flex" : "none";
      });
    } else {
      authElements.forEach(el => el.style.display = "none");
      loginLinks.forEach(el => el.style.display = "inline-flex");
      registerLinks.forEach(el => el.style.display = "inline-flex");
      logoutBtns.forEach(el => el.style.display = "none");
      adminLinks.forEach(el => el.style.display = "none");
    }
  }
};

window.AuthManager = AuthManager;
