/**
 * Haven House Main Application Controller
 * Handles API data fetching, dynamic rendering, modals, and user interactions.
 */

const App = {
  services: [],
  faqs: [],

  async init() {
    // 1. Initialize Auth, Navigation & Chat Controllers
    if (window.AuthManager) AuthManager.init();
    Router.init();
    ChatController.init();
    FloatingWidget.init();

    // 2. Fetch Data from Flask API & Render Components
    await this.loadServices();
    await this.loadFaqs();
    await this.loadPublicContent();

    // 3. Setup Global Event Listeners
    this.setupEventListeners();
  },

  /**
   * Fetch active services from Flask API: GET /api/services
   */
  async loadServices() {
    try {
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/services`);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const json = await response.json();
      if (json.success && Array.isArray(json.data)) {
        this.services = json.data;
        Router.cachedServices = this.services;
        this.renderHomeServiceCards();
        this.renderStep1ServiceCards();
        return;
      }
    } catch (err) {
      console.warn(`[API] Could not fetch services from API: ${err.message}. Displaying local referral fallback.`);
      if (HAVEN_HOUSE_CONFIG.fallbackServices && HAVEN_HOUSE_CONFIG.fallbackServices.length > 0) {
        this.services = HAVEN_HOUSE_CONFIG.fallbackServices;
        Router.cachedServices = this.services;
        this.renderHomeServiceCards();
        this.renderStep1ServiceCards();
      } else {
        this.renderServicesError();
      }
    }
  },

  renderHomeServiceCards() {
    const container = document.getElementById("homeServicesGrid");
    const aboutContainer = document.getElementById("aboutServicesGrid");
    if (!container && !aboutContainer) return;

    if (this.services.length === 0) {
      const message = `<p style="color: var(--color-text-muted); grid-column: 1/-1;">Service information is temporarily unavailable. Please try again.</p>`;
      if (container) container.innerHTML = message;
      if (aboutContainer) aboutContainer.innerHTML = message;
      return;
    }

    const homeServiceOrder = {
      accommodation: 0,
      ndis: 1,
      psychology: 2,
      employment: 3,
      "child-support": 4,
      "general-info": 5
    };
    const homeServices = this.services
      .filter(service => service.service_key !== "chaplaincy")
      .sort((left, right) => (homeServiceOrder[left.service_key] ?? 99) - (homeServiceOrder[right.service_key] ?? 99));
    const homeCards = homeServices.map((service, index) => {
      const iconSvg = HAVEN_HOUSE_CONFIG.ICONS[service.icon_name] || HAVEN_HOUSE_CONFIG.ICONS["default"];
      const keyOrId = service.service_key || service.id;
      return `
        <article class="service-card-select home-service-card" data-service-key="${this.escapeHTML(service.service_key)}" style="--stack-i:${index}"
                 role="link" tabindex="0" aria-label="View ${this.escapeHTML(service.card_title || service.title)} details"
                 onclick="App.bounceAndOpen(this, '${keyOrId}')"
                 onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();App.bounceAndOpen(this, '${keyOrId}')}">
          <div class="service-card-icon">${iconSvg}</div>
          <div class="home-service-text">
            ${this.serviceImageMarkup(service)}
            <div class="service-card-title">${this.escapeHTML(service.card_title || service.title)}</div>
            <div class="service-card-desc">${this.escapeHTML(service.description)}</div>
            <button class="home-service-link" type="button" onclick="event.stopPropagation();App.bounceAndOpen(this.closest('.home-service-card'), '${keyOrId}')">Learn More <span aria-hidden="true">→</span></button>
          </div>
        </article>
      `;
    }).join("");
    const aboutCards = this.services.map(service => {
      const iconSvg = HAVEN_HOUSE_CONFIG.ICONS[service.icon_name] || HAVEN_HOUSE_CONFIG.ICONS["default"];
      const keyOrId = service.service_key || service.id;
      return `
        <div class="service-card-select">
          ${this.serviceImageMarkup(service)}
          <div class="service-card-icon">${iconSvg}</div>
          <div class="service-card-title">${this.escapeHTML(service.card_title || service.title)}</div>
          <div class="service-card-desc">${this.escapeHTML(service.description)}</div>
          <button class="btn btn-secondary btn-sm" type="button" onclick="Router.setSelectedService('${keyOrId}')">View service details</button>
        </div>
      `;
    }).join("");
    if (container) container.innerHTML = homeCards;
    if (aboutContainer) aboutContainer.innerHTML = aboutCards;
  },

  bounceAndOpen(card, serviceKey) {
    const open = () => Router.navigate("service-detail", serviceKey);
    if (!card || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      open();
      return;
    }
    if (card.classList.contains("is-bouncing")) return;
    card.classList.add("is-bouncing");
    setTimeout(() => {
      card.classList.remove("is-bouncing");
      open();
    }, 450);
  },

  serviceImageMarkup(service) {
    const images = {
      accommodation: ["assets/accommodation-support.jpg", "A support worker helping someone view an accommodation option"],
      "child-support": ["assets/children-family-support.jpg", "A family support worker speaking with a parent and young child"],
      ndis: ["assets/ndis-support.jpg", "A disability support worker helping a wheelchair user prepare food"],
      psychology: ["assets/counselling-support.jpg", "A counsellor speaking with a client during a private session"],
      employment: ["assets/employment-skills-support.jpg", "A group taking part in a job skills and resume workshop"],
      chaplaincy: ["assets/chaplaincy-pastoral-care.jpg", "A chaplain talking with a person in a supportive setting"],
      "general-info": ["assets/information-referrals.jpg", "A community member speaking with staff at an information and referral desk"]
    };
    const image = images[service.service_key];
    return image
      ? `<img class="service-card-image" src="${image[0]}" alt="${image[1]}" loading="lazy">`
      : "";
  },

  renderStep1ServiceCards() {
    const container = document.getElementById("step1ServicesGrid");
    if (!container) return;

    if (this.services.length === 0) {
      container.innerHTML = `<p style="color: var(--color-text-muted); grid-column: 1/-1;">Service categories are temporarily unavailable. Please try again.</p>`;
      return;
    }

    container.innerHTML = this.services.map((service, index) => {
      const iconSvg = HAVEN_HOUSE_CONFIG.ICONS[service.icon_name] || HAVEN_HOUSE_CONFIG.ICONS["default"];
      const keyOrId = service.service_key || service.id;
      const isSelected = Router.selectedServiceId === keyOrId || Router.selectedServiceId === service.service_key;
      const serviceImage = this.serviceImageMarkup(service);

      return `
        <div class="service-card-select ${isSelected ? 'selected' : ''}" data-service-index="${index}" data-service-key="${this.escapeHTML(service.service_key || "")}"
             role="button" 
             tabindex="0" 
             onclick="App.selectServiceInStep1('${keyOrId}')"
             onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();App.selectServiceInStep1('${keyOrId}')}">
          ${serviceImage}
          <div class="service-card-icon">${iconSvg}</div>
          <div class="service-card-title">${this.escapeHTML(service.card_title || service.title)}</div>
          <div class="service-card-desc">${this.escapeHTML(service.description)}</div>
        </div>
      `;
    }).join("");
    this.filterServiceCards(document.getElementById("serviceSearchInput")?.value || "");
  },

  filterServiceCards(query) {
    const container = document.getElementById("step1ServicesGrid");
    const status = document.getElementById("serviceSearchStatus");
    const empty = document.getElementById("serviceSearchEmpty");
    if (!container) return;
    const aliases = {
      accommodation: "housing shelter home lodging tenancy আবাসন आवास سكن",
      "child-support": "children child youth family parenting শিশু পরিবার बच्चे परिवार أطفال عائلة",
      ndis: "disability disabled wheelchair ndis",
      psychology: "counselling counseling mental health emotional কাউন্সেলিং परामर्श الإرشاد",
      employment: "job work career resume skills কাজ रोजगार العمل",
      chaplaincy: "chaplain pastoral faith spiritual",
      "general-info": "information referral advice help"
    };
    const normalizedQuery = query.trim().toLocaleLowerCase();
    let visibleCount = 0;
    container.querySelectorAll("[data-service-index]").forEach(card => {
      const service = this.services[Number(card.dataset.serviceIndex)];
      const keywords = `${card.textContent} ${aliases[service?.service_key] || ""}`.toLocaleLowerCase();
      const visible = !normalizedQuery || keywords.includes(normalizedQuery);
      card.hidden = !visible;
      if (visible) visibleCount += 1;
    });
    if (status) status.textContent = `Showing ${visibleCount} of ${this.services.length} services.`;
    if (empty) empty.hidden = visibleCount !== 0;
  },

  renderServicesError() {
    const homeGrid = document.getElementById("homeServicesGrid");
    const step1Grid = document.getElementById("step1ServicesGrid");
    const errMsg = `
      <div class="card" style="grid-column: 1/-1; background-color: var(--color-bg-surface); border: 1px solid var(--color-border-light);">
        <p style="color: var(--color-text-body); font-weight: 500;">Service information is temporarily unavailable. Please verify backend connection or refresh.</p>
        <button class="btn btn-secondary btn-sm" style="margin-top: 10px;" onclick="App.loadServices()">Retry</button>
      </div>
    `;
    if (homeGrid) homeGrid.innerHTML = errMsg;
    if (step1Grid) step1Grid.innerHTML = errMsg;
  },

  selectServiceInStep1(serviceKeyOrId) {
    Router.setSelectedService(serviceKeyOrId);
  },

  /**
   * Fetch active FAQs from Flask API: GET /api/faqs
   */
  async loadFaqs() {
    try {
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/faqs`);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const json = await response.json();
      if (json.success && Array.isArray(json.data) && json.data.length > 0) {
        this.faqs = json.data;
        this.renderFaqAccordion();
        return;
      }
    } catch (err) {
      console.warn(`[API] Could not fetch FAQs from API: ${err.message}.`);
    }
    this.faqs = (HAVEN_HOUSE_CONFIG.fallbackFaqs || []).map(faq => ({ ...faq, isFallback: true }));
    this.renderFaqAccordion();
  },

  escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[char]));
  },

  renderPublicContent(events, announcements) {
    const eventsList = document.getElementById("publicEventsList");
    const announcementsList = document.getElementById("publicAnnouncementsList");
    if (eventsList) {
      eventsList.innerHTML = events.length ? events.map(item => `
        <article class="card public-event-card"><h4>${this.escapeHTML(item.title)}</h4>
          <p>${this.escapeHTML(item.description)}</p>
          <p class="public-content-meta public-event-date"><strong>Date:</strong> ${this.escapeHTML(item.schedule_label || (item.starts_at ? new Date(item.starts_at).toLocaleString() : "To be announced"))}</p>
          <p class="public-content-meta public-event-location"><strong>Location:</strong> ${this.escapeHTML(item.location || "To be announced")}</p>
        </article>`).join("") : "<p class='appointment-field-help'>There are no approved event details to display right now.</p>";
    }
    if (announcementsList) {
      announcementsList.innerHTML = announcements.length ? announcements.map(item => `
        <article class="card public-announcement-card"><h4>${this.escapeHTML(item.title)}</h4>
          <p>${this.escapeHTML(item.body)}</p>
          <p class="public-content-meta public-announcement-date">${item.published_at ? this.escapeHTML(new Date(item.published_at).toLocaleDateString()) : ""}</p>
        </article>`).join("") : "<p class='appointment-field-help'>There are no approved updates to display right now.</p>";
    }
  },

  async loadPublicContent() {
    const eventsList = document.getElementById("publicEventsList");
    const announcementsList = document.getElementById("publicAnnouncementsList");
    try {
      const [eventsResponse, newsResponse, settingsResponse] = await Promise.all([
        fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/events`),
        fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/announcements`),
        fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/site-settings`)
      ]);
      if (!eventsResponse.ok || !newsResponse.ok || !settingsResponse.ok) {
        throw new Error("Public information is temporarily unavailable.");
      }
      const [eventsJson, newsJson, settingsJson] = await Promise.all([
        eventsResponse.json(), newsResponse.json(), settingsResponse.json()
      ]);
      if (!eventsJson.success || !newsJson.success || !settingsJson.success) {
        throw new Error("Public information is temporarily unavailable.");
      }
      const events = eventsJson.data.events || [];
      const announcements = newsJson.data.announcements || [];
      this.renderPublicContent(
        events.length ? events : (HAVEN_HOUSE_CONFIG.fallbackEvents || []),
        announcements.length ? announcements : (HAVEN_HOUSE_CONFIG.fallbackAnnouncements || [])
      );
      const publicSettings = settingsJson.data || {};
      if (publicSettings.site_name) {
        ["mobileBrandTitle", "desktopBrandTitle"].forEach(id => {
          const element = document.getElementById(id);
          if (element) element.textContent = publicSettings.site_name;
        });
        const footerTitle = document.getElementById("footerBrandTitle");
        if (footerTitle) footerTitle.textContent = `© ${new Date().getFullYear()} ${publicSettings.site_name}`;
        document.title = `${publicSettings.site_name} — Crisis Support Services | Get Help`;
      }
      this.renderContactDetails(publicSettings);
    } catch (error) {
      console.warn(`[API] Could not load approved public content: ${error.message}`);
      this.renderContactDetails();
      this.renderPublicContent(
        HAVEN_HOUSE_CONFIG.fallbackEvents || [],
        HAVEN_HOUSE_CONFIG.fallbackAnnouncements || []
      );
    }
  },

  renderContactDetails(settings = {}) {
    const container = document.getElementById("publicContactDetails");
    if (!container) return;
    const rows = [
      ["📍", "Location", settings.address || "Bondi, NSW"],
      ["📞", "Phone", settings.contact_phone],
      ["✉️", "Email", settings.contact_email],
      ["🕐", "Hours", settings.opening_hours]
    ].filter(row => row[2]);
    container.innerHTML = rows.map(([icon, label, value]) =>
      `<span class="contact-detail-row"><span aria-hidden="true">${icon}</span> <strong>${label}:</strong> ${this.escapeHTML(value)}</span>`
    ).join("");
  },

  renderFaqAccordion() {
    const container = document.getElementById("faqListContainer");
    if (!container) return;

    if (this.faqs.length === 0) {
      container.innerHTML = `<p style="color: var(--color-text-muted);">Frequently asked questions are temporarily unavailable.</p>`;
      return;
    }

    container.innerHTML = this.faqs.map((faq, index) => `
      <div class="faq-item ${index === 0 ? 'expanded' : ''}" id="faq-${faq.id}">
        <button class="faq-question-btn" onclick="App.toggleFaq('faq-${faq.id}')" aria-expanded="${index === 0}">
          <span>${faq.question}</span>
          <svg class="faq-toggle-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg>
        </button>
        <div class="faq-answer-pane">
          <p style="white-space: pre-line; margin-top: 12px;">${faq.answer}</p>
          ${faq.isFallback ? "" : `
          <div class="faq-feedback-box">
            <span class="faq-feedback-label">Was this information helpful?</span>
            <div class="btn-group">
              <button class="feedback-btn" onclick="App.handleFaqFeedback(this, ${faq.id}, 'YES')">Yes</button>
              <button class="feedback-btn" onclick="App.handleFaqFeedback(this, ${faq.id}, 'NO')">No</button>
            </div>
          </div>`}

          <div class="faq-connect-box">
            <span class="faq-connect-text">Still need help? Let's connect you directly.</span>
            <div class="btn-group">
              <button class="btn btn-secondary btn-sm" onclick="Router.navigate('services-step-1')">Find a service</button>
              <button class="btn btn-navy btn-sm" onclick="App.openContactModal('FAQ Follow-up')">Contact Haven House</button>
            </div>
          </div>
        </div>
      </div>
    `).join("");
  },

  renderFaqsError() {
    const container = document.getElementById("faqListContainer");
    if (container) {
      container.innerHTML = `
        <div class="card">
          <p style="color: var(--color-text-body);">FAQ information is temporarily unavailable. Please try again.</p>
          <button class="btn btn-secondary btn-sm" style="margin-top: 10px;" onclick="App.loadFaqs()">Retry</button>
        </div>
      `;
    }
  },

  toggleFaq(elementId) {
    const item = document.getElementById(elementId);
    if (!item) return;

    const isExpanded = item.classList.contains("expanded");
    item.classList.toggle("expanded", !isExpanded);
    const btn = item.querySelector(".faq-question-btn");
    if (btn) btn.setAttribute("aria-expanded", !isExpanded);
  },

  /**
   * Submit FAQ feedback to Flask API: POST /api/faqs/<faq_id>/feedback
   */
  async handleFaqFeedback(buttonEl, faqId, responseVal) {
    const parentGroup = buttonEl.closest(".btn-group");
    if (!parentGroup) return;

    const feedbackBox = buttonEl.closest(".faq-feedback-box");
    const label = feedbackBox ? feedbackBox.querySelector(".faq-feedback-label") : null;

    // Visual selection immediately
    parentGroup.querySelectorAll(".feedback-btn").forEach(b => b.classList.remove("selected"));
    buttonEl.classList.add("selected");

    try {
      const res = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/faqs/${faqId}/feedback`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ response: responseVal })
      });

      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      const json = await res.json();

      if (json.success && label) {
        label.textContent = responseVal === "YES" ? "✓ Thank you for your feedback." : "Thank you. Our team continuously refines approved guides.";
        label.style.color = "var(--color-teal)";
        label.style.fontWeight = "600";
      }
    } catch (err) {
      console.warn(`[API] Failed to submit FAQ feedback: ${err.message}`);
      if (label) {
        label.textContent = "Feedback recorded locally (network offline).";
        label.style.color = "var(--color-text-muted)";
      }
    }
  },

  // Step 2 Sub-action triggers
  async handleStep2Action(actionType) {
    let data = Router.currentServiceData;
    const wanted = Router.selectedServiceId || "accommodation";
    if (!data || !data.service || (data.service.service_key !== wanted && String(data.service.id) !== String(wanted))) {
      data = await Router.fetchServiceComposite(wanted);
    }
    this.openInfoPanel(actionType, data);
  },

  openInfoPanel(type, data) {
    const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    const service = (data && data.service) || {};
    const d = (data && data.details) || {};
    const serviceTitle = service.title || "Service";
    const para = (t) => (t ? `<p>${esc(t)}</p>` : "");
    const list = (items) => `<ul class="info-panel-list">${items.map((i) => `<li>${esc(i)}</li>`).join("")}</ul>`;
    let title = "";
    let body = "";
    let actions = '<button class="btn btn-secondary" onclick="App.closeInfoPanel()">Close</button>';

    if (type === "available") {
      title = "What support is available?";
      const m = String(d.overview || "").match(/^(.*?)\s*Support may include:\s*(.*)$/s);
      if (m) {
        const items = m[2].replace(/\.\s*$/, "").split(";").map((s) => s.trim().replace(/^and\s+/i, "")).filter(Boolean)
          .map((s) => s.charAt(0).toUpperCase() + s.slice(1));
        body = para(d.detail_description) + para(m[1]) + "<h4>Support may include:</h4>" + list(items);
      } else {
        body = para(d.detail_description) + para(d.overview) + para(d.relevance);
      }
    } else if (type === "eligibility") {
      title = "Eligibility";
      body = "<h4>Who may be eligible?</h4>" + para(d.eligibility_note);
      const crit = ((data && data.eligibility) || []).map((e) => e.criterion).filter(Boolean);
      if (crit.length) body += list(crit);
      actions = '<button class="btn btn-secondary" onclick="App.closeInfoPanel()">Close</button>' +
        '<button class="btn btn-navy" onclick="App.contactFromInfoPanel()">Contact the team</button>';
    } else if (type === "contact") {
      title = "Contact the team";
      body = "<h4>Need assistance?</h4>" + para(d.intake_desk_text) + para(d.contact_info);
      if (d.website_url) body += `<p><a href="${esc(d.website_url)}" target="_blank" rel="noopener">${esc(d.website_url)}</a></p>`;
      actions = '<button class="btn btn-secondary" onclick="App.closeInfoPanel()">Close</button>' +
        '<button class="btn btn-navy" onclick="App.contactFromInfoPanel()">Send an enquiry</button>';
    } else if (type === "hours") {
      title = "Opening hours";
      const hours = (data && data.hours) || [];
      const rows = hours.filter((h) => h.day_of_week);
      if (rows.length) {
        const t = (v) => String(v || "").slice(0, 5);
        body = '<table class="info-panel-hours">' + rows.map((h) =>
          `<tr><td>${esc(h.day_of_week)}</td><td>${h.is_closed ? "Closed" : esc(t(h.opening_time)) + " – " + esc(t(h.closing_time))}</td></tr>`).join("") + "</table>";
      }
      body += hours.map((h) => para(h.notes)).join("");
      if (!body) body = para("Contact the team to confirm availability.");
    }

    this._infoPanelTitle = serviceTitle;
    document.getElementById("infoModalService").textContent = serviceTitle;
    document.getElementById("infoModalTitle").textContent = title;
    document.getElementById("infoModalBody").innerHTML = body;
    document.getElementById("infoModalActions").innerHTML = actions;
    document.getElementById("infoModal").classList.add("open");
  },

  closeInfoPanel() {
    const m = document.getElementById("infoModal");
    if (m) m.classList.remove("open");
  },

  contactFromInfoPanel() {
    this.closeInfoPanel();
    this.openContactModal(this._infoPanelTitle || "Service Inquiry");
  },

  // Modals
  openCallModal() {
    const modal = document.getElementById("callModal");
    if (modal) modal.classList.add("open");
  },

  closeCallModal() {
    const modal = document.getElementById("callModal");
    if (modal) modal.classList.remove("open");
  },

  openContactModal(serviceContext = "General Inquiry") {
    const modal = document.getElementById("contactModal");
    const label = document.getElementById("contactModalContext");
    if (label) label.textContent = serviceContext;
    const form = document.getElementById("contactEnquiryForm");
    if (form) form.elements.subject.value = serviceContext;
    if (modal) modal.classList.add("open");
  },

  closeContactModal() {
    const modal = document.getElementById("contactModal");
    if (modal) modal.classList.remove("open");
  },

  openHoursModal(data) {
    const modal = document.getElementById("hoursModal");
    const titleEl = document.getElementById("hoursModalTitle");
    const bodyEl = document.getElementById("hoursModalBody");

    const serviceTitle = data && data.service ? data.service.title : "Service";
    let hoursText = "Standard coordination: Monday to Friday. 24/7 intake assessment for emergency situations.";

    if (data && data.hours && data.hours.length > 0) {
      const hourNotes = data.hours.map(h => h.notes).filter(Boolean);
      if (hourNotes.length > 0) {
        hoursText = hourNotes.join("\n");
      }
    }

    if (titleEl) titleEl.textContent = `${serviceTitle} — Operating Hours`;
    if (bodyEl) bodyEl.textContent = hoursText;
    if (modal) modal.classList.add("open");
  },

  closeHoursModal() {
    const modal = document.getElementById("hoursModal");
    if (modal) modal.classList.remove("open");
  },

  openPolicyModal(type) {
    const modal = document.getElementById("policyModal");
    const titleEl = document.getElementById("policyModalTitle");
    const bodyEl = document.getElementById("policyModalBody");

    if (type === "privacy") {
      titleEl.textContent = "Privacy & Confidentiality Notice";
      bodyEl.innerHTML = `
        <p>Haven House is committed to safeguarding client privacy. In this prototype:</p>
        <ul style="margin: 12px 0 12px 20px; line-height: 1.6;">
          <li>Chat messages and search inputs are processed locally in your browser session.</li>
          <li>No personal data or crisis conversation records are saved to the database.</li>
          <li>In real-world Haven House operational settings, all client information is handled in accordance with Australian privacy legislation and professional duty of care standards.</li>
        </ul>
      `;
    } else if (type === "terms") {
      titleEl.textContent = "Terms of Service";
      bodyEl.innerHTML = `
        <p>This platform is designed to assist visitors in discovering Haven House services and approved community information.</p>
        <ul style="margin: 12px 0 12px 20px; line-height: 1.6;">
          <li>The Support Assistant provides service navigation and approved information only.</li>
          <li>It is not a substitute for emergency services, legal counsel, or medical advice.</li>
          <li>For immediate danger, always contact 000 (Australia) or human crisis support.</li>
        </ul>
      `;
    } else if (type === "safety") {
      titleEl.textContent = "Haven House Safety Plan";
      bodyEl.innerHTML = `
        <p>If you or someone you know is in immediate danger or experiencing crisis:</p>
        <ul style="margin: 12px 0 12px 20px; line-height: 1.6;">
          <li><strong>Emergency Services:</strong> Dial 000 immediately.</li>
          <li><strong>24/7 Haven House Crisis Line:</strong> [Haven House approved 24/7 crisis number: 1300 HAVEN / (02) 9300 XXXX].</li>
          <li><strong>Bondi Safe Hub:</strong> Emergency intake coordination is available 24/7.</li>
        </ul>
      `;
    }

    if (modal) modal.classList.add("open");
  },

  closePolicyModal() {
    const modal = document.getElementById("policyModal");
    if (modal) modal.classList.remove("open");
  },

  toggleMobileNav() {
    const drawer = document.getElementById("mobileNavDrawer");
    if (drawer) drawer.classList.toggle("open");
  },

  setupEventListeners() {
    const serviceSearch = document.getElementById("serviceSearchInput");
    if (serviceSearch) {
      serviceSearch.addEventListener("input", event => this.filterServiceCards(event.currentTarget.value));
    }
    const toggleBtn = document.getElementById("mobileMenuToggle");
    if (toggleBtn) {
      toggleBtn.addEventListener("click", () => this.toggleMobileNav());
    }
    const contactForm = document.getElementById("contactEnquiryForm");
    if (contactForm) {
      contactForm.addEventListener("submit", async event => {
        event.preventDefault();
        const feedback = document.getElementById("contactEnquiryFeedback");
        const submit = contactForm.querySelector('[type="submit"]');
        feedback.className = "auth-feedback";
        feedback.textContent = "Sending…";
        submit.disabled = true;
        try {
          const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/contact-enquiries`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(Object.fromEntries(new FormData(contactForm)))
          });
          const result = await response.json();
          if (!response.ok || !result.success) throw new Error(result.message || "Could not send your message.");
          feedback.className = "auth-feedback success";
          feedback.textContent = result.message || "Your message has been received.";
          contactForm.reset();
        } catch (error) {
          feedback.className = "auth-feedback error";
          feedback.textContent = error.message;
        } finally {
          submit.disabled = false;
        }
      });
    }

    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        this.closeCallModal();
        this.closeContactModal();
        this.closeHoursModal();
        this.closePolicyModal();
      }
    });

    document.querySelectorAll(".modal-backdrop").forEach(backdrop => {
      backdrop.addEventListener("click", (e) => {
        if (e.target === backdrop) {
          backdrop.classList.remove("open");
        }
      });
    });
  },

  async handleAdminLoginSubmit(event) {
    event.preventDefault();
    const username = document.getElementById("adminLoginUsername").value.trim();
    const passcode = document.getElementById("adminLoginPasscode").value;
    const feedback = document.getElementById("adminLoginFeedback");
    const button = document.getElementById("adminLoginBtn");
    if (!username || !passcode) {
      feedback.className = "auth-feedback error";
      feedback.textContent = "Please enter your username and passcode.";
      return;
    }
    button.disabled = true;
    button.textContent = "Signing in...";
    const result = await AuthManager.adminLogin(username, passcode);
    button.disabled = false;
    button.textContent = "Log In";
    if (result.success) {
      document.getElementById("adminLoginPasscode").value = "";
      feedback.className = "auth-feedback";
      feedback.textContent = "";
      Router.navigate("admin");
    } else {
      feedback.className = "auth-feedback error";
      feedback.textContent = result.message;
    }
  },

  async handleLoginSubmit(event) {
    event.preventDefault();
    const emailEl = document.getElementById("loginEmail");
    const passwordEl = document.getElementById("loginPassword");
    const feedbackEl = document.getElementById("loginFeedback");
    const submitBtn = document.getElementById("loginSubmitBtn");

    if (!emailEl || !passwordEl || !feedbackEl) return;
    const email = emailEl.value.trim();
    const password = passwordEl.value;

    if (!email || !password) {
      feedbackEl.className = "auth-feedback error";
      feedbackEl.textContent = "Please enter both email and password.";
      return;
    }

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = "Verifying...";
    }

    const result = await AuthManager.login(email, password);

    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.textContent = "Sign In";
    }

    if (result.success) {
      if (result.otpRequired) {
        feedbackEl.className = "auth-feedback success";
        feedbackEl.textContent = "Password verified. Redirecting to verification code step...";
        setTimeout(() => {
          this.setupOtpScreen();
          if (window.Router) Router.navigate("otp-verification");
        }, 400);
      } else {
        feedbackEl.className = "auth-feedback success";
        feedbackEl.textContent = "Sign in successful! Redirecting...";
        setTimeout(() => {
          const destination = sessionStorage.getItem("haven_house_after_login_route") || "home";
          sessionStorage.removeItem("haven_house_after_login_route");
          if (window.Router) Router.navigate(destination);
        }, 500);
      }
    } else {
      feedbackEl.className = "auth-feedback error";
      feedbackEl.textContent = result.message || "Invalid email or password.";
    }
  },

  openPasswordReset() {
    const loginEmail = document.getElementById("loginEmail");
    const resetEmail = document.getElementById("passwordResetEmail");
    const feedback = document.getElementById("passwordResetRequestFeedback");
    if (loginEmail && resetEmail && loginEmail.value.trim()) {
      resetEmail.value = loginEmail.value.trim();
    }
    if (feedback) {
      feedback.className = "auth-feedback";
      feedback.textContent = "";
    }
  },

  async handlePasswordResetRequest(event) {
    event.preventDefault();
    const emailInput = document.getElementById("passwordResetEmail");
    const feedback = document.getElementById("passwordResetRequestFeedback");
    const submitButton = document.getElementById("passwordResetRequestBtn");
    if (!emailInput || !feedback) return;

    if (submitButton) {
      submitButton.disabled = true;
      submitButton.textContent = "Sending...";
    }
    const result = await AuthManager.requestPasswordReset(emailInput.value.trim());
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Send reset code";
    }

    if (result.success) {
      feedback.className = "auth-feedback success";
      feedback.textContent = result.message;
      setTimeout(() => Router.navigate("reset-password"), 700);
    } else {
      feedback.className = "auth-feedback error";
      feedback.textContent = result.message || "Could not request a password reset.";
    }
  },

  async handlePasswordResetConfirm(event) {
    event.preventDefault();
    const codeInput = document.getElementById("passwordResetCode");
    const passwordInput = document.getElementById("newPassword");
    const confirmInput = document.getElementById("confirmNewPassword");
    const feedback = document.getElementById("passwordResetConfirmFeedback");
    const submitButton = document.getElementById("passwordResetConfirmBtn");
    if (!codeInput || !passwordInput || !confirmInput || !feedback) return;

    if (passwordInput.value !== confirmInput.value) {
      feedback.className = "auth-feedback error";
      feedback.textContent = "The passwords do not match.";
      confirmInput.focus();
      return;
    }

    if (submitButton) {
      submitButton.disabled = true;
      submitButton.textContent = "Saving...";
    }
    const result = await AuthManager.confirmPasswordReset(codeInput.value.trim(), passwordInput.value);
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Save new password";
    }

    if (result.success) {
      feedback.className = "auth-feedback success";
      feedback.textContent = result.message;
      passwordInput.value = "";
      confirmInput.value = "";
      setTimeout(() => Router.navigate("login"), 900);
    } else {
      feedback.className = "auth-feedback error";
      feedback.textContent = result.message || "Could not reset your password.";
    }
  },

  setupOtpScreen() {
    const destEl = document.getElementById("otpDestinationDisplay");
    const codeInput = document.getElementById("otpInputCode");
    const feedbackEl = document.getElementById("otpFeedback");
    const challenge = AuthManager.getPendingChallenge();

    if (destEl && challenge) {
      destEl.textContent = challenge.destination || "your email";
    }

    if (codeInput) {
      codeInput.value = "";
      setTimeout(() => codeInput.focus(), 150);
    }

    if (feedbackEl) {
      feedbackEl.className = "auth-feedback";
      feedbackEl.textContent = "";
      feedbackEl.style.display = "none";
    }

    this.startOtpCountdown(60);
  },

  startOtpCountdown(seconds = 60) {
    const timerEl = document.getElementById("otpCountdownTimer");
    const resendBtn = document.getElementById("otpResendBtn");

    if (this._otpTimerInterval) {
      clearInterval(this._otpTimerInterval);
    }

    let remaining = seconds;
    if (resendBtn) resendBtn.disabled = true;

    const updateTimerText = () => {
      if (remaining <= 0) {
        clearInterval(this._otpTimerInterval);
        if (timerEl) timerEl.textContent = "";
        if (resendBtn) {
          resendBtn.disabled = false;
          resendBtn.style.opacity = "1";
        }
      } else {
        if (timerEl) timerEl.textContent = `(Resend available in ${remaining}s)`;
        if (resendBtn) resendBtn.style.opacity = "0.5";
        remaining--;
      }
    };

    updateTimerText();
    this._otpTimerInterval = setInterval(updateTimerText, 1000);
  },

  async handleOtpSubmit(event) {
    event.preventDefault();
    const codeEl = document.getElementById("otpInputCode");
    const feedbackEl = document.getElementById("otpFeedback");
    const submitBtn = document.getElementById("otpSubmitBtn");

    if (!codeEl || !feedbackEl) return;
    const code = codeEl.value.trim();

    if (!code || code.length !== 6) {
      feedbackEl.className = "auth-feedback error";
      feedbackEl.textContent = "Please enter the complete 6-digit verification code.";
      return;
    }

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = "Verifying Code...";
    }

    const result = await AuthManager.verifyOtp(code);

    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.textContent = "Verify & Sign In";
    }

    if (result.success) {
      feedbackEl.className = "auth-feedback success";
      feedbackEl.textContent = "Verification successful! Welcome to Haven House.";
      setTimeout(() => {
        const destination = sessionStorage.getItem("haven_house_after_login_route") || "home";
        sessionStorage.removeItem("haven_house_after_login_route");
        if (window.Router) Router.navigate(destination);
      }, 500);
    } else {
      feedbackEl.className = "auth-feedback error";
      feedbackEl.textContent = result.message || "Invalid verification code. Please try again.";
      codeEl.select();
    }
  },

  async handleOtpResend() {
    const feedbackEl = document.getElementById("otpFeedback");
    const resendBtn = document.getElementById("otpResendBtn");

    if (resendBtn && resendBtn.disabled) return;

    if (feedbackEl) {
      feedbackEl.className = "auth-feedback";
      feedbackEl.style.display = "none";
    }

    const result = await AuthManager.resendOtp();

    if (result.success) {
      if (feedbackEl) {
        feedbackEl.className = "auth-feedback success";
        feedbackEl.textContent = result.message || "A new verification code has been sent.";
      }
      this.startOtpCountdown(60);
    } else {
      if (feedbackEl) {
        feedbackEl.className = "auth-feedback error";
        feedbackEl.textContent = result.message || "Could not resend code. Please try again later.";
      }
    }
  },

  async handleRegisterSubmit(event) {
    event.preventDefault();
    const nameEl = document.getElementById("registerName");
    const emailEl = document.getElementById("registerEmail");
    const passwordEl = document.getElementById("registerPassword");
    const confirmEl = document.getElementById("registerConfirmPassword");
    const feedbackEl = document.getElementById("registerFeedback");
    const submitBtn = document.getElementById("registerSubmitBtn");

    if (!nameEl || !emailEl || !passwordEl || !confirmEl || !feedbackEl) return;

    const name = nameEl.value.trim();
    const email = emailEl.value.trim();
    const password = passwordEl.value;
    const confirm = confirmEl.value;

    if (!name || !email || !password) {
      feedbackEl.className = "auth-feedback error";
      feedbackEl.textContent = "Please fill in all required fields.";
      return;
    }

    if (password.length < 8) {
      feedbackEl.className = "auth-feedback error";
      feedbackEl.textContent = "Password must be at least 8 characters long.";
      return;
    }

    if (password !== confirm) {
      feedbackEl.className = "auth-feedback error";
      feedbackEl.textContent = "Passwords do not match. Please verify and try again.";
      return;
    }

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = "Creating Account...";
    }

    const result = await AuthManager.register(name, email, password);

    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.textContent = "Create Account";
    }

    if (result.success) {
      feedbackEl.className = "auth-feedback success";
      feedbackEl.textContent = "Account created successfully! Please sign in.";
      setTimeout(() => {
        if (window.Router) Router.navigate("login");
      }, 1000);
    } else {
      feedbackEl.className = "auth-feedback error";
      feedbackEl.textContent = result.message || "Registration could not be completed.";
    }
  }
};

document.addEventListener("DOMContentLoaded", () => {
  App.init();
});

window.App = App;
