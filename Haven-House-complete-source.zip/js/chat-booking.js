/**
 * Inline appointment booking inside the assistant chat (no sign-in required).
 * Uses GET /api/appointments/availability and POST /api/appointments/guest.
 */
const ChatBooking = {
  formHtml() {
    const today = new Date();
    const min = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
    return `
      <form class="chat-booking-form" novalidate>
        <input class="form-input" name="name" type="text" maxlength="120" placeholder="Your name" autocomplete="name" required>
        <input class="form-input" name="contact" type="text" maxlength="190" placeholder="Email or phone number" autocomplete="email" required>
        <input class="form-input chat-booking-date" name="date" type="date" min="${min}" required>
        <select class="form-input" name="time" required disabled><option value="">Choose a date first</option></select>
        <button class="btn btn-primary btn-sm" type="submit">Confirm appointment</button>
        <p class="chat-booking-status" role="status"></p>
      </form>`;
  },

  async loadSlots(form) {
    const select = form.elements.time;
    const date = form.elements.date.value;
    select.disabled = true;
    select.innerHTML = '<option value="">Loading times...</option>';
    if (!date) return;
    try {
      const res = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/appointments/availability?date=${encodeURIComponent(date)}`);
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error(json.message || "Could not load times.");
      const slots = json.data.slots || [];
      if (!slots.length) {
        select.innerHTML = '<option value="">No times available that day</option>';
        return;
      }
      select.innerHTML = '<option value="">Choose a time</option>' + slots.map((s) => {
        const label = new Date(s).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
        return `<option value="${s}">${label}</option>`;
      }).join("");
      select.disabled = false;
    } catch (err) {
      select.innerHTML = `<option value="">${err.message}</option>`;
    }
  },

  async submit(form) {
    const status = form.querySelector(".chat-booking-status");
    const button = form.querySelector("button[type=submit]");
    const name = form.elements.name.value.trim();
    const contact = form.elements.contact.value.trim();
    const startsAt = form.elements.time.value;
    if (!name || !contact || !startsAt) {
      status.textContent = "Please fill in your name, contact details, date and time.";
      status.className = "chat-booking-status is-error";
      return;
    }
    button.disabled = true;
    status.textContent = "Booking...";
    status.className = "chat-booking-status";
    try {
      const res = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/appointments/guest`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, contact, starts_at: startsAt }),
      });
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error(json.message || "Could not book that appointment.");
      const when = new Date(startsAt).toLocaleString([], { dateStyle: "full", timeStyle: "short" });
      form.innerHTML = `<p class="chat-booking-status is-success">Booked! Your appointment is confirmed for ${when}.</p>`;
    } catch (err) {
      status.textContent = err.message;
      status.className = "chat-booking-status is-error";
      button.disabled = false;
      if (/booked|reserved|available/i.test(err.message)) this.loadSlots(form);
    }
  },
};

document.addEventListener("change", (event) => {
  if (event.target.matches(".chat-booking-date")) ChatBooking.loadSlots(event.target.form);
});
document.addEventListener("submit", (event) => {
  if (event.target.matches(".chat-booking-form")) {
    event.preventDefault();
    ChatBooking.submit(event.target);
  }
});
