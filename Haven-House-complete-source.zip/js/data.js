/**
 * Haven House Frontend Configuration & Static Asset Mappings
 * Dynamic content (Services, Details, Eligibility, FAQs) is fetched from the Flask REST API.
 * Contains local fallback definitions for verified external referral information.
 */

const HAVEN_HOUSE_CONFIG = {
  // Base URL for Haven House Backend API (Port 5001 avoids macOS AirPlay collision on port 5000)
  API_BASE: window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1"
    ? "http://localhost:5001/api"
    : "/api",

  // SVG Icon mappings corresponding to database icon_name identifiers
  ICONS: {
    "home": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>`,
    "child": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="7" r="4"/><path d="M5 21v-2a7 7 0 0 1 14 0v2"/><path d="M16 11h6"/><path d="M19 8v6"/></svg>`,
    "accessibility": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="4" r="2"/><path d="m15 8-3 3-3-3"/><path d="M12 11v8"/><path d="M8 21h8"/></svg>`,
    "heart-pulse": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>`,
    "briefcase": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="14" x="2" y="7" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>`,
    "hands-helping": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>`,
    "info-circle": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`,
    "default": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>`
  },

  // Fallback organization data
  fallbackOrganization: {
    name: "Haven House",
    tagline: "Crisis Support Services",
    location: "Bondi, Sydney",
    established_period: "1980s",
    crisisPhonePlaceholder: "[Haven House approved 24/7 crisis number: 1300 HAVEN / (02) 9300 XXXX]",
    emergencyNumber: "000 (Australia) / 911 (International Reference)",
    emailPlaceholder: "[Haven House approved email: intake@havenhouse.org.au]",
    disclaimer: "The Support Assistant provides service navigation and approved information. It is not a counsellor, therapist, lawyer, doctor, or emergency service."
  },

  // Published public content remains available if the local CMS database is offline.
  fallbackFaqs: [
    {
      id: "what-is",
      question: "What is Haven House?",
      answer: "Haven House is focused on providing a safe, supportive and welcoming environment for people who need assistance, connection and access to appropriate support services."
    },
    {
      id: "who-can-access",
      question: "Who can access support?",
      answer: "Our services may be available to individuals and families who meet the relevant eligibility requirements. Contact our team to discuss your circumstances and available support options."
    },
    {
      id: "request-support",
      question: "How do I request support?",
      answer: "You can contact the Haven House team through our enquiry or intake process. Our team will listen to your needs and help identify the most appropriate next steps."
    },
    {
      id: "confidential",
      question: "Is my information confidential?",
      answer: "We respect your privacy and aim to handle personal information responsibly and confidentially, subject to applicable legal and safety requirements."
    },
    {
      id: "referral",
      question: "Do I need a referral?",
      answer: "Referral requirements depend on the type of support you are seeking. Contact our Intake Coordination Desk to find out whether a referral is required."
    },
    {
      id: "after-enquiry",
      question: "What happens after I submit an enquiry?",
      answer: "A member of our team can review your enquiry, discuss your needs and explain the available support pathways."
    },
    {
      id: "on-behalf",
      question: "Can I contact you on behalf of someone else?",
      answer: "Yes. You can make an enquiry on behalf of another person, although consent may be required before certain information can be discussed or services arranged."
    }
  ],

  fallbackEvents: [
    {
      title: "Community Information Session",
      description: "An information session for community members to learn more about our projects, services, upcoming activities, and ways to get involved.",
      schedule_label: "To be announced",
      location: "Heaven House Projects"
    },
    {
      title: "Volunteer Orientation Session",
      description: "An introductory session for new and existing volunteers covering available opportunities, responsibilities, and how volunteers can contribute to our projects.",
      schedule_label: "To be announced",
      location: "Heaven House Projects"
    },
    {
      title: "Community Gathering",
      description: "A community gathering designed to bring people together, encourage participation, and build stronger connections within the community.",
      schedule_label: "To be announced",
      location: "To be announced"
    },
    {
      title: "Project Open Day",
      description: "Visitors will have the opportunity to learn more about Heaven House Projects, meet the team, explore our initiatives, and ask questions.",
      schedule_label: "To be announced",
      location: "Heaven House Projects"
    }
  ],

  fallbackAnnouncements: [
    {
      title: "Website Update",
      body: "We are pleased to announce that the Heaven House Projects website has been updated with improved navigation, new information, and additional features. We will continue improving the website to make it easier for visitors to access important information and updates.",
      published_at: "2026-10-08T12:00:00"
    },
    {
      title: "Community Program Updates",
      body: "Heaven House Projects is continuing to develop community-focused programs and activities. More information about upcoming initiatives, services, and opportunities to participate will be shared soon.",
      published_at: "2026-10-15T12:00:00"
    },
    {
      title: "Volunteer Opportunities",
      body: "We are looking for people who are interested in supporting Heaven House Projects and contributing to our community activities. Further information about available volunteer opportunities will be announced soon.",
      published_at: "2026-10-20T12:00:00"
    },
    {
      title: "New Project Information Available",
      body: "New information about our projects, activities, and community initiatives will be added to the website. Please visit our website regularly to stay informed about the latest developments.",
      published_at: "2026-10-25T12:00:00"
    },
    {
      title: "Important Community Notice",
      body: "Please check this section regularly for important announcements, program updates, event information, and other notices from Heaven House Projects.",
      published_at: "2026-11-01T12:00:00"
    }
  ],

  // 7 service navigation categories with external referral information
  fallbackServices: [
    {
      id: 1,
      service_key: "accommodation",
      title: "Accommodation Support",
      card_title: "Accommodation Support",
      badge: "Accommodation support",
      description: "Our accommodation support helps residents understand their housing options and connect with the appropriate Haven team. Support may include information about residences, accommodation pathways and assistance with housing-related enquiries.",
      icon_name: "home",
      is_active: 1,
      display_order: 1
    },
    {
      id: 2,
      service_key: "child-support",
      title: "Children, Youth & Family Services",
      card_title: "Children, Youth & Family Services",
      badge: "External referral information",
      description: "The Family Relationship Advice Line provides information, support and referrals for families. Call 1800 050 321.",
      icon_name: "child",
      is_active: 1,
      display_order: 2
    },
    {
      id: 3,
      service_key: "ndis",
      title: "NDIS Support",
      card_title: "NDIS Support",
      badge: "External referral information",
      description: "Contact the NDIS for information about access, plans, supports and providers. Call 1800 800 110.",
      icon_name: "accessibility",
      is_active: 1,
      display_order: 3
    },
    {
      id: 4,
      service_key: "psychology",
      title: "Counselling & Psychology",
      card_title: "Counselling & Psychology",
      badge: "External referral information",
      description: "Lifeline offers crisis support by phone, text and online chat, 24 hours a day. This is not a Haven House service.",
      icon_name: "heart-pulse",
      is_active: 1,
      display_order: 4
    },
    {
      id: 5,
      service_key: "employment",
      title: "Employment & Skills Support",
      card_title: "Employment & Skills Support",
      badge: "External referral information",
      description: "Contact Workforce Australia for information about employment services. Eligibility and assistance vary.",
      icon_name: "briefcase",
      is_active: 1,
      display_order: 5
    },
    {
      id: 6,
      service_key: "chaplaincy",
      title: "Chaplaincy Pastoral Care",
      card_title: "Chaplaincy Pastoral Care",
      badge: "External referral information",
      description: "Ask a relevant hospital, educational institution or community organisation about pastoral support.",
      icon_name: "hands-helping",
      is_active: 1,
      display_order: 6
    },
    {
      id: 7,
      service_key: "general-info",
      title: "Information and Referrals",
      card_title: "Information and Referrals",
      badge: "External referral information",
      description: "Search Ask Izzy for Australian community services. Confirm availability and requirements with each provider.",
      icon_name: "info-circle",
      is_active: 1,
      display_order: 7
    }
  ]
};

window.HAVEN_HOUSE_CONFIG = HAVEN_HOUSE_CONFIG;
