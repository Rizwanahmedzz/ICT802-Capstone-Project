/**
 * Support Assistant Full Page Logic
 * Connected to Flask REST API: POST /api/assistant
 * Handles approved database-backed service navigation and crisis handoff guardrail.
 */

const ChatController = {
  messagesContainer: null,
  inputField: null,
  form: null,
  isProcessing: false,

  init() {
    this.messagesContainer = document.getElementById("chatMessages");
    this.inputField = document.getElementById("chatInputField");
    this.form = document.getElementById("chatForm");

    if (this.form) {
      this.form.addEventListener("submit", (e) => {
        e.preventDefault();
        this.handleUserSubmit();
      });
    }

    this.renderWelcomeMessage();
  },

  renderWelcomeMessage() {
    if (!this.messagesContainer) return;
    this.messagesContainer.innerHTML = `
      <div class="message-row assistant-message">
        <div class="message-avatar-small">HH</div>
        <div class="message-bubble">
          <p>Hello. I am the Haven House support assistant. I can help you find service information and navigate your options. Your message is sent to OpenAI to generate a reply. How can I assist you today?</p>
          
          <div class="suggested-actions-grid">
            <button class="suggested-action-btn" onclick="ChatController.sendSuggested('Find a Safe Place')">
              <span class="suggested-action-title">Find a Safe Place</span>
              <span class="suggested-action-desc">Locate crisis and temporary accommodation info.</span>
            </button>
            <button class="suggested-action-btn" onclick="ChatController.sendSuggested('Talk to Someone')">
              <span class="suggested-action-title">Talk to Someone</span>
              <span class="suggested-action-desc">Access psychology and emotional wellbeing info.</span>
            </button>
            <button class="suggested-action-btn" onclick="ChatController.sendSuggested('Community & NDIS')">
              <span class="suggested-action-title">Community & NDIS</span>
              <span class="suggested-action-desc">Information on disability and family programs.</span>
            </button>
          </div>

          <div class="quick-chips-row">
            <button class="quick-chip" onclick="ChatController.sendSuggested('Accommodation')">Accommodation</button>
            <button class="quick-chip" onclick="ChatController.sendSuggested('Support for a child')">Support for a child</button>
            <button class="quick-chip" onclick="ChatController.sendSuggested('NDIS')">NDIS</button>
            <button class="quick-chip" onclick="ChatController.sendSuggested('Psychology')">Psychology</button>
            <button class="quick-chip" onclick="ChatController.sendSuggested('Employment')">Employment</button>
            <button class="quick-chip" onclick="ChatController.sendSuggested('Chaplaincy')">Chaplaincy</button>
          </div>
        </div>
      </div>
    `;
  },

  handleUserSubmit() {
    if (!this.inputField || this.isProcessing) return;
    const text = this.inputField.value.trim();
    if (!text) return;

    this.inputField.value = "";
    this.processMessage(text);
  },

  sendSuggested(text) {
    if (this.isProcessing) return;
    this.processMessage(text);
  },

  async processMessage(userText) {
    // 1. Append User Message
    this.appendMessage("user", userText);

    // 2. CLIENT-SIDE SAFETY GUARDRAIL CHECK
    if (SafetyController.isCrisisIntent(userText)) {
      SafetyController.triggerCrisisHandoff("Support Assistant (Client Safety Guard)");
      return;
    }

    // 3. Show Loading Indicator
    this.isProcessing = true;
    const loadingId = this.showLoadingIndicator();

    try {
      // 4. Send Message to Flask Assistant API
      const response = await fetch(`${HAVEN_HOUSE_CONFIG.API_BASE}/assistant`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userText })
      });

      this.removeLoadingIndicator(loadingId);
      this.isProcessing = false;

      const json = await response.json();
      if (!response.ok) {
        throw new Error(json.message || `HTTP error ${response.status}`);
      }
      if (!json.success || !json.data) {
        throw new Error(json.message || "Invalid response from assistant");
      }

      const data = json.data;

      // 5. SERVER-SIDE CRISIS HANDOFF CHECK
      if (data.handoff === true) {
        SafetyController.triggerCrisisHandoff("Support Assistant (Server Safety Guard)");
        return;
      }

      // 6. Render Assistant Navigation Response
      this.renderAssistantResponse(data);

    } catch (err) {
      console.warn(`[Assistant API Error] ${err.message}`);
      this.removeLoadingIndicator(loadingId);
      this.isProcessing = false;

      // Safe Graceful Fallback
      this.appendMessage("assistant", `
        <p>${this.escapeHtml(err.message)} Make sure the Flask backend is running and OPENAI_API_KEY is configured in its .env file. Open this site through XAMPP at a localhost URL, not directly as a file.</p>
        <div class="btn-group" style="margin-top: 12px;">
          <button class="btn btn-secondary btn-sm" onclick="Router.navigate('services-step-1')">Find a Service</button>
          <button class="btn btn-navy btn-sm" onclick="App.openContactModal('Assistant Offline')">Contact Haven House</button>
        </div>
      `, true);
    }
  },

  renderAssistantResponse(data) {
    const formattedText = this.escapeHtml(data.message).replace(/\n/g, "<br>");
    let actionButtonsHtml = "";

    if (data.services && data.services.length > 0) {
      if (data.services.length === 1) {
        const s = data.services[0];
        const keyOrId = this.escapeJsString(s.service_key || s.id);
        const titleSafe = this.escapeHtml(s.title);
        const titleJsSafe = this.escapeJsString(s.title);
        actionButtonsHtml = `
          <div class="btn-group" style="margin-top: 12px;">
            <button class="btn btn-primary btn-sm" onclick="Router.navigate('service-detail', '${keyOrId}')">View ${titleSafe}</button>
            <button class="btn btn-secondary btn-sm" onclick="App.openContactModal('${titleJsSafe}')">Contact Haven House</button>
          </div>
        `;
      } else {
        // Multiple services or general inquiry list
        const serviceButtons = data.services.slice(0, 4).map(s => {
          const keyOrId = this.escapeJsString(s.service_key || s.id);
          const titleSafe = this.escapeHtml(s.title);
          return `<button class="btn btn-secondary btn-sm" onclick="Router.navigate('service-detail', '${keyOrId}')">${titleSafe}</button>`;
        }).join(" ");

        actionButtonsHtml = `
          <div class="btn-group" style="margin-top: 12px;">
            ${serviceButtons}
            <button class="btn btn-navy btn-sm" onclick="App.openContactModal('General Inquiry')">Contact Haven House</button>
          </div>
        `;
      }
    } else {
      actionButtonsHtml = `
        <div class="btn-group" style="margin-top: 12px;">
          <button class="btn btn-primary btn-sm" onclick="Router.navigate('services-step-1')">Find a Service</button>
          <button class="btn btn-secondary btn-sm" onclick="App.openContactModal('Inquiry')">Contact Haven House</button>
        </div>
      `;
    }

    const fullContent = `<p>${formattedText}</p>${data.action === "book_appointment" ? ChatBooking.formHtml() : actionButtonsHtml}`;
    this.appendMessage("assistant", fullContent, true);
  },

  showLoadingIndicator() {
    const id = "loading-" + Date.now();
    const row = document.createElement("div");
    row.id = id;
    row.className = "message-row assistant-message";
    row.innerHTML = `
      <div class="message-avatar-small">HH</div>
      <div class="message-bubble" style="color: var(--color-text-muted); font-style: italic;">
        Checking approved service knowledge...
      </div>
    `;
    this.messagesContainer.appendChild(row);
    this.scrollToBottom();
    return id;
  },

  removeLoadingIndicator(id) {
    const el = document.getElementById(id);
    if (el) el.remove();
  },

  appendMessage(sender, contentHtml, isHtml = false) {
    if (!this.messagesContainer) return;

    const row = document.createElement("div");
    row.className = `message-row ${sender}-message`;

    if (sender === "assistant") {
      row.innerHTML = `
        <div class="message-avatar-small">HH</div>
        <div class="message-bubble">${isHtml ? contentHtml : `<p>${contentHtml}</p>`}</div>
      `;
    } else {
      row.innerHTML = `
        <div class="message-bubble">
          <p>${this.escapeHtml(contentHtml)}</p>
        </div>
      `;
    }

    this.messagesContainer.appendChild(row);
    this.scrollToBottom();
  },

  scrollToBottom() {
    if (!this.messagesContainer) return;
    this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
  },

  escapeHtml(text) {
    if (!text) return "";
    const div = document.createElement("div");
    div.textContent = String(text);
    return div.innerHTML;
  },

  escapeJsString(str) {
    if (!str) return "";
    return String(str).replace(/\\/g, "\\\\").replace(/'/g, "\\'").replace(/"/g, "&quot;");
  }
};

window.ChatController = ChatController;
